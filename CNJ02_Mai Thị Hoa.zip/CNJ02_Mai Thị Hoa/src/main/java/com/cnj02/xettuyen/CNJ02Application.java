package com.cnj02.xettuyen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EntityScan(basePackages = "com.cnj02.xettuyen")
@EnableJpaRepositories(basePackages = "com.cnj02.xettuyen")
public class CNJ02Application {

    public static void main(String[] args) {
        SpringApplication.run(CNJ02Application.class, args);
    }
}