package com.cnj02.xettuyen.PRESENTATION_LAYER_UI.ADMIN_CONTROLLER;

import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.text.Normalizer;
import java.util.*;

/**
 * Nghiệp vụ cán bộ tuyển sinh.
 * Cán bộ dùng chung khu vực /admin, nhưng chỉ nhìn thấy các chức năng nghiệp vụ;
 * tài khoản ADMIN không được thực hiện thao tác xét duyệt.
 */
@Controller
@RequestMapping("/admin/duyet-ho-so")
public class DuyetHoSoController {
    private final JdbcTemplate jdbc;

    public DuyetHoSoController(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    private User staff(HttpSession session) {
        User u = (User) session.getAttribute("currentUser");
        return u != null && Integer.valueOf(2).equals(u.getRoleId()) ? u : null;
    }

    @GetMapping
    public String list(HttpSession session, Model model,
                       @RequestParam(defaultValue = "1") int page) {
        User u = staff(session);
        if (u == null) return "redirect:/403";

        final int pageSize = 30;
        long total = jdbc.queryForObject("SELECT COUNT(*) FROM HoSo WHERE ngay_nop >= '2026-01-01 00:00:00' AND ngay_nop < '2027-01-01 00:00:00'", Long.class);
        int totalPages = Math.max(1, (int) Math.ceil(total / (double) pageSize));
        page = Math.max(1, Math.min(page, totalPages));
        int offset = (page - 1) * pageSize;

        List<Map<String,Object>> items = jdbc.queryForList(
                "SELECT hs.ho_so_id, hs.ngay_nop, COALESCE(hs.trang_thai,'CHO_DUYET') trang_thai, " +
                "COALESCE(hs.ghi_chu,'Hồ sơ nộp trực tuyến') ghi_chu, " +
                "COALESCE(sv.ho_ten,'Thí sinh') ho_ten, COALESCE(sv.cccd,'Chưa cập nhật') cccd, " +
                "COALESCE(pt.ma_phuong_thuc,CONCAT('PT#',hs.phuong_thuc_id)) ma_phuong_thuc, " +
                "COALESCE(pt.ten_phuong_thuc,'Phương thức xét tuyển') ten_phuong_thuc, " +
                "(SELECT COUNT(*) FROM NguyenVong nv WHERE nv.ho_so_id=hs.ho_so_id) so_nguyen_vong, " +
                "(SELECT COUNT(*) FROM MinhChung mc WHERE mc.ho_so_id=hs.ho_so_id) so_minh_chung, " +
                "(SELECT COUNT(*) FROM DiemXetTuyen d WHERE d.ho_so_id=hs.ho_so_id) so_diem " +
                "FROM HoSo hs JOIN SinhVien sv ON sv.sinh_vien_id=hs.sinh_vien_id " +
                "LEFT JOIN PhuongThucXetTuyen pt ON pt.phuong_thuc_id=hs.phuong_thuc_id " +
                "WHERE hs.ngay_nop >= '2026-01-01 00:00:00' AND hs.ngay_nop < '2027-01-01 00:00:00' ORDER BY hs.ho_so_id ASC LIMIT ? OFFSET ?", pageSize, offset);

        long pending = jdbc.queryForObject("SELECT COUNT(*) FROM HoSo WHERE ngay_nop >= '2026-01-01 00:00:00' AND ngay_nop < '2027-01-01 00:00:00' AND trang_thai='CHO_DUYET'", Long.class);
        long approved = jdbc.queryForObject("SELECT COUNT(*) FROM HoSo WHERE ngay_nop >= '2026-01-01 00:00:00' AND ngay_nop < '2027-01-01 00:00:00' AND trang_thai='DA_DUYET'", Long.class);
        long rejected = jdbc.queryForObject("SELECT COUNT(*) FROM HoSo WHERE ngay_nop >= '2026-01-01 00:00:00' AND ngay_nop < '2027-01-01 00:00:00' AND trang_thai='KHONG_DUYET'", Long.class);

        model.addAttribute("items", items);
        model.addAttribute("totalCount", total);
        model.addAttribute("pendingCount", pending);
        model.addAttribute("approvedCount", approved);
        model.addAttribute("rejectedCount", rejected);
        model.addAttribute("page", page);
        model.addAttribute("totalPages", totalPages);
        model.addAttribute("currentUser", u);
        model.addAttribute("isStaff", true);
        model.addAttribute("tabId", "hoso");
        return "VIEW/ADMIN/duyet-ho-so";
    }

    @GetMapping("/{id}")
    public String detail(@PathVariable int id, HttpSession session, Model model) {
        User u = staff(session);
        if (u == null) return "redirect:/403";

        List<Map<String,Object>> rows = jdbc.queryForList(
                "SELECT hs.ho_so_id, hs.sinh_vien_id, hs.phuong_thuc_id, " +
                "COALESCE(hs.to_hop,'') to_hop, hs.ngay_nop, COALESCE(hs.trang_thai,'CHO_DUYET') trang_thai, " +
                "COALESCE(hs.ghi_chu,'Hồ sơ nộp trực tuyến') ghi_chu, " +
                "COALESCE(pt.ma_phuong_thuc,CONCAT('PT#',hs.phuong_thuc_id)) ma_phuong_thuc, " +
                "COALESCE(pt.ten_phuong_thuc,'Phương thức xét tuyển') ten_phuong_thuc, " +
                "COALESCE(pt.mo_ta,'Thông tin phương thức xét tuyển') mo_ta_phuong_thuc, " +
                "COALESCE(sv.ho_ten,'Thí sinh') ho_ten, COALESCE(sv.cccd,'Chưa cập nhật') cccd, " +
                "COALESCE(DATE_FORMAT(sv.ngay_sinh,'%d/%m/%Y'),'Chưa cập nhật') ngay_sinh, " +
                "COALESCE(sv.gioi_tinh,'Chưa cập nhật') gioi_tinh, " +
                "COALESCE(sv.dia_chi,'Chưa cập nhật') dia_chi, COALESCE(sv.truong_thpt,'Chưa cập nhật') truong_thpt, " +
                "sv.anh_dai_dien, sv.anh_dai_dien_data, sv.anh_dai_dien_mime, " +
                "COALESCE(u.username,'Tài khoản thí sinh') username, COALESCE(u.email,'Chưa cập nhật') email, " +
                "COALESCE(u.phone,'Chưa cập nhật') phone " +
                "FROM HoSo hs JOIN SinhVien sv ON sv.sinh_vien_id=hs.sinh_vien_id " +
                "JOIN `User` u ON u.user_id=sv.user_id " +
                "LEFT JOIN PhuongThucXetTuyen pt ON pt.phuong_thuc_id=hs.phuong_thuc_id " +
                "WHERE hs.ho_so_id=?", id);

        if (rows.isEmpty()) {
            model.addAttribute("notFound", true);
            model.addAttribute("currentUser", u);
            model.addAttribute("isStaff", true);
            model.addAttribute("tabId", "hoso");
            return "VIEW/ADMIN/duyet-ho-so-chi-tiet";
        }

        Map<String,Object> a = new LinkedHashMap<>(rows.get(0));
        int studentId = ((Number) a.get("sinh_vien_id")).intValue();
        String syncedToHop = syncToHopFromScores(id);
        if (syncedToHop != null) a.put("to_hop", syncedToHop);

        List<Map<String,Object>> aspirations = jdbc.queryForList(
                "SELECT nv.nguyen_vong_id,nv.thu_tu_nguyen_vong,COALESCE(nv.trang_thai,'CHO_XET') trang_thai,nv.nganh_id, " +
                "COALESCE(n.ma_nganh,CONCAT('NGANH#',nv.nganh_id)) ma_nganh, " +
                "COALESCE(n.ten_nganh,'Ngành tuyển sinh') ten_nganh, COALESCE(n.mo_ta,'Chương trình đào tạo') mo_ta " +
                "FROM NguyenVong nv LEFT JOIN Nganh n ON n.nganh_id=nv.nganh_id " +
                "WHERE nv.ho_so_id=? ORDER BY nv.thu_tu_nguyen_vong,nv.nguyen_vong_id", id);

        List<Map<String,Object>> documents = jdbc.queryForList(
                "SELECT minh_chung_id,COALESCE(ten_minh_chung,'Minh chứng hồ sơ') ten_minh_chung, " +
                "COALESCE(file_path,'') file_path,COALESCE(loai_minh_chung,'FILE') loai_minh_chung, " +
                "COALESCE(mime_type,'application/octet-stream') mime_type,COALESCE(kich_thuoc,0) kich_thuoc, " +
                "CASE WHEN du_lieu IS NULL THEN 0 ELSE OCTET_LENGTH(du_lieu) END db_size " +
                "FROM MinhChung WHERE ho_so_id=? ORDER BY minh_chung_id", id);

        List<Map<String,Object>> scores = jdbc.queryForList(
                "SELECT COALESCE(ten_mon,'Môn xét tuyển') ten_mon,COALESCE(diem_so,0) diem_so " +
                "FROM DiemXetTuyen WHERE ho_so_id=? ORDER BY diem_id", id);
        // =========================
        // TỔ HỢP + ĐIỂM THÍ SINH ĐÃ KHAI BÁO
        // =========================

        String selectedToHop = a.get("to_hop") == null
                ? ""
                : String.valueOf(a.get("to_hop")).trim();

        // Nếu hồ sơ cũ bị thiếu HoSo.to_hop thì đối chiếu 3 môn
        // đã lưu trong DiemXetTuyen với danh mục ToHopMon.
        if (selectedToHop.isBlank()) {
            String resolved = syncToHopFromScores(id);
            if (resolved != null) {
                selectedToHop = resolved;
                a.put("to_hop", resolved);
            }
        }

        List<String> selectedSubjects = selectedToHop.isBlank()
                ? List.of()
                : subjects(selectedToHop);

        // Điểm gốc lấy trực tiếp từ DiemXetTuyen.
        // Chuẩn hóa tên môn để không bị lỗi do khoảng trắng/hoa thường.
        Map<String, Double> rawScoreMap = new LinkedHashMap<>();
        for (Map<String,Object> row : scores) {
            Object name = row.get("ten_mon");
            Object value = row.get("diem_so");

            if (name != null && value instanceof Number n) {
                rawScoreMap.put(
                        normalizeSubject(String.valueOf(name)),
                        n.doubleValue()
                );
            }
        }

        // Danh sách điểm dùng để hiển thị:
        // - Có tổ hợp: hiển thị đúng thứ tự môn của tổ hợp.
        // - Không có tổ hợp: vẫn hiển thị toàn bộ điểm đã lưu,
        //   để cán bộ không bao giờ thấy "Chưa nhập" khi CSDL đã có điểm.
        List<Map<String,Object>> displayScores = new ArrayList<>();

        if (!selectedSubjects.isEmpty()) {
            for (String subject : selectedSubjects) {
                Double value = rawScoreMap.get(normalizeSubject(subject));
                if (value != null) {
                    Map<String,Object> item = new LinkedHashMap<>();
                    item.put("ten_mon", subject);
                    item.put("diem_so", value);
                    displayScores.add(item);
                }
            }
        }

        if (displayScores.isEmpty()) {
            displayScores.addAll(scores);
        }

        double totalScore = displayScores.stream()
                .filter(x -> x.get("diem_so") instanceof Number)
                .mapToDouble(x -> ((Number)x.get("diem_so")).doubleValue())
                .sum();

        List<Map<String,Object>> result = jdbc.queryForList(

                "SELECT kq.ket_qua_id,kq.ho_so_id,kq.diem_xet_tuyen,COALESCE(kq.trang_thai_ket_qua,'Đang chờ kết quả') trang_thai_ket_qua,kq.ngay_cap_nhat, " +
                "COALESCE(n.ma_nganh,CONCAT('NGANH#',kq.nganh_id)) ma_nganh,COALESCE(n.ten_nganh,'Ngành tuyển sinh') ten_nganh " +
                "FROM KetQua kq LEFT JOIN Nganh n ON n.nganh_id=kq.nganh_id WHERE kq.ho_so_id=?", id);

        String avatarUrl = "/images/avatar-placeholder.svg";
        // Ưu tiên ảnh IMAGE_AVATAR đã lưu trong MinhChung của chính hồ sơ;
        // nếu hồ sơ cũ không có thì mới đọc ảnh đại diện từ SinhVien.
        for (Map<String,Object> d : documents) {
            if ("IMAGE_AVATAR".equals(String.valueOf(d.get("loai_minh_chung")))) {
                avatarUrl = "/minh-chung/file/" + d.get("minh_chung_id");
                break;
            }
        }
        if (studentId > 0 && "/images/avatar-placeholder.svg".equals(avatarUrl)) avatarUrl = "/sinh-vien/avatar/" + studentId;

        a.put("aspirations", aspirations);
        a.put("documents", documents);
        a.put("scores", scores);
        a.put("displayScores", displayScores);
        a.put("result", result.isEmpty() ? null : result.get(0));
        a.put("avatarUrl", avatarUrl);

        // Template có cả cách đọc Map và biến trực tiếp. Gửi đủ biến để
        // không bao giờ xuất hiện HSnull / null / trống do sai tên thuộc tính.
        model.addAttribute("application", a);
        model.addAttribute("aspirations", aspirations);
        model.addAttribute("documents", documents);
        model.addAttribute("scores", scores);
        model.addAttribute("displayScores", displayScores);
        model.addAttribute("selectedToHop", selectedToHop);
        model.addAttribute("selectedSubjects", selectedSubjects);
        model.addAttribute("totalScore", totalScore);
        // Lịch sử xử lý chỉ hiển thị tại khu vực QUẢN TRỊ.
        // Dữ liệu được đọc trực tiếp từ HoSoLog của chính hồ sơ, không lấy từ dữ liệu mô phỏng trên giao diện.
        List<Map<String,Object>> logs = jdbc.queryForList(
                "SELECT l.log_id,l.ho_so_id,l.user_id,l.hanh_dong,l.thoi_gian,COALESCE(l.chi_tiet,'') chi_tiet, " +
                "COALESCE(u.username,'Hệ thống') username,COALESCE(r.role_name,'') role_name " +
                "FROM HoSoLog l LEFT JOIN `User` u ON u.user_id=l.user_id " +
                "LEFT JOIN Role r ON r.role_id=u.role_id " +
                "WHERE l.ho_so_id=? ORDER BY l.thoi_gian DESC,l.log_id DESC", id);

        model.addAttribute("result", result.isEmpty() ? null : result.get(0));
        model.addAttribute("logs", logs);
        model.addAttribute("currentUser", u);
        model.addAttribute("isStaff", true);
        model.addAttribute("tabId", "hoso");
        model.addAttribute("avatarFallbackUrl", "/sinh-vien/avatar/" + studentId);
        model.addAttribute("hoSoId", a.get("ho_so_id"));
        model.addAttribute("ngayNop", a.get("ngay_nop"));
        model.addAttribute("maPhuongThuc", a.get("ma_phuong_thuc"));
        model.addAttribute("tenPhuongThuc", a.get("ten_phuong_thuc"));
        model.addAttribute("moTaPhuongThuc", a.get("mo_ta_phuong_thuc"));
        model.addAttribute("hoTen", a.get("ho_ten"));
        model.addAttribute("cccd", a.get("cccd"));
        model.addAttribute("ngaySinh", a.get("ngay_sinh"));
        model.addAttribute("gioiTinh", a.get("gioi_tinh"));
        model.addAttribute("email", a.get("email"));
        model.addAttribute("phone", a.get("phone"));
        model.addAttribute("truongThpt", a.get("truong_thpt"));
        model.addAttribute("diaChi", a.get("dia_chi"));
        String currentStatus = a.get("trang_thai") == null ? "CHO_DUYET" : String.valueOf(a.get("trang_thai"));
        model.addAttribute("statusText", switch (currentStatus) { case "TIEP_NHAN" -> "ĐÃ TIẾP NHẬN"; case "DANG_XU_LY" -> "ĐANG XỬ LÝ"; case "DA_DUYET" -> "ĐÃ DUYỆT"; case "KHONG_DUYET" -> "KHÔNG ĐƯỢC DUYỆT"; case "HUY" -> "ĐÃ HỦY"; default -> "ĐANG CHỜ XỬ LÝ"; });
        model.addAttribute("statusClass", switch (currentStatus) { case "DA_DUYET" -> "status-ok"; case "KHONG_DUYET", "HUY" -> "status-no"; case "TIEP_NHAN", "DANG_XU_LY" -> "status-info"; default -> "status-wait"; });
        return "VIEW/ADMIN/duyet-ho-so-chi-tiet";
    }

    @PostMapping("/update/{id}")
    @Transactional
    public String update(@PathVariable Integer id,
                         @RequestParam(defaultValue="CHO_DUYET") String status,
                         @RequestParam(required=false) String note,
                         HttpSession session, RedirectAttributes ra) {
        User u = staff(session);
        if (u == null) return "redirect:/403";
        status = status == null ? "" : status.trim().toUpperCase(Locale.ROOT);
        Set<String> allowed = Set.of("CHO_DUYET","TIEP_NHAN","DANG_XU_LY","DA_DUYET","KHONG_DUYET","HUY");
        if (!allowed.contains(status)) {
            ra.addFlashAttribute("error", "Trạng thái xử lý không hợp lệ. Vui lòng chọn đúng trạng thái trong danh sách.");
            return "redirect:/admin/duyet-ho-so/" + id;
        }
        try {
            // Đọc trạng thái cũ trực tiếp từ MySQL để bảo đảm nhật ký phản ánh đúng lần chuyển trạng thái.
            Map<String,Object> current = jdbc.queryForMap(
                    "SELECT trang_thai,COALESCE(ghi_chu,'') ghi_chu FROM HoSo WHERE ho_so_id=?", id);
            String oldStatus = current.get("trang_thai") == null ? "CHO_DUYET" : String.valueOf(current.get("trang_thai"));

            // Cán bộ KHÔNG nhập lại tổ hợp/điểm. Đây là dữ liệu thí sinh đã khai trong hồ sơ.
            // Khi duyệt, hệ thống chỉ kiểm tra dữ liệu đã lưu rồi tính kết quả.
            if ("DA_DUYET".equals(status)) validateSubmittedScores(id);
            String cleanNote = note == null || note.isBlank() ? defaultNote(status) : note.trim();
            jdbc.update("UPDATE HoSo SET trang_thai=?, ghi_chu=? WHERE ho_so_id=?", status, cleanNote, id);

            // Nhật ký chỉ là dữ liệu quản trị: ghi đúng nghiệp vụ thực tế và thời điểm MySQL cập nhật.
            if (!status.equalsIgnoreCase(oldStatus) || !cleanNote.equals(String.valueOf(current.get("ghi_chu")))) {
                String action = historyAction(status);
                String detail = cleanNote;
                jdbc.update("INSERT INTO HoSoLog(ho_so_id,user_id,hanh_dong,chi_tiet) VALUES(?,?,?,?)",
                        id, u.getUserId(), action, detail);
            }

            // Đồng bộ toàn bộ dữ liệu liên quan của hồ sơ sau khi đổi trạng thái.
            if ("DA_DUYET".equals(status)) {
                createOrUpdateResult(id);
            } else if ("KHONG_DUYET".equals(status)) {
                jdbc.update("UPDATE NguyenVong SET trang_thai='KHONG_DUYET' WHERE ho_so_id=?", id);
                jdbc.update("UPDATE KetQua SET trang_thai_ket_qua='KHONG_TRUNG_TUYEN',ngay_cap_nhat=NOW() WHERE ho_so_id=?", id);
            } else if ("CHO_DUYET".equals(status) || "TIEP_NHAN".equals(status) || "DANG_XU_LY".equals(status) || "HUY".equals(status)) {
                // Chưa hoàn tất xét tuyển thì kết quả không được phép còn trạng thái cũ như TRÚNG TUYỂN.
                jdbc.update("UPDATE NguyenVong SET trang_thai='CHO_XET' WHERE ho_so_id=?", id);
                jdbc.update("UPDATE KetQua SET trang_thai_ket_qua=?,ngay_cap_nhat=NOW() WHERE ho_so_id=?",
                        "HUY".equals(status) ? "HUY" : "CHUA_XET", id);
            }
            ra.addFlashAttribute("success", "Đã cập nhật hồ sơ HS" + id + " thành " + status + ".");
        } catch (Exception e) {
            // Không để giao dịch dở dang: nếu kiểm tra tổ hợp/điểm/tính kết quả lỗi,
            // trạng thái hồ sơ cũng phải được rollback về trạng thái trước đó.
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            ra.addFlashAttribute("error", "Không thể cập nhật hồ sơ: " + safe(e.getMessage()));
        }
        return "redirect:/admin/duyet-ho-so/" + id;
    }

    private String historyAction(String status) {
        return switch (status) {
            case "TIEP_NHAN" -> "TIẾP NHẬN HỒ SƠ";
            case "DANG_XU_LY" -> "ĐANG XỬ LÝ HỒ SƠ";
            case "DA_DUYET" -> "DUYỆT HỒ SƠ";
            case "KHONG_DUYET" -> "KHÔNG DUYỆT HỒ SƠ";
            case "HUY" -> "HỦY HỒ SƠ";
            default -> "CẬP NHẬT TRẠNG THÁI HỒ SƠ";
        };
    }

    private String defaultNote(String status) {
        return switch (status) {
            case "TIEP_NHAN" -> "Cán bộ đã tiếp nhận hồ sơ.";
            case "DANG_XU_LY" -> "Cán bộ đang kiểm tra hồ sơ, nguyện vọng, tổ hợp và điểm.";
            case "DA_DUYET" -> "Hồ sơ hợp lệ, cán bộ đã duyệt. Hệ thống tính kết quả từ dữ liệu thí sinh đã nộp.";
            case "KHONG_DUYET" -> "Hồ sơ không đủ điều kiện để duyệt.";
            case "HUY" -> "Hồ sơ đã được hủy.";
            default -> "Cán bộ cập nhật trạng thái hồ sơ.";
        };
    }

    private void validateSubmittedScores(int hoSoId) {
        String synced = syncToHopFromScores(hoSoId);
        Map<String,Object> hs = jdbc.queryForMap(
                "SELECT hs.to_hop FROM HoSo hs WHERE hs.ho_so_id=?", hoSoId);
        String hop = synced != null ? synced : (hs.get("to_hop") == null ? "" : String.valueOf(hs.get("to_hop")).trim());
        if (hop.isBlank() || "null".equalsIgnoreCase(hop)) {
            throw new IllegalArgumentException("Hồ sơ chưa có tổ hợp do thí sinh khai báo.");
        }
        List<String> selectedSubjects = subjects(hop);
        for (String subject : selectedSubjects) {
            Integer exists = jdbc.queryForObject(
                    "SELECT COUNT(*) FROM DiemXetTuyen WHERE ho_so_id=? AND ten_mon=? AND diem_so BETWEEN 0 AND 10",
                    Integer.class, hoSoId, subject);
            if (exists == null || exists == 0) {
                throw new IllegalArgumentException("Thiếu điểm " + subject + " trong hồ sơ thí sinh.");
            }
        }
    }

    private List<String> subjects(String hop) {
        List<String> subjects = jdbc.queryForList(
                "SELECT m.ten_mon FROM ToHopMon m JOIN ToHopXetTuyen t ON t.to_hop_id=m.to_hop_id WHERE t.ma_to_hop=? ORDER BY m.thu_tu",
                String.class, hop);
        if (subjects.isEmpty()) throw new IllegalArgumentException("Tổ hợp chưa được cấu hình môn xét tuyển trong CSDL.");
        return subjects;
    }

    /** Tính kết quả dựa hoàn toàn trên tổ hợp + điểm do thí sinh đã nộp và các nguyện vọng đã đăng ký. */
    private void createOrUpdateResult(int hoSoId) {
        Map<String,Object> hs = jdbc.queryForMap("SELECT phuong_thuc_id,to_hop FROM HoSo WHERE ho_so_id=?", hoSoId);
        Integer methodId = ((Number) hs.get("phuong_thuc_id")).intValue();
        String toHop = hs.get("to_hop") == null ? "" : String.valueOf(hs.get("to_hop"));
        List<String> selectedSubjects = subjects(toHop);
        String placeholders = String.join(",", Collections.nCopies(selectedSubjects.size(), "?"));
        Object[] scoreArgs = new Object[selectedSubjects.size() + 1];
        scoreArgs[0] = hoSoId;
        for (int i = 0; i < selectedSubjects.size(); i++) scoreArgs[i + 1] = selectedSubjects.get(i);
        Double total = jdbc.queryForObject(
                "SELECT SUM(diem_so) FROM DiemXetTuyen WHERE ho_so_id=? AND ten_mon IN (" + placeholders + ")",
                Double.class, scoreArgs);
        if (total == null) throw new IllegalArgumentException("Không có điểm xét tuyển trong hồ sơ.");

        List<Map<String,Object>> nv = jdbc.queryForList("SELECT nv.nganh_id,nv.thu_tu_nguyen_vong,n.ma_nganh,n.ten_nganh FROM NguyenVong nv LEFT JOIN Nganh n ON n.nganh_id=nv.nganh_id WHERE nv.ho_so_id=? ORDER BY nv.thu_tu_nguyen_vong", hoSoId);
        if (nv.isEmpty()) throw new IllegalArgumentException("Hồ sơ chưa có nguyện vọng để xét tuyển.");

        Integer selected = null;
        Double selectedFloor = null;
        for (Map<String,Object> row : nv) {
            int nganh = ((Number) row.get("nganh_id")).intValue();
            Double floor = jdbc.queryForObject("SELECT MIN(diem_san) FROM ChiTieu WHERE nganh_id=? AND phuong_thuc_id=? AND nam_hoc=(SELECT MAX(nam_hoc) FROM ChiTieu)", Double.class, nganh, methodId);
            Long quota = jdbc.queryForObject("SELECT COALESCE(SUM(so_luong),0) FROM ChiTieu WHERE nganh_id=? AND phuong_thuc_id=? AND nam_hoc=(SELECT MAX(nam_hoc) FROM ChiTieu)", Long.class, nganh, methodId);
            Long approved = jdbc.queryForObject("SELECT COUNT(*) FROM KetQua WHERE nganh_id=? AND trang_thai_ket_qua='TRUNG_TUYEN' AND ho_so_id<>?", Long.class, nganh, hoSoId);
            if (floor != null && total >= floor && (quota == null || quota == 0 || approved == null || approved < quota)) {
                selected = nganh; selectedFloor = floor; break;
            }
        }
        // Nếu không đạt NV nào, vẫn ghi kết quả tại NV1 để sinh viên biết hồ sơ không trúng tuyển;
        // không tự chuyển sang một ngành mà sinh viên không đăng ký.
        if (selected == null) {
            selected = ((Number) nv.get(0).get("nganh_id")).intValue();
            selectedFloor = jdbc.queryForObject("SELECT MIN(diem_san) FROM ChiTieu WHERE nganh_id=? AND phuong_thuc_id=? AND nam_hoc=(SELECT MAX(nam_hoc) FROM ChiTieu)", Double.class, selected, methodId);
        }
        String resultStatus = selectedFloor != null && total >= selectedFloor ? "TRUNG_TUYEN" : "KHONG_TRUNG_TUYEN";
        Integer exists = jdbc.queryForObject("SELECT COUNT(*) FROM KetQua WHERE ho_so_id=?", Integer.class, hoSoId);
        if (exists != null && exists > 0) {
            jdbc.update("UPDATE KetQua SET nganh_id=?,diem_xet_tuyen=?,trang_thai_ket_qua=?,ngay_cap_nhat=NOW() WHERE ho_so_id=?", selected,total,resultStatus,hoSoId);
        } else {
            jdbc.update("INSERT INTO KetQua(ho_so_id,nganh_id,diem_xet_tuyen,trang_thai_ket_qua,ngay_cap_nhat) VALUES(?,?,?,?,NOW())",hoSoId,selected,total,resultStatus);
        }
        if ("TRUNG_TUYEN".equals(resultStatus)) {
            jdbc.update("UPDATE NguyenVong SET trang_thai=CASE WHEN nganh_id=? THEN 'DA_DUYET' ELSE 'KHONG_DUYET' END WHERE ho_so_id=?", selected,hoSoId);
        } else {
            jdbc.update("UPDATE NguyenVong SET trang_thai='KHONG_DUYET' WHERE ho_so_id=?", hoSoId);
        }
    }

    /** Đồng bộ tổ hợp bị thiếu từ đúng 3 môn điểm đã lưu trong MySQL. */
    private String syncToHopFromScores(int hoSoId) {
        List<Map<String,Object>> hsRows = jdbc.queryForList(
                "SELECT to_hop FROM HoSo WHERE ho_so_id=?", hoSoId);
        if (hsRows.isEmpty()) return null;

        Object current = hsRows.get(0).get("to_hop");
        if (current != null && !String.valueOf(current).trim().isBlank()) {
            String hop = String.valueOf(current).trim();
            Integer exists = jdbc.queryForObject("SELECT COUNT(*) FROM ToHopXetTuyen WHERE ma_to_hop=?", Integer.class, hop);
            if (exists != null && exists > 0) return hop;
        }

        List<String> savedSubjects = jdbc.queryForList(
                "SELECT ten_mon FROM DiemXetTuyen WHERE ho_so_id=? ORDER BY diem_id",
                String.class, hoSoId);

        Set<String> saved = new LinkedHashSet<>();
        for (String subject : savedSubjects) {
            String key = normalizeSubject(subject);
            if (!key.isBlank()) saved.add(key);
        }
        // Một hồ sơ xét tuyển theo tổ hợp phải có đúng 3 môn khác nhau.
        if (saved.size() != 3) return null;

        List<Map<String,Object>> rows = jdbc.queryForList(
                "SELECT t.ma_to_hop,m.ten_mon FROM ToHopXetTuyen t JOIN ToHopMon m ON m.to_hop_id=t.to_hop_id ORDER BY t.to_hop_id,m.thu_tu");
        Map<String,Set<String>> comboSubjects = new LinkedHashMap<>();
        for (Map<String,Object> row : rows) {
            String code = String.valueOf(row.get("ma_to_hop"));
            comboSubjects.computeIfAbsent(code,k -> new LinkedHashSet<>()).add(normalizeSubject(String.valueOf(row.get("ten_mon"))));
        }
        List<String> matches = new ArrayList<>();
        for (Map.Entry<String,Set<String>> e : comboSubjects.entrySet()) {
            if (e.getValue().size() == 3 && e.getValue().equals(saved)) {
                matches.add(e.getKey());
            }
        }

        // Fallback: nếu bảng ToHopMon của CSDL đang thiếu dữ liệu,
        // vẫn có thể đối chiếu từ tên 3 môn được lưu trong ToHopXetTuyen.
        // Chỉ chọn khi khớp duy nhất một tổ hợp, tuyệt đối không đoán theo tổng điểm.
        if (matches.isEmpty()) {
            List<Map<String,Object>> comboNames = jdbc.queryForList(
                    "SELECT ma_to_hop, ten_to_hop FROM ToHopXetTuyen"
            );

            for (Map<String,Object> row : comboNames) {
                String code = String.valueOf(row.get("ma_to_hop"));
                String name = String.valueOf(row.get("ten_to_hop"));

                Set<String> comboNameSubjects = new LinkedHashSet<>();
                for (String part : name.split(",")) {
                    comboNameSubjects.add(normalizeSubject(part));
                }

                if (comboNameSubjects.size() == 3 && comboNameSubjects.equals(saved)) {
                    matches.add(code);
                }
            }
        }

        if (matches.size() != 1) return null;
        String resolved = matches.get(0);
        jdbc.update("UPDATE HoSo SET to_hop=? WHERE ho_so_id=?", resolved, hoSoId);
        return resolved;
    }

    private String normalizeSubject(String value) {
        if (value == null) return "";
        String s = value.trim().replaceAll("\\s+", " ").toLowerCase(Locale.ROOT);
        // Chuẩn hóa dấu tiếng Việt để "Vật lý", "Vat ly" và "Vật lí"
        // không làm sai việc đối chiếu tổ hợp.
        s = Normalizer.normalize(s, Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "");
        s = s.replace("đ", "d");
        return s;
    }

    private String safe(String s) { return s == null || s.isBlank() ? "lỗi không xác định" : s; }
}
