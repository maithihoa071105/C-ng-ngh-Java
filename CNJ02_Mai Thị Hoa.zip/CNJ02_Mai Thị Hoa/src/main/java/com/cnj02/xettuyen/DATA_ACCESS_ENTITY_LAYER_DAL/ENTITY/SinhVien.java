package com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY;
import jakarta.persistence.*; import java.time.LocalDate;
@Entity @Table(name="SinhVien") public class SinhVien {
@Id @GeneratedValue(strategy=GenerationType.IDENTITY) @Column(name="sinh_vien_id") private Integer sinhVienId;
@Column(name="user_id",nullable=false,unique=true) private Integer userId;
@Column(name="ho_ten",nullable=false) private String hoTen; @Column(name="cccd",nullable=false,unique=true) private String cccd;
@Column(name="ngay_sinh") private LocalDate ngaySinh; @Column(name="gioi_tinh") private String gioiTinh;
@Column(name="dia_chi") private String diaChi; @Column(name="truong_thpt") private String truongThpt; @Column(name="anh_dai_dien") private String anhDaiDien; @Lob @Column(name="anh_dai_dien_data") private byte[] anhDaiDienData; @Column(name="anh_dai_dien_mime") private String anhDaiDienMime;
public SinhVien(){} public Integer getSinhVienId(){return sinhVienId;} public void setSinhVienId(Integer v){sinhVienId=v;}
public Integer getUserId(){return userId;} public void setUserId(Integer v){userId=v;} public String getHoTen(){return hoTen;} public void setHoTen(String v){hoTen=v;}
public String getCccd(){return cccd;} public void setCccd(String v){cccd=v;} public LocalDate getNgaySinh(){return ngaySinh;} public void setNgaySinh(LocalDate v){ngaySinh=v;}
public String getGioiTinh(){return gioiTinh;} public void setGioiTinh(String v){gioiTinh=v;} public String getDiaChi(){return diaChi;} public void setDiaChi(String v){diaChi=v;}
public String getTruongThpt(){return truongThpt;} public void setTruongThpt(String v){truongThpt=v;} public String getAnhDaiDien(){return anhDaiDien;} public void setAnhDaiDien(String v){anhDaiDien=v;} public byte[] getAnhDaiDienData(){return anhDaiDienData;} public void setAnhDaiDienData(byte[] v){anhDaiDienData=v;} public String getAnhDaiDienMime(){return anhDaiDienMime;} public void setAnhDaiDienMime(String v){anhDaiDienMime=v;}}
