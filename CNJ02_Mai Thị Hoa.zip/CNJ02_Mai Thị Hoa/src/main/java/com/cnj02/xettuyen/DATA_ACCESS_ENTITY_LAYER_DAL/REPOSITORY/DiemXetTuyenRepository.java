package com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.REPOSITORY;
import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.DiemXetTuyen; import org.springframework.data.jpa.repository.JpaRepository;
public interface DiemXetTuyenRepository extends JpaRepository<DiemXetTuyen,Integer>{  }
