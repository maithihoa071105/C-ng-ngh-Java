package com.cnj02.xettuyen.PRESENTATION_LAYER_UI.CONTROLLER;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/** Các alias ổn định cho WebView/Desktop, tránh lỗi 404 khi điều hướng. */
@Controller
public class CompatibilityController {
    @GetMapping("/nhat-ky")
    public String nhatKyAlias() { return "redirect:/admin/nhat-ky"; }
}
