package com.cnj02.xettuyen.PRESENTATION_LAYER_UI.CONTROLLER;

import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AccessErrorController {
    @GetMapping("/403")
    public String forbidden(HttpSession session, Model model) {
        User u = (User) session.getAttribute("currentUser");
        model.addAttribute("currentUser", u);
        model.addAttribute("user", u);
        return "ERROR/403";
    }
}
