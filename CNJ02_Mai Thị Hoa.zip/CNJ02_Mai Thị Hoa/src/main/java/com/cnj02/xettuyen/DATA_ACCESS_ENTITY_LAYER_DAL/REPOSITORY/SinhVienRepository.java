package com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.REPOSITORY;
import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.SinhVien; import org.springframework.data.jpa.repository.JpaRepository;
public interface SinhVienRepository extends JpaRepository<SinhVien,Integer>{ boolean existsByCccd(String cccd); java.util.Optional<SinhVien> findByUserId(Integer userId); }
