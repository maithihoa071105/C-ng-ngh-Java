package com.cnj02.xettuyen.PRESENTATION_LAYER_UI.ADMIN_CONTROLLER;

import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller @RequestMapping("/admin")
public class NguyenVongAdminController {
    private final JdbcTemplate jdbc; public NguyenVongAdminController(JdbcTemplate jdbc){this.jdbc=jdbc;}
    private boolean ok(HttpSession s){User u=(User)s.getAttribute("currentUser");return u!=null&&Integer.valueOf(2).equals(u.getRoleId());}
    private void common(Model m){m.addAttribute("majors",jdbc.queryForList("SELECT nganh_id,ma_nganh,ten_nganh FROM Nganh WHERE trang_thai='DANG_TUYEN_SINH' ORDER BY ten_nganh"));}
    @GetMapping("/nguyen-vong") public String list(HttpSession s,Model m){if(!ok(s))return "redirect:/403";m.addAttribute("items",items());common(m);m.addAttribute("form",new Form());return "VIEW/ADMIN/nguyen-vong";}
    @GetMapping("/nguyen-vong/edit/{id}") public String edit(HttpSession s,@PathVariable Integer id,Model m){if(!ok(s))return "redirect:/403";m.addAttribute("items",items());common(m);var r=jdbc.queryForList("SELECT nguyen_vong_id,ho_so_id,nganh_id,thu_tu_nguyen_vong,trang_thai FROM NguyenVong WHERE nguyen_vong_id=?",id);if(r.isEmpty())return "redirect:/admin/nguyen-vong?error=notfound";var x=r.get(0);Form f=new Form();f.id=((Number)x.get("nguyen_vong_id")).intValue();f.hoSoId=((Number)x.get("ho_so_id")).intValue();f.nganhId=((Number)x.get("nganh_id")).intValue();f.order=((Number)x.get("thu_tu_nguyen_vong")).intValue();f.status=String.valueOf(x.get("trang_thai"));m.addAttribute("form",f);return "VIEW/ADMIN/nguyen-vong";}
    private java.util.List<java.util.Map<String,Object>> items(){return jdbc.queryForList("SELECT nv.nguyen_vong_id nguyenVongId,nv.ho_so_id hoSoId,nv.nganh_id nganhId,nv.thu_tu_nguyen_vong thuTuNguyenVong,COALESCE(nv.trang_thai,'CHO_XET') trangThai,n.ma_nganh,n.ten_nganh,sv.ho_ten FROM NguyenVong nv JOIN HoSo hs ON hs.ho_so_id=nv.ho_so_id JOIN SinhVien sv ON sv.sinh_vien_id=hs.sinh_vien_id LEFT JOIN Nganh n ON n.nganh_id=nv.nganh_id ORDER BY nv.ho_so_id,nv.thu_tu_nguyen_vong,nv.nguyen_vong_id");}
    @PostMapping("/nguyen-vong/save") public String save(HttpSession s,@RequestParam(required=false) Integer nguyenVongId,@RequestParam Integer hoSoId,@RequestParam Integer nganhId,@RequestParam Integer thuTuNguyenVong,@RequestParam(defaultValue="CHO_XET") String trangThai){if(!ok(s))return "redirect:/403";if(nguyenVongId==null)jdbc.update("INSERT INTO NguyenVong(ho_so_id,nganh_id,thu_tu_nguyen_vong,trang_thai) VALUES(?,?,?,?)",hoSoId,nganhId,thuTuNguyenVong,trangThai);else jdbc.update("UPDATE NguyenVong SET ho_so_id=?,nganh_id=?,thu_tu_nguyen_vong=?,trang_thai=? WHERE nguyen_vong_id=?",hoSoId,nganhId,thuTuNguyenVong,trangThai,nguyenVongId);return "redirect:/admin/nguyen-vong?success=saved";}
    @PostMapping("/nguyen-vong/delete/{id}") public String del(HttpSession s,@PathVariable Integer id){if(!ok(s))return "redirect:/403";jdbc.update("DELETE FROM NguyenVong WHERE nguyen_vong_id=?",id);return "redirect:/admin/nguyen-vong?success=deleted";}
    public static class Form{Integer id,hoSoId,nganhId,order=1;String status="CHO_XET";public Integer getId(){return id;}public Integer getHoSoId(){return hoSoId;}public Integer getNganhId(){return nganhId;}public Integer getOrder(){return order;}public String getStatus(){return status;}}
}
