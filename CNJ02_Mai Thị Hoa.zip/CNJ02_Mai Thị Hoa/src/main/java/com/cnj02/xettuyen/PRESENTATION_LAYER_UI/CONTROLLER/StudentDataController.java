package com.cnj02.xettuyen.PRESENTATION_LAYER_UI.CONTROLLER;

import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Map;

@Controller
public class StudentDataController {
    private final JdbcTemplate jdbc;
    public StudentDataController(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    private User guard(HttpSession session) {
        User u=(User)session.getAttribute("currentUser");
        return u!=null && Integer.valueOf(3).equals(u.getRoleId()) ? u : null;
    }

    @GetMapping("/nguyen-vong")
    public String aspirations(HttpSession session, Model model) {
        User u=guard(session); if(u==null) return "redirect:/login";
        List<Map<String,Object>> rows=jdbc.queryForList(
                "SELECT hs.ho_so_id,COALESCE(hs.trang_thai,'CHO_DUYET') ho_so_trang_thai,nv.nguyen_vong_id,nv.thu_tu_nguyen_vong, " +
                "COALESCE(nv.trang_thai,'CHO_XET') trang_thai,nv.nganh_id,COALESCE(n.ma_nganh,CONCAT('NGANH#',nv.nganh_id)) ma_nganh,COALESCE(n.ten_nganh,'Ngành tuyển sinh') ten_nganh " +
                "FROM NguyenVong nv JOIN HoSo hs ON hs.ho_so_id=nv.ho_so_id JOIN SinhVien sv ON sv.sinh_vien_id=hs.sinh_vien_id " +
                "LEFT JOIN Nganh n ON n.nganh_id=nv.nganh_id WHERE sv.user_id=? ORDER BY hs.ho_so_id DESC,nv.thu_tu_nguyen_vong",u.getUserId());
        model.addAttribute("user",u); model.addAttribute("currentUser",u); model.addAttribute("tabId","theodoi"); model.addAttribute("items",rows);
        return "VIEW/USER/nguyen-vong";
    }

    @GetMapping("/minh-chung")
    public String evidence(HttpSession session, Model model) {
        User u=guard(session); if(u==null) return "redirect:/login";
        List<Map<String,Object>> rows=jdbc.queryForList(
                "SELECT mc.minh_chung_id,mc.ho_so_id,COALESCE(mc.ten_minh_chung,'Minh chứng hồ sơ') ten_minh_chung, " +
                "COALESCE(mc.loai_minh_chung,'FILE') loai_minh_chung,COALESCE(mc.mime_type,'application/octet-stream') mime_type, " +
                "COALESCE(mc.kich_thuoc,0) kich_thuoc,COALESCE(hs.trang_thai,'CHO_DUYET') trang_thai " +
                "FROM MinhChung mc JOIN HoSo hs ON hs.ho_so_id=mc.ho_so_id JOIN SinhVien sv ON sv.sinh_vien_id=hs.sinh_vien_id " +
                "WHERE sv.user_id=? ORDER BY mc.ho_so_id DESC,mc.minh_chung_id",u.getUserId());
        model.addAttribute("user",u); model.addAttribute("currentUser",u); model.addAttribute("tabId","theodoi"); model.addAttribute("items",rows);
        return "VIEW/USER/minh-chung";
    }

    @PostMapping("/minh-chung/delete/{id}")
    public String deleteEvidence(@PathVariable int id,HttpSession session,RedirectAttributes ra) {
        User u=guard(session); if(u==null) return "redirect:/login";
        Integer count=jdbc.queryForObject("SELECT COUNT(*) FROM MinhChung mc JOIN HoSo hs ON hs.ho_so_id=mc.ho_so_id JOIN SinhVien sv ON sv.sinh_vien_id=hs.sinh_vien_id WHERE mc.minh_chung_id=? AND sv.user_id=? AND hs.trang_thai IN ('CHO_DUYET','TIEP_NHAN','DANG_XU_LY')",Integer.class,id,u.getUserId());
        if(count==null||count==0){ra.addFlashAttribute("error","Minh chứng không tồn tại hoặc hồ sơ đã được chốt xử lý.");return "redirect:/minh-chung";}
        jdbc.update("DELETE FROM MinhChung WHERE minh_chung_id=?",id);
        ra.addFlashAttribute("success","Đã xóa minh chứng. Bạn có thể tải lại file trong chức năng cập nhật hồ sơ.");
        return "redirect:/minh-chung";
    }
}
