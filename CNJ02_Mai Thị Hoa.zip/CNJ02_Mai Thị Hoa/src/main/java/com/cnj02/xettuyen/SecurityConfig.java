package com.cnj02.xettuyen;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    /**
     * BCrypt dùng để mã hóa và kiểm tra mật khẩu.
     * Mật khẩu KHÔNG được lưu dạng plaintext trong database.
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(10);
    }

    /**
     * Cấu hình bảo mật.
     *
     * Hiện tại cho phép truy cập các URL để phục vụ quá trình
     * phát triển hệ thống. Việc phân quyền được xử lý bằng
     * Session + Controller/Filter ở các bước tiếp theo.
     */
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        http
            // Trong giai đoạn phát triển có thể tắt CSRF
            .csrf(csrf -> csrf.disable())

            .authorizeHttpRequests(auth -> auth
                .requestMatchers(
                    "/login",
                    "/register",
                    "/css/**",
                    "/js/**",
                    "/images/**",
                    "/error"
                ).permitAll()

                // Các URL còn lại tạm thời cho phép
                .anyRequest().permitAll()
            );

        return http.build();
    }
}