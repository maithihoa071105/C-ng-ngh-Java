package com.cnj02.xettuyen.BUSINESS_LOGIC_LAYER_BUS.SERVICE;

import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.*;
import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.REPOSITORY.*;
import org.springframework.data.domain.Sort;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.jdbc.core.JdbcTemplate;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

@Service
public class AdminDataService {
    final UserRepository userRepo;
    final NganhRepository nganhRepo;
    final PhuongThucXetTuyenRepository ptRepo;
    final ChiTieuRepository ctRepo;
    final HoSoRepository hsRepo;
    final SinhVienRepository svRepo;
    final MinhChungRepository mcRepo;
    final NguyenVongRepository nvRepo;
    final DiemXetTuyenRepository diemRepo;
    final KetQuaRepository kqRepo;
    final HoSoLogRepository logRepo;
    final ThongBaoRepository tbRepo;
    final NguoiNhanThongBaoRepository nnRepo;
    final DashboardRepository dash;
    final PasswordEncoder encoder;
    final JdbcTemplate jdbc;

    public AdminDataService(UserRepository u, NganhRepository n, PhuongThucXetTuyenRepository p,
                            ChiTieuRepository c, HoSoRepository h, SinhVienRepository s,
                            MinhChungRepository m, NguyenVongRepository nv, DiemXetTuyenRepository d,
                            KetQuaRepository k, HoSoLogRepository l, ThongBaoRepository t,
                            NguoiNhanThongBaoRepository nn, DashboardRepository dr, PasswordEncoder e, JdbcTemplate jdbcTemplate) {
        userRepo=u; nganhRepo=n; ptRepo=p; ctRepo=c; hsRepo=h; svRepo=s; mcRepo=m; nvRepo=nv;
        diemRepo=d; kqRepo=k; logRepo=l; tbRepo=t; nnRepo=nn; dash=dr; encoder=e; jdbc=jdbcTemplate;
    }

    public List<User> users(){return userRepo.findAll(Sort.by(Sort.Direction.ASC,"userId"));}
    public Nganh getNganh(Integer id){return nganhRepo.findById(id).orElseThrow();}
    public List<Nganh> nganh(){return nganhRepo.findAll(Sort.by(Sort.Direction.ASC,"nganhId"));}
    public List<PhuongThucXetTuyen> phuongThuc(){return ptRepo.findAll(Sort.by(Sort.Direction.ASC,"phuongThucId"));}
    public List<ChiTieu> chiTieu(){return ctRepo.findAll(Sort.by(Sort.Direction.ASC,"chiTieuId"));}
    public List<HoSo> hoSo(){return hsRepo.findAll(Sort.by(Sort.Direction.ASC,"hoSoId"));}
    public List<SinhVien> sinhVien(){return svRepo.findAll(Sort.by(Sort.Direction.ASC,"sinhVienId"));}
    public List<KetQua> ketQua(){return kqRepo.findAll(Sort.by(Sort.Direction.ASC,"ketQuaId"));}
    public List<MinhChung> minhChung(){return mcRepo.findAll(Sort.by(Sort.Direction.ASC,"minhChungId"));}
    public List<NguyenVong> nguyenVong(){return nvRepo.findAll(Sort.by(Sort.Direction.ASC,"nguyenVongId"));}
    public List<DiemXetTuyen> diem(){return diemRepo.findAll(Sort.by(Sort.Direction.ASC,"diemId"));}
    public List<NguoiNhanThongBao> nguoiNhan(){return nnRepo.findAll(Sort.by(Sort.Direction.ASC,"id"));}
    public List<ThongBao> thongBao(){return tbRepo.findAll(Sort.by(Sort.Direction.ASC,"thongBaoId"));}

    public Map<String,Object> dashboard(){
        Map<String,Object> m=new LinkedHashMap<>();

        long users=number(jdbc.queryForObject("SELECT COUNT(*) FROM `User`", Number.class));
        final int currentRecruitmentYear = 2026;
        final int currentMonth = (LocalDate.now().getYear() == currentRecruitmentYear) ? LocalDate.now().getMonthValue() : 10;
        long hoSo=number(jdbc.queryForObject("SELECT COUNT(*) FROM HoSo WHERE YEAR(ngay_nop)=?", Number.class, currentRecruitmentYear));
        long nganh=number(jdbc.queryForObject("SELECT COUNT(*) FROM Nganh WHERE trang_thai='DANG_TUYEN_SINH'", Number.class));
        long chiTieu=number(jdbc.queryForObject(
                "SELECT COALESCE(SUM(ct.so_luong),0) FROM ChiTieu ct " +
                "JOIN Nganh n ON n.nganh_id=ct.nganh_id AND n.trang_thai='DANG_TUYEN_SINH' " +
                "JOIN PhuongThucXetTuyen p ON p.phuong_thuc_id=ct.phuong_thuc_id AND p.trang_thai='ACTIVE' " +
                "WHERE ct.nam_hoc=?", Number.class, currentRecruitmentYear));

        m.put("users",users); m.put("hoso",hoSo); m.put("nganh",nganh); m.put("chitieu",chiTieu);
        m.put("hoSo",hoSo); m.put("chiTieu",chiTieu);

        int dashboardYear=currentRecruitmentYear;
        List<Map<String,Object>> statusStats=jdbc.queryForList(
                "SELECT trang_thai,COUNT(*) so_luong FROM HoSo WHERE YEAR(ngay_nop)=? GROUP BY trang_thai ORDER BY COUNT(*) DESC", dashboardYear);
        m.put("statusStats",statusStats);
        Map<Integer,Long> monthMap=new HashMap<>();
        for(Map<String,Object> r: jdbc.queryForList(
                "SELECT MONTH(ngay_nop) thang,COUNT(*) so_luong FROM HoSo WHERE YEAR(ngay_nop)=? GROUP BY MONTH(ngay_nop)", dashboardYear)) {
            monthMap.put(((Number)r.get("thang")).intValue(), number(r.get("so_luong")));
        }
        List<Map<String,Object>> monthlyStats=new ArrayList<>();
        for(int month=1;month<=currentMonth;month++){
            Map<String,Object> r=new LinkedHashMap<>();
            r.put("thang",String.format("%02d",month));
            r.put("so_luong",monthMap.getOrDefault(month,0L));
            monthlyStats.add(r);
        }
        m.put("dashboardYear",dashboardYear); m.put("monthlyStats",monthlyStats);
        m.put("facultyCount", jdbc.queryForObject("SELECT COUNT(DISTINCT khoa) FROM Nganh WHERE trang_thai='DANG_TUYEN_SINH'", Long.class));

        m.put("methodStats",jdbc.queryForList(
                "SELECT pt.ten_phuong_thuc,COUNT(hs.ho_so_id) so_luong " +
                "FROM PhuongThucXetTuyen pt LEFT JOIN HoSo hs ON hs.phuong_thuc_id=pt.phuong_thuc_id AND YEAR(hs.ngay_nop)=? " +
                "WHERE pt.trang_thai='ACTIVE' GROUP BY pt.phuong_thuc_id,pt.ten_phuong_thuc " +
                "ORDER BY so_luong DESC", dashboardYear));

        m.put("majorStats",jdbc.queryForList(
                "SELECT n.ten_nganh,COUNT(DISTINCT hs.ho_so_id) so_luong " +
                "FROM Nganh n LEFT JOIN NguyenVong nv ON nv.nganh_id=n.nganh_id AND nv.thu_tu_nguyen_vong=1 " +
                "LEFT JOIN HoSo hs ON hs.ho_so_id=nv.ho_so_id AND YEAR(hs.ngay_nop)=? " +
                "WHERE n.trang_thai='DANG_TUYEN_SINH' GROUP BY n.nganh_id,n.ten_nganh " +
                "ORDER BY so_luong DESC,n.nganh_id LIMIT 10", dashboardYear));

        Map<String,Object> summary=jdbc.queryForMap(
                "SELECT COALESCE(SUM(CASE WHEN trang_thai_ket_qua='TRUNG_TUYEN' THEN 1 ELSE 0 END),0) admitted, " +
                "COALESCE(SUM(CASE WHEN trang_thai_ket_qua IN ('TRUNG_TUYEN','KHONG_TRUNG_TUYEN') THEN 1 ELSE 0 END),0) decided " +
                "FROM KetQua kq JOIN HoSo h ON h.ho_so_id=kq.ho_so_id WHERE YEAR(h.ngay_nop)=?", dashboardYear);
        long admitted=number(summary.get("admitted"));
        long decided=number(summary.get("decided"));
        double admissionRate=decided==0?0:Math.round(admitted*10000.0/decided)/100.0;
        m.put("admittedCount",admitted); m.put("decidedCount",decided); m.put("admissionRate",admissionRate);
        // Tỷ lệ nhập học được tính trực tiếp từ NhapHoc, dùng chung cho Dashboard Admin và Cán bộ.
        long totalEnrollmentEligible=number(jdbc.queryForObject("SELECT COUNT(DISTINCT nh.ho_so_id) FROM NhapHoc nh JOIN HoSo h ON h.ho_so_id=nh.ho_so_id JOIN KetQua kq ON kq.ket_qua_id=nh.ket_qua_id WHERE YEAR(h.ngay_nop)=? AND UPPER(TRIM(kq.trang_thai_ket_qua)) IN ('TRUNG_TUYEN','DA_TRUNG_TUYEN')", Number.class, currentRecruitmentYear));
        long enrollmentPending=number(jdbc.queryForObject("SELECT COUNT(*) FROM NhapHoc nh JOIN HoSo h ON h.ho_so_id=nh.ho_so_id WHERE YEAR(h.ngay_nop)=? AND nh.trang_thai='CHO_CAN_BO_XU_LY'", Number.class, currentRecruitmentYear));
        long enrolled=number(jdbc.queryForObject("SELECT COUNT(*) FROM NhapHoc nh JOIN HoSo h ON h.ho_so_id=nh.ho_so_id WHERE YEAR(h.ngay_nop)=? AND nh.trang_thai='DA_NHAP_HOC'", Number.class, currentRecruitmentYear));
        long enrollmentRejected=number(jdbc.queryForObject("SELECT COUNT(*) FROM NhapHoc nh JOIN HoSo h ON h.ho_so_id=nh.ho_so_id WHERE YEAR(h.ngay_nop)=? AND nh.trang_thai='TU_CHOI'", Number.class, currentRecruitmentYear));
        double enrollmentRate=totalEnrollmentEligible==0?0:Math.round(enrolled*10000.0/totalEnrollmentEligible)/100.0;
        m.put("totalEnrollmentEligible",totalEnrollmentEligible);
        m.put("enrollmentPending",enrollmentPending);
        m.put("enrolledCount",enrolled);
        m.put("enrollmentRejected",enrollmentRejected);
        m.put("enrollmentRate",enrollmentRate);

        List<Map<String,Object>> dashboardRows=new ArrayList<>();
        String rowSql="SELECT n.ten_nganh,n.ma_nganh,n.khoa, " +
                "COALESCE((SELECT SUM(ct.so_luong) FROM ChiTieu ct " +
                "JOIN PhuongThucXetTuyen p ON p.phuong_thuc_id=ct.phuong_thuc_id AND p.trang_thai='ACTIVE' " +
                "WHERE ct.nganh_id=n.nganh_id AND ct.nam_hoc="+dashboardYear+"),0) chi_tieu, " +
                "COUNT(DISTINCT hs.ho_so_id) ho_so, " +
                "COUNT(DISTINCT CASE WHEN kq.trang_thai_ket_qua='TRUNG_TUYEN' THEN kq.ho_so_id END) da_duyet " +
                "FROM Nganh n " +
                "LEFT JOIN NguyenVong nv ON nv.nganh_id=n.nganh_id AND nv.thu_tu_nguyen_vong=1 " +
                "LEFT JOIN HoSo hs ON hs.ho_so_id=nv.ho_so_id AND YEAR(hs.ngay_nop)="+dashboardYear+" " +
                "LEFT JOIN KetQua kq ON kq.ho_so_id=hs.ho_so_id AND kq.nganh_id=nv.nganh_id " +
                "WHERE n.trang_thai='DANG_TUYEN_SINH' " +
                "GROUP BY n.nganh_id,n.ten_nganh,n.ma_nganh,n.khoa ORDER BY ho_so DESC,n.nganh_id";
        for(Map<String,Object> r:jdbc.queryForList(rowSql)){
            long quota=number(r.get("chi_tieu"));
            long apps=number(r.get("ho_so"));
            long acc=number(r.get("da_duyet"));
            double rate=apps==0?0:Math.round(acc*10000.0/apps)/100.0;
            double share=hoSo==0?0:Math.round(apps*10000.0/hoSo)/100.0;
            Map<String,Object> x=new LinkedHashMap<>();
            x.put("ten_nganh",r.get("ten_nganh")); x.put("ma_nganh",r.get("ma_nganh")); x.put("khoa",r.get("khoa"));
            x.put("chi_tieu",quota); x.put("ho_so",apps); x.put("da_duyet",acc); x.put("ty_le",rate); x.put("ty_le_nganh",share);
            x.put("xep_loai",apps==0?"CHƯA TUYỂN SINH":"ĐANG TUYỂN");
            dashboardRows.add(x);
        }
        // Ngành hot được xác định động: ngành có nhiều hồ sơ NV1 nhất trong kỳ hiện tại.
        long maxApps=dashboardRows.stream().mapToLong(x->number(x.get("ho_so"))).max().orElse(0);
        if(maxApps>0){
            for(Map<String,Object> x:dashboardRows){
                if(number(x.get("ho_so"))==maxApps) x.put("xep_loai","NGÀNH HOT");
            }
        }
        m.put("dashboardRows",dashboardRows);

        List<Map<String,Object>> facultyStats=new ArrayList<>();
        for(Map<String,Object> r:jdbc.queryForList(
                "SELECT n.khoa,COUNT(DISTINCT hs.ho_so_id) ho_so, " +
                "COUNT(DISTINCT CASE WHEN kq.trang_thai_ket_qua='TRUNG_TUYEN' THEN kq.ho_so_id END) trung_tuyen " +
                "FROM Nganh n LEFT JOIN NguyenVong nv ON nv.nganh_id=n.nganh_id AND nv.thu_tu_nguyen_vong=1 " +
                "LEFT JOIN HoSo hs ON hs.ho_so_id=nv.ho_so_id AND YEAR(hs.ngay_nop)="+dashboardYear+" " +
                "LEFT JOIN KetQua kq ON kq.ho_so_id=hs.ho_so_id AND kq.nganh_id=nv.nganh_id " +
                "WHERE n.trang_thai='DANG_TUYEN_SINH' GROUP BY n.khoa ORDER BY ho_so DESC,n.khoa")){
            long apps=number(r.get("ho_so")); long acc=number(r.get("trung_tuyen"));
            Map<String,Object> x=new LinkedHashMap<>(); x.put("khoa",r.get("khoa")); x.put("ho_so",apps); x.put("trung_tuyen",acc);
            x.put("ty_le_khoa",hoSo==0?0:Math.round(apps*10000.0/hoSo)/100.0);
            x.put("ty_le_trung_tuyen",apps==0?0:Math.round(acc*10000.0/apps)/100.0);
            facultyStats.add(x);
        }
        m.put("facultyStats",facultyStats);

        // Thống kê 5 năm: 2026 là kỳ đang tuyển sinh; 2027-2030 chỉ là kế hoạch/chỉ tiêu,
        // chưa có hồ sơ nếu chưa tới kỳ. Khi có hồ sơ thật phát sinh trong MySQL, số liệu tự cập nhật.
        List<Map<String,Object>> yearStats=new ArrayList<>();
        for(int y=2026;y<=2030;y++){
            // Chỉ năm đang tuyển mới đọc dữ liệu nghiệp vụ. Các năm tương lai chỉ là kế hoạch.
            Long apps=0L, decidedYear=0L, acc=0L;
            if(y==currentRecruitmentYear){
                apps=jdbc.queryForObject("SELECT COUNT(*) FROM HoSo WHERE YEAR(ngay_nop)=?",Long.class,y);
                decidedYear=jdbc.queryForObject("SELECT COUNT(DISTINCT kq.ho_so_id) FROM KetQua kq JOIN HoSo h ON h.ho_so_id=kq.ho_so_id WHERE YEAR(h.ngay_nop)=? AND kq.trang_thai_ket_qua IN ('TRUNG_TUYEN','KHONG_TRUNG_TUYEN')",Long.class,y);
                acc=jdbc.queryForObject("SELECT COUNT(DISTINCT kq.ho_so_id) FROM KetQua kq JOIN HoSo h ON h.ho_so_id=kq.ho_so_id WHERE YEAR(h.ngay_nop)=? AND kq.trang_thai_ket_qua='TRUNG_TUYEN'",Long.class,y);
            }
            Long quota=jdbc.queryForObject("SELECT COALESCE(SUM(so_luong),0) FROM ChiTieu WHERE nam_hoc=?",Long.class,y);
            apps=apps==null?0:apps; decidedYear=decidedYear==null?0:decidedYear; acc=acc==null?0:acc; quota=quota==null?0:quota;
            Map<String,Object> x=new LinkedHashMap<>();
            x.put("nam_hoc",y); x.put("ho_so",apps); x.put("da_xet",decidedYear); x.put("trung_tuyen",acc); x.put("chi_tieu",quota);
            x.put("ty_le",decidedYear==0?0:Math.round(acc*10000.0/decidedYear)/100.0);
            x.put("trang_thai", y==currentRecruitmentYear ? "ĐANG TUYỂN SINH" : "CHƯA ĐẾN KỲ TUYỂN SINH");
            yearStats.add(x);
        }
        m.put("currentRecruitmentYear",currentRecruitmentYear);
        m.put("yearStats",yearStats);

        // Gom ngành theo từng khoa để thống kê không bị dàn trải, mỗi khoa chỉ hiện các ngành thuộc khoa đó.
        List<Map<String,Object>> facultySections=new ArrayList<>();
        LinkedHashMap<String,List<Map<String,Object>>> grouped=new LinkedHashMap<>();
        for(Map<String,Object> r:dashboardRows){
            String khoa=String.valueOf(r.get("khoa"));
            grouped.computeIfAbsent(khoa,k->new ArrayList<>()).add(r);
        }
        for(Map.Entry<String,List<Map<String,Object>>> e:grouped.entrySet()){
            long totalApps=0,totalAdmitted=0,totalQuota=0;
            for(Map<String,Object> r:e.getValue()){
                totalApps+=number(r.get("ho_so")); totalAdmitted+=number(r.get("da_duyet")); totalQuota+=number(r.get("chi_tieu"));
            }
            Map<String,Object> f=new LinkedHashMap<>();
            f.put("khoa",e.getKey()); f.put("majors",e.getValue()); f.put("ho_so",totalApps); f.put("trung_tuyen",totalAdmitted); f.put("chi_tieu",totalQuota);
            f.put("ty_le_trung_tuyen",totalApps==0?0:Math.round(totalAdmitted*10000.0/totalApps)/100.0);
            facultySections.add(f);
        }
        m.put("facultySections",facultySections);

        String hotMajor="Chưa có dữ liệu", noRecruitMajor="Chưa có dữ liệu";
        for(Map<String,Object> r:dashboardRows){ if("NGÀNH HOT".equals(r.get("xep_loai"))){hotMajor=String.valueOf(r.get("ten_nganh"));break;} }
        for(Map<String,Object> r:dashboardRows){ if("CHƯA TUYỂN SINH".equals(r.get("xep_loai"))){noRecruitMajor=String.valueOf(r.get("ten_nganh"));break;} }
        m.put("hotMajor",hotMajor); m.put("noRecruitMajor",noRecruitMajor);
        return m;
    }

    private long number(Object o){return o==null?0:((Number)o).longValue();}

    @Transactional public User saveUser(User u,String pass){
        if(pass!=null&&!pass.isBlank()) u.setPassword(encoder.encode(pass.trim()));
        else if(u.getUserId()==null&&(u.getPassword()==null||u.getPassword().isBlank())) u.setPassword(encoder.encode("123456"));
        if(u.getRoleId()==null)u.setRoleId(3);
        if(u.getStatus()==null||u.getStatus().isBlank())u.setStatus("ACTIVE");
        return userRepo.save(u);
    }
    public User getUser(Integer id){return userRepo.findById(id).orElseThrow();}
    public String hotMajorCode(){
        List<Map<String,Object>> rows=jdbc.queryForList("SELECT n.ma_nganh FROM Nganh n LEFT JOIN NguyenVong nv ON nv.nganh_id=n.nganh_id AND nv.thu_tu_nguyen_vong=1 LEFT JOIN HoSo hs ON hs.ho_so_id=nv.ho_so_id AND YEAR(hs.ngay_nop)=2026 WHERE n.trang_thai='DANG_TUYEN_SINH' GROUP BY n.nganh_id,n.ma_nganh ORDER BY COUNT(hs.ho_so_id) DESC,n.nganh_id LIMIT 1");
        return rows.isEmpty()?null:String.valueOf(rows.get(0).get("ma_nganh"));
    }
    @Transactional public void deleteUser(Integer id){userRepo.deleteById(id);}
    @Transactional public Nganh saveNganh(Nganh x){return nganhRepo.save(x);}
    @Transactional public void deleteNganh(Integer id){nganhRepo.deleteById(id);}
    @Transactional public PhuongThucXetTuyen savePt(PhuongThucXetTuyen x){return ptRepo.save(x);}
    @Transactional public void deletePt(Integer id){ptRepo.deleteById(id);}
    @Transactional public ChiTieu saveCt(ChiTieu x){return ctRepo.save(x);}
    @Transactional public void deleteCt(Integer id){ctRepo.deleteById(id);}
    @Transactional public HoSo saveHs(HoSo x){if(x.getNgayNop()==null)x.setNgayNop(LocalDateTime.now());if(x.getTrangThai()==null)x.setTrangThai("CHO_DUYET");return hsRepo.save(x);}
    @Transactional public void deleteHs(Integer id){hsRepo.deleteById(id);}
    @Transactional public SinhVien saveSv(SinhVien x){return svRepo.save(x);}
    @Transactional public void deleteSv(Integer id){svRepo.deleteById(id);}
    @Transactional public ThongBao saveTb(ThongBao x){if(x.getNgayTao()==null)x.setNgayTao(LocalDateTime.now());return tbRepo.save(x);}
    @Transactional public void deleteTb(Integer id){tbRepo.deleteById(id);}
    @Transactional public MinhChung saveMc(MinhChung x){return mcRepo.save(x);}
    @Transactional public void deleteMc(Integer id){mcRepo.deleteById(id);}
    @Transactional public NguyenVong saveNv(NguyenVong x){if(x.getTrangThai()==null)x.setTrangThai("CHO_XET");return nvRepo.save(x);}
    @Transactional public void deleteNv(Integer id){nvRepo.deleteById(id);}
    @Transactional public DiemXetTuyen saveDiem(DiemXetTuyen x){return diemRepo.save(x);}
    @Transactional public void deleteDiem(Integer id){diemRepo.deleteById(id);}
    @Transactional public KetQua saveKq(KetQua x){x.setNgayCapNhat(LocalDateTime.now());return kqRepo.save(x);}
    @Transactional public void deleteKq(Integer id){kqRepo.deleteById(id);}
    @Transactional public void updateStatus(Integer id,String status,String note,Integer uid){
        HoSo h=hsRepo.findById(id).orElseThrow(); h.setTrangThai(status); h.setGhiChu(note); hsRepo.save(h);
        if(uid!=null){HoSoLog l=new HoSoLog();l.setHoSoId(id);l.setUserId(uid);l.setHanhDong("Đổi trạng thái: "+status);l.setChiTiet(note);l.setThoiGian(LocalDateTime.now());logRepo.save(l);}
    }
}
