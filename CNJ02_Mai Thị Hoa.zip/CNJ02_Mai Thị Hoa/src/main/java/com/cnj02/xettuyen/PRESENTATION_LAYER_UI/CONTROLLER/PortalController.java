package com.cnj02.xettuyen.PRESENTATION_LAYER_UI.CONTROLLER;

import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.User;
import com.cnj02.xettuyen.UTILS.FileUtil;
import jakarta.servlet.http.HttpSession;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.text.Normalizer;
import java.util.*;

@Controller
public class PortalController {
    private final JdbcTemplate jdbc;

    public PortalController(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    private User user(HttpSession session) { return (User) session.getAttribute("currentUser"); }

    private String guard(HttpSession session, Model model, String tab) {
        User u = user(session);
        if (u == null) return "redirect:/login";
        if (!Integer.valueOf(3).equals(u.getRoleId())) {
            return Integer.valueOf(1).equals(u.getRoleId()) || Integer.valueOf(2).equals(u.getRoleId()) ? "redirect:/admin/dashboard" : "redirect:/403";
        }
        model.addAttribute("user", u);
        model.addAttribute("currentUser", u);
        model.addAttribute("tabId", tab);
        return null;
    }

    @GetMapping("/ho-so")
    public String hoSo(HttpSession session, Model model) {
        String g = guard(session, model, "hoso"); if (g != null) return g;
        int uid = user(session).getUserId();
        List<Map<String,Object>> applications = jdbc.queryForList(
            "SELECT hs.ho_so_id AS ho_so_id, hs.ngay_nop AS ngay_nop, COALESCE(hs.trang_thai,'CHO_DUYET') AS trang_thai, COALESCE(hs.ghi_chu,'Hồ sơ nộp trực tuyến') AS ghi_chu, " +
            "COALESCE(hs.to_hop,'Không áp dụng') AS to_hop, " +
            "COALESCE(pt.ten_phuong_thuc,CONCAT('Phương thức #',hs.phuong_thuc_id)) AS ten_phuong_thuc, " +
            "COALESCE(pt.ma_phuong_thuc,CONCAT('PT#',hs.phuong_thuc_id)) AS ma_phuong_thuc " +
            "FROM HoSo hs JOIN SinhVien sv ON sv.sinh_vien_id=hs.sinh_vien_id " +
            "LEFT JOIN PhuongThucXetTuyen pt ON pt.phuong_thuc_id=hs.phuong_thuc_id " +
            "WHERE sv.user_id=? ORDER BY hs.ho_so_id DESC", uid);
        for (Map<String,Object> a : applications) {
            int id = ((Number)a.get("ho_so_id")).intValue();
            String synced = syncToHopFromScores(id);
            if (synced != null) a.put("to_hop", synced);
            a.put("aspirations", jdbc.queryForList(
                "SELECT nv.thu_tu_nguyen_vong,nv.trang_thai,n.ma_nganh,n.ten_nganh " +
                "FROM NguyenVong nv JOIN Nganh n ON n.nganh_id=nv.nganh_id " +
                "WHERE nv.ho_so_id=? ORDER BY nv.thu_tu_nguyen_vong", id));
            a.put("scores", jdbc.queryForList(
                "SELECT ten_mon,diem_so FROM DiemXetTuyen WHERE ho_so_id=? ORDER BY diem_id", id));
            a.put("documents", jdbc.queryForObject(
                "SELECT COUNT(*) FROM MinhChung WHERE ho_so_id=?", Integer.class, id));
            List<Map<String,Object>> kq = jdbc.queryForList(
                "SELECT kq.diem_xet_tuyen,kq.trang_thai_ket_qua,n.ma_nganh,n.ten_nganh " +
                "FROM KetQua kq LEFT JOIN Nganh n ON n.nganh_id=kq.nganh_id WHERE kq.ho_so_id=?", id);
            a.put("result", kq.isEmpty() ? null : kq.get(0));
        }
        model.addAttribute("applications", applications);
        return "VIEW/USER/ho-so";
    }

    @GetMapping("/dang-ky-xet-tuyen")
    public String dangKy(@RequestParam(value="hoSoId", required=false) Integer hoSoId, HttpSession session, Model model) {
        String g = guard(session, model, "dangky"); if (g != null) return g;
        int uid = user(session).getUserId();
        model.addAttribute("methods", jdbc.queryForList("SELECT phuong_thuc_id,ma_phuong_thuc,ten_phuong_thuc,COALESCE(mo_ta,'') mo_ta FROM PhuongThucXetTuyen WHERE trang_thai='ACTIVE' ORDER BY phuong_thuc_id"));
        model.addAttribute("combos", jdbc.queryForList(
                "SELECT t.ma_to_hop,t.ten_to_hop,COALESCE(t.mo_ta,'') mo_ta, " +
                "COALESCE((SELECT GROUP_CONCAT(m.ten_mon ORDER BY m.thu_tu SEPARATOR '|') FROM ToHopMon m WHERE m.to_hop_id=t.to_hop_id),'') mon_list " +
                "FROM ToHopXetTuyen t WHERE t.trang_thai='ACTIVE' ORDER BY t.to_hop_id"));
        model.addAttribute("majors", jdbc.queryForList("SELECT n.nganh_id,n.ma_nganh,n.ten_nganh,n.mo_ta, CASE WHEN n.nganh_id=(SELECT nv.nganh_id FROM NguyenVong nv JOIN HoSo hs ON hs.ho_so_id=nv.ho_so_id WHERE nv.thu_tu_nguyen_vong=1 AND YEAR(hs.ngay_nop)=2026 GROUP BY nv.nganh_id ORDER BY COUNT(*) DESC LIMIT 1) THEN 1 ELSE 0 END AS is_hot FROM Nganh n WHERE n.trang_thai='DANG_TUYEN_SINH' ORDER BY n.nganh_id"));
        // Hiển thị đúng danh mục ngành: mỗi ngành chỉ xuất hiện 1 lần.
        // Các bản ghi ChiTieu theo từng phương thức vẫn được lấy nguyên vẹn từ MySQL
        // và gộp thành chuỗi để không làm lặp tên ngành trên giao diện.
        model.addAttribute("quotas", jdbc.queryForList(
            "SELECT n.nganh_id,n.ma_nganh,n.ten_nganh, " +
            "ct.nam_hoc AS nam_hoc, " +
            "GROUP_CONCAT(CONCAT(pt.ma_phuong_thuc, ': ', ct.so_luong) ORDER BY pt.ma_phuong_thuc SEPARATOR ' | ') AS chi_tieu_list, " +
            "GROUP_CONCAT(CONCAT(pt.ma_phuong_thuc, ': ', FORMAT(ct.diem_san,2)) ORDER BY pt.ma_phuong_thuc SEPARATOR ' | ') AS diem_san_list, " +
            "GROUP_CONCAT(pt.ma_phuong_thuc ORDER BY pt.ma_phuong_thuc SEPARATOR ' | ') AS phuong_thuc_list " +
            "FROM ChiTieu ct JOIN Nganh n ON n.nganh_id=ct.nganh_id " +
            "JOIN PhuongThucXetTuyen pt ON pt.phuong_thuc_id=ct.phuong_thuc_id " +
            "WHERE ct.nam_hoc=2026 " +
            "GROUP BY n.nganh_id,n.ma_nganh,n.ten_nganh,ct.nam_hoc ORDER BY n.nganh_id"));
        Map<String,Object> studentData = student(uid);
        model.addAttribute("student", studentData);
        if (studentData.get("sinh_vien_id") != null &&
                ((studentData.get("anh_dai_dien_data") instanceof byte[] b && b.length > 0) ||
                 (studentData.get("anh_dai_dien") != null && !String.valueOf(studentData.get("anh_dai_dien")).isBlank()))) {
            model.addAttribute("studentAvatarUrl", "/sinh-vien/avatar/" + studentData.get("sinh_vien_id"));
        }
        model.addAttribute("editingHoSoId", hoSoId);
        model.addAttribute("existingScoreMap", new LinkedHashMap<String,Object>());
        if (hoSoId != null) {
            // Hồ sơ cũ được tạo ở phiên bản trước có thể đã lưu điểm nhưng thiếu HoSo.to_hop.
            // Khi mở lại form, đồng bộ tổ hợp từ đúng 3 môn điểm đã lưu nếu chỉ khớp duy nhất một tổ hợp.
            syncToHopFromScores(hoSoId);
            List<Map<String,Object>> editRows = jdbc.queryForList("SELECT hs.ho_so_id,hs.phuong_thuc_id,hs.to_hop,hs.trang_thai,hs.ghi_chu FROM HoSo hs JOIN SinhVien sv ON sv.sinh_vien_id=hs.sinh_vien_id WHERE hs.ho_so_id=? AND sv.user_id=?", hoSoId, uid);
            if (!editRows.isEmpty() && !"DA_DUYET".equals(String.valueOf(editRows.get(0).get("trang_thai")))) {
                Map<String,Object> e = editRows.get(0);
                model.addAttribute("editingApplication", e);
                List<Integer> selected = jdbc.queryForList("SELECT nganh_id FROM NguyenVong WHERE ho_so_id=? ORDER BY thu_tu_nguyen_vong", hoSoId).stream().map(x -> ((Number)x.get("nganh_id")).intValue()).toList();
                model.addAttribute("selectedMajor1", selected.size()>0 ? selected.get(0) : null);
                model.addAttribute("selectedMajor2", selected.size()>1 ? selected.get(1) : null);
                model.addAttribute("selectedMajor3", selected.size()>2 ? selected.get(2) : null);
                List<Map<String,Object>> oldScores = jdbc.queryForList(
                        "SELECT ten_mon,diem_so FROM DiemXetTuyen WHERE ho_so_id=? ORDER BY diem_id", hoSoId);
                Map<String,Object> oldScoreMap = new LinkedHashMap<>();
                for (Map<String,Object> row : oldScores) oldScoreMap.put(String.valueOf(row.get("ten_mon")), row.get("diem_so"));
                model.addAttribute("existingScoreMap", oldScoreMap);
            } else {
                model.addAttribute("editingHoSoId", null);
            }
        }
        return "VIEW/USER/dang-ky-xet-tuyen";
    }

    @PostMapping("/dang-ky-xet-tuyen/submit")
    @Transactional
    public String submitApplication(
            @RequestParam(value="hoSoId", required=false) Integer hoSoId,
            @RequestParam int phuongThucId,
            @RequestParam(required=false) String toHop,
            @RequestParam(required=false) Integer nganh1,
            @RequestParam(required=false) Integer nganh2,
            @RequestParam(required=false) Integer nganh3,
            @RequestParam String hoTen,
            @RequestParam String cccd,
            @RequestParam(required=false) String ngaySinh,
            @RequestParam(required=false) String gioiTinh,
            @RequestParam(required=false) String truongThpt,
            @RequestParam(required=false) String diaChi,
            @RequestParam(required=false) String ghiChu,
            @RequestParam(value="anhDaiDien", required=false) MultipartFile anhDaiDien,
            @RequestParam(value="minhChungFiles", required=false) MultipartFile[] minhChungFiles,
            @RequestParam Map<String,String> allParams,
            HttpSession session,
            RedirectAttributes ra) throws IOException {
        User u = user(session); if (u == null) return "redirect:/login";
        if (!Integer.valueOf(3).equals(u.getRoleId())) return "redirect:/403";
        try {
            Integer svId = jdbc.queryForObject("SELECT sinh_vien_id FROM SinhVien WHERE user_id=?", Integer.class, u.getUserId());
            if (svId == null) { ra.addFlashAttribute("error", "Bạn chưa có hồ sơ sinh viên. Vui lòng cập nhật thông tin tài khoản trước."); return "redirect:/profile"; }

            if (hoTen == null || hoTen.isBlank() || cccd == null || cccd.isBlank()) {
                ra.addFlashAttribute("error", "Họ tên và CCCD không được để trống."); return "redirect:/dang-ky-xet-tuyen";
            }
            Integer duplicateCccd = jdbc.queryForObject("SELECT COUNT(*) FROM SinhVien WHERE cccd=? AND sinh_vien_id<>?", Integer.class, cccd.trim(), svId);
            if (duplicateCccd != null && duplicateCccd > 0) { ra.addFlashAttribute("error", "CCCD đã được sử dụng bởi thí sinh khác."); return "redirect:/dang-ky-xet-tuyen"; }
            jdbc.update("UPDATE SinhVien SET ho_ten=?,cccd=?,ngay_sinh=?,gioi_tinh=?,truong_thpt=?,dia_chi=? WHERE sinh_vien_id=?",
                    hoTen.trim(), cccd.trim(), parseDate(ngaySinh), blankToNull(gioiTinh), blankToNull(truongThpt), blankToNull(diaChi), svId);

            boolean hasNewAvatar = anhDaiDien != null && !anhDaiDien.isEmpty();
            if (hasNewAvatar && (!FileUtil.allowedImage(anhDaiDien) || anhDaiDien.getSize() > 5 * 1024 * 1024)) { ra.addFlashAttribute("error", "Ảnh phải là JPG, PNG hoặc WEBP và không quá 5MB."); return "redirect:/dang-ky-xet-tuyen"; }
            List<MultipartFile> evidence = new ArrayList<>();
            if (minhChungFiles != null) for (MultipartFile f : minhChungFiles) if (f != null && !f.isEmpty()) evidence.add(f);
            boolean updatingExisting = hoSoId != null;

            // Hồ sơ mới vẫn được phép dùng ảnh đã có trong hồ sơ SinhVien.
            // Chỉ bắt buộc tải ảnh mới nếu sinh viên chưa có ảnh nào trong CSDL.
            boolean hasStoredAvatar = jdbc.queryForObject(
                    "SELECT COUNT(*) FROM SinhVien WHERE sinh_vien_id=? AND ((anh_dai_dien_data IS NOT NULL AND OCTET_LENGTH(anh_dai_dien_data)>0) OR (anh_dai_dien IS NOT NULL AND TRIM(anh_dai_dien)<>'') )",
                    Integer.class, svId) > 0;
            if (!updatingExisting && !hasNewAvatar && !hasStoredAvatar) {
                ra.addFlashAttribute("error", "Vui lòng tải ảnh thí sinh hoặc cập nhật ảnh đại diện trong CSDL trước khi nộp hồ sơ.");
                return "redirect:/dang-ky-xet-tuyen";
            }
            if (!updatingExisting && evidence.isEmpty()) {
                ra.addFlashAttribute("error", "Vui lòng tải ít nhất 1 file minh chứng.");
                return "redirect:/dang-ky-xet-tuyen";
            }
            for (MultipartFile f : evidence) if (!FileUtil.allowedEvidence(f) || f.getSize() > 10 * 1024 * 1024) { ra.addFlashAttribute("error", "Mỗi file minh chứng phải là PDF/JPG/PNG/WEBP và không quá 10MB."); return "redirect:/dang-ky-xet-tuyen"; }

            List<Integer> majors = uniqueMajors(nganh1, nganh2, nganh3);
            if (majors.isEmpty()) { ra.addFlashAttribute("error", "Vui lòng chọn ít nhất 1 nguyện vọng ngành."); return "redirect:/dang-ky-xet-tuyen"; }
            Integer methodExists = jdbc.queryForObject("SELECT COUNT(*) FROM PhuongThucXetTuyen WHERE phuong_thuc_id=?", Integer.class, phuongThucId);
            Integer comboExists = jdbc.queryForObject("SELECT COUNT(*) FROM ToHopXetTuyen WHERE ma_to_hop=?", Integer.class, toHop);
            if (comboExists == null || comboExists == 0) { ra.addFlashAttribute("error", "Tổ hợp xét tuyển không tồn tại trong danh mục CSDL."); return "redirect:/dang-ky-xet-tuyen"; }
            if (methodExists == null || methodExists == 0) throw new IllegalArgumentException("Phương thức xét tuyển không tồn tại.");
            // Không chặn hồ sơ mới chỉ vì sinh viên đã có một hồ sơ khác.
            // Mỗi lần bấm "Tạo hồ sơ" là một HoSo mới; khi cập nhật, hoSoId xác định đúng hồ sơ cần sửa.

            // Đọc file mới nếu có. Khi sửa hồ sơ, nếu không chọn lại ảnh/file thì giữ nguyên dữ liệu cũ.
            byte[] avatarBytes = hasNewAvatar ? anhDaiDien.getBytes() : null;
            String avatarMime = hasNewAvatar ? (anhDaiDien.getContentType() == null ? "image/jpeg" : anhDaiDien.getContentType()) : null;
            String avatarPath = hasNewAvatar ? FileUtil.save(anhDaiDien, "anh-dai-dien") : null;

            if (hoSoId != null) {
                Integer owned = jdbc.queryForObject("SELECT COUNT(*) FROM HoSo hs JOIN SinhVien sv ON sv.sinh_vien_id=hs.sinh_vien_id WHERE hs.ho_so_id=? AND sv.user_id=? AND hs.trang_thai<>'DA_DUYET'", Integer.class, hoSoId, u.getUserId());
                if (owned == null || owned == 0) throw new IllegalArgumentException("Hồ sơ không tồn tại, không thuộc tài khoản hoặc đã được duyệt.");
                String note = blankToNull(ghiChu);
                if (note == null) note = "Thí sinh bổ sung/cập nhật lại hồ sơ trực tuyến";
                jdbc.update("UPDATE HoSo SET phuong_thuc_id=?,to_hop=?,trang_thai='CHO_DUYET',ghi_chu=? WHERE ho_so_id=?", phuongThucId, blankToNull(toHop), note, hoSoId);
                jdbc.update("DELETE FROM DiemXetTuyen WHERE ho_so_id=?", hoSoId);
                jdbc.update("DELETE FROM NguyenVong WHERE ho_so_id=?", hoSoId);
                // Chỉ thay bộ minh chứng khi người dùng thực sự tải file mới.
                if (!evidence.isEmpty()) jdbc.update("DELETE FROM MinhChung WHERE ho_so_id=?", hoSoId);
            } else {
                KeyHolder keyHolder = new GeneratedKeyHolder();
                jdbc.update(connection -> {
                    var ps = connection.prepareStatement(
                            "INSERT INTO HoSo(sinh_vien_id,phuong_thuc_id,to_hop,trang_thai,ghi_chu) VALUES(?,?,?,'CHO_DUYET', ?)",
                            java.sql.Statement.RETURN_GENERATED_KEYS);
                    ps.setInt(1, svId);
                    ps.setInt(2, phuongThucId);
                    if (blankToNull(toHop) == null) ps.setNull(3, java.sql.Types.VARCHAR);
                    else ps.setString(3, blankToNull(toHop));
                    ps.setString(4, "Hồ sơ được nộp trực tuyến");
                    return ps;
                }, keyHolder);
                Number generatedId = keyHolder.getKey();
                if (generatedId == null) throw new IllegalStateException("Không lấy được mã hồ sơ vừa tạo từ MySQL.");
                hoSoId = generatedId.intValue();
            }
            if (hasNewAvatar) {
                jdbc.update("UPDATE SinhVien SET anh_dai_dien=?,anh_dai_dien_data=?,anh_dai_dien_mime=? WHERE sinh_vien_id=?", avatarPath, avatarBytes, avatarMime, svId);
                // Lưu ảnh đại diện như một minh chứng để cán bộ xem ngay trong hồ sơ.
                jdbc.update("DELETE FROM MinhChung WHERE ho_so_id=? AND loai_minh_chung='IMAGE_AVATAR'", hoSoId);
                jdbc.update("INSERT INTO MinhChung(ho_so_id,ten_minh_chung,file_path,loai_minh_chung,du_lieu,mime_type,kich_thuoc) VALUES(?,?,?,?,?,?,?)",
                        hoSoId, "Ảnh thẻ/ảnh đại diện", avatarPath, "IMAGE_AVATAR", avatarBytes, avatarMime, (long)avatarBytes.length);
            }

            for (MultipartFile f : evidence) {
                byte[] fileBytes = f.getBytes();
                String path = FileUtil.save(f, "minh-chung");
                String originalName = f.getOriginalFilename() == null ? "Minh chứng" : Paths.get(f.getOriginalFilename()).getFileName().toString();
                String type = f.getContentType() == null ? "application/octet-stream" : f.getContentType();
                jdbc.update("INSERT INTO MinhChung(ho_so_id,ten_minh_chung,file_path,loai_minh_chung,du_lieu,mime_type,kich_thuoc) VALUES(?,?,?,?,?,?,?)",
                        hoSoId, originalName, path, type, fileBytes, type, (long)fileBytes.length);
            }

            if (toHop != null && !toHop.isBlank()) {
                String[] subjects = subjectsForCombo(toHop);
                for (int i = 0; i < subjects.length; i++) {
                    String subject = subjects[i];
                    // Dùng score_0, score_1... thay vì tên môn làm tên request param;
                    // tránh lỗi với tiếng Việt/ký tự khoảng trắng và bảo đảm dữ liệu đi đúng thứ tự môn trong MySQL.
                    String value = allParams.get("score_" + i);
                    if (value == null || value.isBlank()) throw new IllegalArgumentException("Vui lòng nhập điểm " + subject + ".");
                    double score = Double.parseDouble(value);
                    if (score < 0 || score > 10) throw new IllegalArgumentException("Điểm từng môn phải từ 0 đến 10.");
                    jdbc.update("INSERT INTO DiemXetTuyen(ho_so_id,ten_mon,diem_so) VALUES(?,?,?)", hoSoId, subject, score);
                }
            }

            int order = 1;
            for (Integer majorId : majors) {
                Integer ok = jdbc.queryForObject("SELECT COUNT(*) FROM Nganh WHERE nganh_id=?", Integer.class, majorId);
                if (ok == null || ok == 0) throw new IllegalArgumentException("Ngành đã chọn không tồn tại.");
                jdbc.update("INSERT INTO NguyenVong(ho_so_id,nganh_id,thu_tu_nguyen_vong,trang_thai) VALUES(?,?,?,'CHO_XET')", hoSoId, majorId, order++);
            }
            jdbc.update("INSERT INTO HoSoLog(ho_so_id,user_id,hanh_dong,chi_tiet) VALUES(?,?,?,?)", hoSoId, u.getUserId(), updatingExisting ? "CẬP NHẬT HỒ SƠ" : "NỘP HỒ SƠ", "Thí sinh đăng ký " + majors.size() + " nguyện vọng.");
            ra.addFlashAttribute("success", "Đã lưu hồ sơ HS" + hoSoId + " vào MySQL. Hồ sơ đang chờ cán bộ tiếp nhận.");
        } catch (DuplicateKeyException e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            ra.addFlashAttribute("error", "Dữ liệu đã tồn tại, vui lòng kiểm tra lại thông tin.");
            return "redirect:/dang-ky-xet-tuyen";
        } catch (IOException e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            ra.addFlashAttribute("error", "Không thể đọc/lưu file: " + e.getMessage());
            return "redirect:/dang-ky-xet-tuyen";
        } catch (Exception e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            ra.addFlashAttribute("error", "Không thể nộp hồ sơ: " + e.getMessage());
            return "redirect:/dang-ky-xet-tuyen";
        }
        return "redirect:/ho-so";
    }

    @PostMapping("/theo-doi-ho-so/{id}/huy")
    @Transactional
    public String huyHoSo(@PathVariable int id, HttpSession session, RedirectAttributes ra) {
        User u = user(session); if (u == null) return "redirect:/login";
        if (!Integer.valueOf(3).equals(u.getRoleId())) return "redirect:/403";
        try {
            Integer count = jdbc.queryForObject("SELECT COUNT(*) FROM HoSo hs JOIN SinhVien sv ON sv.sinh_vien_id=hs.sinh_vien_id WHERE hs.ho_so_id=? AND sv.user_id=? AND hs.trang_thai IN ('CHO_DUYET','TIEP_NHAN','DANG_XU_LY')", Integer.class, id, u.getUserId());
            if (count == null || count == 0) { ra.addFlashAttribute("error", "Hồ sơ không tồn tại hoặc không còn ở trạng thái có thể hủy."); return "redirect:/theo-doi-ho-so"; }
            jdbc.update("UPDATE HoSo SET trang_thai='HUY',ghi_chu=? WHERE ho_so_id=?", "Thí sinh chủ động hủy hồ sơ", id);
            jdbc.update("INSERT INTO HoSoLog(ho_so_id,user_id,hanh_dong,chi_tiet) VALUES(?,?,?,?)", id, u.getUserId(), "HỦY HỒ SƠ", "Thí sinh hủy hồ sơ khi hồ sơ chưa được duyệt.");
            ra.addFlashAttribute("success", "Đã hủy hồ sơ HS" + id + ". Hồ sơ vẫn được lưu để đối soát.");
        } catch (Exception e) { ra.addFlashAttribute("error", "Không thể hủy hồ sơ: " + e.getMessage()); }
        return "redirect:/theo-doi-ho-so";
    }

    @GetMapping("/theo-doi-ho-so")
    public String theoDoi(HttpSession session, Model model) {
        String g = guard(session, model, "theodoi"); if (g != null) return g;
        int uid = user(session).getUserId();
        List<Map<String,Object>> apps = jdbc.queryForList("SELECT hs.ho_so_id AS ho_so_id,hs.ngay_nop AS ngay_nop,COALESCE(hs.trang_thai,'CHO_DUYET') AS trang_thai,COALESCE(hs.ghi_chu,'Hồ sơ nộp trực tuyến') AS ghi_chu,COALESCE(pt.ten_phuong_thuc,CONCAT('Phương thức #',hs.phuong_thuc_id)) AS ten_phuong_thuc,COALESCE(pt.ma_phuong_thuc,CONCAT('PT#',hs.phuong_thuc_id)) AS ma_phuong_thuc FROM HoSo hs JOIN SinhVien sv ON sv.sinh_vien_id=hs.sinh_vien_id LEFT JOIN PhuongThucXetTuyen pt ON pt.phuong_thuc_id=hs.phuong_thuc_id WHERE sv.user_id=? ORDER BY hs.ho_so_id ASC", uid);
        for (Map<String,Object> a : apps) {
            int hs = ((Number)a.get("ho_so_id")).intValue();
            String synced = syncToHopFromScores(hs);
            if (synced != null) a.put("to_hop", synced);
            a.put("aspirations", jdbc.queryForList("SELECT nv.thu_tu_nguyen_vong,nv.trang_thai,n.ma_nganh,n.ten_nganh FROM NguyenVong nv JOIN Nganh n ON n.nganh_id=nv.nganh_id WHERE nv.ho_so_id=? ORDER BY nv.thu_tu_nguyen_vong", hs));
            a.put("documents", jdbc.queryForObject("SELECT COUNT(*) FROM MinhChung WHERE ho_so_id=?", Integer.class, hs));
        }
        model.addAttribute("applications", apps);
        return "VIEW/USER/theo-doi-ho-so";
    }

    @GetMapping({"/theo-doi-ho-so/{id}", "/ho-so/{id}"})
    public String chiTietHoSo(@PathVariable int id, HttpSession session, Model model) {
        String g = guard(session, model, "theodoi");
        if (g != null) return g;
        int uid = user(session).getUserId();

        List<Map<String,Object>> rows = jdbc.queryForList(
            "SELECT hs.ho_so_id,hs.ngay_nop,COALESCE(hs.trang_thai,'CHO_DUYET') AS trang_thai,COALESCE(hs.ghi_chu,'Hồ sơ nộp trực tuyến') AS ghi_chu,COALESCE(hs.to_hop,'Không áp dụng') AS to_hop," +
            "hs.sinh_vien_id,hs.phuong_thuc_id," +
            "COALESCE(pt.ma_phuong_thuc,CONCAT('PT#',hs.phuong_thuc_id)) AS ma_phuong_thuc," +
            "COALESCE(pt.ten_phuong_thuc,'Phương thức xét tuyển') AS ten_phuong_thuc," +
            "COALESCE(pt.mo_ta,'Thông tin phương thức xét tuyển') AS mo_ta_phuong_thuc," +
            "sv.ho_ten,sv.cccd,sv.ngay_sinh,sv.gioi_tinh,sv.dia_chi,sv.truong_thpt," +
            "sv.anh_dai_dien,sv.anh_dai_dien_data,sv.anh_dai_dien_mime," +
            "u.username,u.email,u.phone " +
            "FROM HoSo hs JOIN SinhVien sv ON sv.sinh_vien_id=hs.sinh_vien_id " +
            "JOIN `User` u ON u.user_id=sv.user_id " +
            "LEFT JOIN PhuongThucXetTuyen pt ON pt.phuong_thuc_id=hs.phuong_thuc_id " +
            "WHERE hs.ho_so_id=? AND sv.user_id=?", id, uid);
        if (rows.isEmpty()) {
            model.addAttribute("notFound", true);
            return "VIEW/USER/ho-so-chi-tiet";
        }

        Map<String,Object> application = new LinkedHashMap<>(rows.get(0));

        // LEFT JOIN ngành để hồ sơ cũ vẫn hiện nguyện vọng kể cả khi mã ngành đã bị thay đổi.
        List<Map<String,Object>> aspirations = jdbc.queryForList(
            "SELECT nv.nguyen_vong_id,nv.thu_tu_nguyen_vong,nv.trang_thai,nv.nganh_id," +
            "COALESCE(n.ma_nganh,CONCAT('NGANH#',nv.nganh_id)) AS ma_nganh," +
            "COALESCE(n.ten_nganh,'Ngành chưa còn trong danh mục') AS ten_nganh " +
            "FROM NguyenVong nv LEFT JOIN Nganh n ON n.nganh_id=nv.nganh_id " +
            "WHERE nv.ho_so_id=? ORDER BY nv.thu_tu_nguyen_vong,nv.nguyen_vong_id", id);

        List<Map<String,Object>> documents = jdbc.queryForList(
            "SELECT minh_chung_id,ten_minh_chung,file_path,loai_minh_chung,mime_type,kich_thuoc," +
            "CASE WHEN du_lieu IS NULL THEN 0 ELSE OCTET_LENGTH(du_lieu) END AS db_size " +
            "FROM MinhChung WHERE ho_so_id=? ORDER BY minh_chung_id", id);

        List<Map<String,Object>> scores = jdbc.queryForList(
            "SELECT ten_mon,diem_so FROM DiemXetTuyen WHERE ho_so_id=? ORDER BY diem_id", id);

        // Tổ hợp và thứ tự môn được lấy trực tiếp từ MySQL. Với hồ sơ cũ bị thiếu to_hop,
        // hệ thống đối chiếu đúng các môn đã lưu trong DiemXetTuyen và đồng bộ lại HoSo.to_hop.
        String selectedToHop = application.get("to_hop") == null ? "" : String.valueOf(application.get("to_hop")).trim();
        if (selectedToHop.isBlank()) {
            String synced = syncToHopFromScores(id);
            if (synced != null) {
                selectedToHop = synced;
                application.put("to_hop", synced);
            }
        }
        List<String> selectedSubjects = selectedToHop.isBlank() ? List.of() : jdbc.queryForList(
                "SELECT m.ten_mon FROM ToHopMon m JOIN ToHopXetTuyen t ON t.to_hop_id=m.to_hop_id WHERE t.ma_to_hop=? ORDER BY m.thu_tu",
                String.class, selectedToHop);
        // Chuẩn hóa tên môn để tránh lỗi khi tên môn trong MySQL
        // có khác nhau về chữ hoa/chữ thường hoặc khoảng trắng.
        Map<String,Double> rawScoreMap = new LinkedHashMap<>();
        for (Map<String,Object> row : scores) {
            Object tenMonObj = row.get("ten_mon");
            Object diemObj = row.get("diem_so");
            if (tenMonObj != null && diemObj instanceof Number n) {
                rawScoreMap.put(normalizeSubject(String.valueOf(tenMonObj)), n.doubleValue());
            }
        }

        // scoreMap dùng chính tên môn của tổ hợp để Thymeleaf
        // có thể lấy scoreMap[subject] chính xác.
        Map<String,Double> scoreMap = new LinkedHashMap<>();
        for (String subject : selectedSubjects) {
            Double diem = rawScoreMap.get(normalizeSubject(subject));
            if (diem != null) {
                scoreMap.put(subject, diem);
            }
        }

        // Tổng điểm chỉ tính các môn thuộc tổ hợp đang xét.
        double totalScore = scoreMap.values().stream()
                .mapToDouble(Double::doubleValue)
                .sum();

        List<Map<String,Object>> result = jdbc.queryForList(
            "SELECT kq.ket_qua_id,kq.diem_xet_tuyen,kq.trang_thai_ket_qua,kq.ngay_cap_nhat," +
            "n.ma_nganh,n.ten_nganh FROM KetQua kq LEFT JOIN Nganh n ON n.nganh_id=kq.nganh_id " +
            "WHERE kq.ho_so_id=?", id);

        String avatarUrl = null;
        for (Map<String,Object> d : documents) {
            if ("IMAGE_AVATAR".equals(String.valueOf(d.get("loai_minh_chung")))) {
                avatarUrl = "/minh-chung/file/" + d.get("minh_chung_id");
                break;
            }
        }
        if (avatarUrl == null && application.get("sinh_vien_id") != null &&
                (application.get("anh_dai_dien_data") instanceof byte[] b && b.length > 0 ||
                 application.get("anh_dai_dien") != null && !String.valueOf(application.get("anh_dai_dien")).isBlank())) {
            avatarUrl = "/sinh-vien/avatar/" + application.get("sinh_vien_id");
        }

        application.put("aspirations", aspirations);
        application.put("documents", documents);
        application.put("scores", scores);
        application.put("selectedSubjects", selectedSubjects);
        application.put("scoreMap", scoreMap);
        application.put("totalScore", totalScore);
        application.put("result", result.isEmpty() ? null : result.get(0));
        application.put("avatar_url", avatarUrl);

        String status = application.get("trang_thai") == null ? "CHO_DUYET" : String.valueOf(application.get("trang_thai"));
        String statusText;
        String statusClass;
        switch (status) {
            case "DA_DUYET" -> { statusText="ĐÃ DUYỆT"; statusClass="status-ok"; }
            case "TIEP_NHAN" -> { statusText="ĐÃ TIẾP NHẬN"; statusClass="status-info"; }
            case "DANG_XU_LY" -> { statusText="ĐANG XỬ LÝ"; statusClass="status-info"; }
            case "KHONG_DUYET", "TU_CHOI" -> { statusText="KHÔNG ĐƯỢC DUYỆT"; statusClass="status-no"; }
            case "HUY" -> { statusText="ĐÃ HỦY"; statusClass="status-no"; }
            default -> { statusText="ĐANG CHỜ XỬ LÝ"; statusClass="status-wait"; }
        }

        // Gửi cả Map lẫn các biến riêng. Như vậy template không phụ thuộc cách Thymeleaf truy cập Map lồng nhau.
        model.addAttribute("application", application);
        model.addAttribute("selectedToHop", selectedToHop);
        model.addAttribute("aspirations", aspirations);
        model.addAttribute("documents", documents);
        model.addAttribute("scores", scores);
        model.addAttribute("selectedSubjects", selectedSubjects);
        model.addAttribute("scoreMap", scoreMap);
        model.addAttribute("totalScore", totalScore);
        model.addAttribute("result", result.isEmpty() ? null : result.get(0));
        model.addAttribute("hoSoId", application.get("ho_so_id"));
        model.addAttribute("ngayNop", application.get("ngay_nop"));
        model.addAttribute("maPhuongThuc", application.get("ma_phuong_thuc"));
        model.addAttribute("tenPhuongThuc", application.get("ten_phuong_thuc"));
        model.addAttribute("moTaPhuongThuc", application.get("mo_ta_phuong_thuc"));
        model.addAttribute("hoTen", application.get("ho_ten"));
        model.addAttribute("cccd", application.get("cccd"));
        model.addAttribute("ngaySinh", application.get("ngay_sinh"));
        model.addAttribute("gioiTinh", application.get("gioi_tinh"));
        model.addAttribute("email", application.get("email"));
        model.addAttribute("phone", application.get("phone"));
        model.addAttribute("truongThpt", application.get("truong_thpt"));
        model.addAttribute("diaChi", application.get("dia_chi"));
        model.addAttribute("username", application.get("username"));
        model.addAttribute("sinhVienId", application.get("sinh_vien_id"));
        model.addAttribute("avatarUrl", avatarUrl);
        model.addAttribute("statusText", statusText);
        model.addAttribute("statusClass", statusClass);
        return "VIEW/USER/ho-so-chi-tiet";
    }

    /**
     * Đồng bộ dữ liệu hồ sơ cũ: nếu HoSo.to_hop đang NULL nhưng đã có đúng 3 môn điểm,
     * tìm tổ hợp duy nhất có cùng tập môn trong ToHopXetTuyen/ToHopMon rồi ghi lại vào MySQL.
     * Không suy đoán từ tổng điểm và không thay đổi điểm của thí sinh.
     */
    /**
     * Đồng bộ tổ hợp của hồ sơ từ chính dữ liệu điểm đã nộp.
     * Không suy đoán theo tổng điểm. Hệ thống chuẩn hóa tên môn (trim +
     * không phân biệt hoa thường + gom khoảng trắng) rồi đối chiếu với
     * ToHopMon trong MySQL. Nếu khớp duy nhất một tổ hợp thì ghi lại
     * HoSo.to_hop để mọi màn hình đọc cùng một dữ liệu.
     */
    private String syncToHopFromScores(int hoSoId) {
        List<Map<String,Object>> hsRows = jdbc.queryForList(
                "SELECT to_hop FROM HoSo WHERE ho_so_id=?", hoSoId);
        if (hsRows.isEmpty()) return null;

        Object current = hsRows.get(0).get("to_hop");
        if (current != null && !String.valueOf(current).trim().isBlank()) {
            String hop = String.valueOf(current).trim();
            Integer exists = jdbc.queryForObject(
                    "SELECT COUNT(*) FROM ToHopXetTuyen WHERE ma_to_hop=?", Integer.class, hop);
            if (exists != null && exists > 0) return hop;
        }

        List<String> savedSubjects = jdbc.queryForList(
                "SELECT ten_mon FROM DiemXetTuyen WHERE ho_so_id=? GROUP BY ten_mon ORDER BY MIN(diem_id)",
                String.class, hoSoId);
        if (savedSubjects.size() != 3) return null;

        Set<String> saved = new LinkedHashSet<>();
        for (String subject : savedSubjects) saved.add(normalizeSubject(subject));
        if (saved.size() != 3) return null;

        List<Map<String,Object>> combos = jdbc.queryForList(
                "SELECT t.ma_to_hop, m.ten_mon, m.thu_tu " +
                "FROM ToHopXetTuyen t JOIN ToHopMon m ON m.to_hop_id=t.to_hop_id " +
                "ORDER BY t.to_hop_id,m.thu_tu");
        Map<String,Set<String>> comboSubjects = new LinkedHashMap<>();
        for (Map<String,Object> row : combos) {
            String code = String.valueOf(row.get("ma_to_hop"));
            comboSubjects.computeIfAbsent(code, k -> new LinkedHashSet<>())
                    .add(normalizeSubject(String.valueOf(row.get("ten_mon"))));
        }

        List<String> matches = new ArrayList<>();
        for (Map.Entry<String,Set<String>> entry : comboSubjects.entrySet()) {
            if (entry.getValue().size() == 3 && entry.getValue().equals(saved)) {
                matches.add(entry.getKey());
            }
        }

        // Nếu danh mục ToHopMon của CSDL chưa được đồng bộ,
        // đối chiếu thêm với tên 3 môn trong ToHopXetTuyen.
        if (matches.isEmpty()) {
            List<Map<String,Object>> comboNames = jdbc.queryForList(
                    "SELECT ma_to_hop, ten_to_hop FROM ToHopXetTuyen"
            );

            for (Map<String,Object> row : comboNames) {
                String code = String.valueOf(row.get("ma_to_hop"));
                String name = String.valueOf(row.get("ten_to_hop"));

                Set<String> nameSubjects = new LinkedHashSet<>();
                for (String part : name.split(",")) {
                    nameSubjects.add(normalizeSubject(part));
                }

                if (nameSubjects.size() == 3 && nameSubjects.equals(saved)) {
                    matches.add(code);
                }
            }
        }

        if (matches.size() != 1) return null;

        String resolved = matches.get(0);
        jdbc.update("UPDATE HoSo SET to_hop=? WHERE ho_so_id=?", resolved, hoSoId);
        return resolved;
    }

    private String normalizeSubject(String value) {
        if (value == null) return "";
        String s = value.trim().replaceAll("\\s+", " ").toLowerCase(Locale.ROOT);
        s = Normalizer.normalize(s, Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "");
        s = s.replace("đ", "d");
        return s;
    }

    private Map<String,Object> student(int uid) {
        List<Map<String,Object>> rows = jdbc.queryForList("SELECT sv.sinh_vien_id AS sinh_vien_id,sv.ho_ten AS ho_ten,sv.cccd AS cccd,sv.ngay_sinh AS ngay_sinh,sv.gioi_tinh AS gioi_tinh,sv.dia_chi AS dia_chi,sv.truong_thpt AS truong_thpt,sv.anh_dai_dien AS anh_dai_dien,sv.anh_dai_dien_data AS anh_dai_dien_data,u.email AS email,u.phone AS phone FROM SinhVien sv JOIN `User` u ON u.user_id=sv.user_id WHERE sv.user_id=?", uid);
        if (rows.isEmpty()) return new HashMap<>();
        return rows.get(0);
    }
    private String[] subjectsForCombo(String combo) {
        List<String> subjects = jdbc.queryForList(
                "SELECT m.ten_mon FROM ToHopMon m JOIN ToHopXetTuyen t ON t.to_hop_id=m.to_hop_id WHERE t.ma_to_hop=? ORDER BY m.thu_tu",
                String.class, combo);
        if (subjects.isEmpty()) throw new IllegalArgumentException("Tổ hợp chưa được cấu hình môn xét tuyển trong CSDL.");
        return subjects.toArray(String[]::new);
    }

    private List<Integer> uniqueMajors(Integer... ids) { LinkedHashSet<Integer> s=new LinkedHashSet<>(); for(Integer id:ids) if(id!=null) s.add(id); return new ArrayList<>(s); }
    private String blankToNull(String s){return s==null||s.trim().isEmpty()?null:s.trim();}
    private LocalDate parseDate(String s){return s==null||s.isBlank()?null:LocalDate.parse(s);}
}
