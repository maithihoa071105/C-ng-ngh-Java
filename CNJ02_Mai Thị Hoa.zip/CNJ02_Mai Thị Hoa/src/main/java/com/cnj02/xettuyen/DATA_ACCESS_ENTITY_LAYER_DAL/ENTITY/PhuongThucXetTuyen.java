package com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY;

import jakarta.persistence.*;

@Entity
@Table(name="PhuongThucXetTuyen")
public class PhuongThucXetTuyen {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="phuong_thuc_id")
    private Integer phuongThucId;

    @Column(name="ma_phuong_thuc")
    private String maPhuongThuc;

    @Column(name="ten_phuong_thuc")
    private String tenPhuongThuc;

    @Column(name="mo_ta")
    private String moTa;

    @Column(name="trang_thai")
    private String trangThai = "ACTIVE";

    public PhuongThucXetTuyen(){}
    public Integer getPhuongThucId(){return phuongThucId;}
    public void setPhuongThucId(Integer v){this.phuongThucId=v;}
    public String getMaPhuongThuc(){return maPhuongThuc;}
    public void setMaPhuongThuc(String v){this.maPhuongThuc=v;}
    public String getTenPhuongThuc(){return tenPhuongThuc;}
    public void setTenPhuongThuc(String v){this.tenPhuongThuc=v;}
    public String getMoTa(){return moTa;}
    public void setMoTa(String v){this.moTa=v;}
    public String getTrangThai(){return trangThai;}
    public void setTrangThai(String v){this.trangThai=v;}

    @PrePersist
    public void prePersist(){if(trangThai==null||trangThai.isBlank()) trangThai="ACTIVE";}
}
