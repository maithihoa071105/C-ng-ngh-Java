package com.cnj02.xettuyen.PRESENTATION_LAYER_UI.ADMIN_CONTROLLER;

import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin")
public class ThongBaoAdminController {
    private final JdbcTemplate jdbc;
    public ThongBaoAdminController(JdbcTemplate jdbc){this.jdbc=jdbc;}
    private boolean ok(HttpSession s){User u=(User)s.getAttribute("currentUser");return u!=null&&Integer.valueOf(1).equals(u.getRoleId());}
    private String base(HttpSession s,Model m){if(!ok(s))return "redirect:/403";m.addAttribute("items",jdbc.queryForList("SELECT thong_bao_id thongBaoId,tieu_de tieuDe,noi_dung noiDung,ngay_tao ngayTao FROM ThongBao ORDER BY thong_bao_id DESC"));return null;}
    @GetMapping("/thong-bao") public String list(HttpSession s,Model m){String g=base(s,m);if(g!=null)return g;m.addAttribute("form",new Form());return "VIEW/ADMIN/thong-bao";}
    @GetMapping("/thong-bao/edit/{id}") public String edit(HttpSession s,@PathVariable Integer id,Model m){String g=base(s,m);if(g!=null)return g;var r=jdbc.queryForList("SELECT thong_bao_id,tieu_de,noi_dung FROM ThongBao WHERE thong_bao_id=?",id);if(r.isEmpty())return "redirect:/admin/thong-bao?error=notfound";var x=r.get(0);Form f=new Form();f.id=((Number)x.get("thong_bao_id")).intValue();f.title=String.valueOf(x.get("tieu_de"));f.content=String.valueOf(x.get("noi_dung"));m.addAttribute("form",f);return "VIEW/ADMIN/thong-bao";}
    @PostMapping("/thong-bao/save") public String save(HttpSession s,@RequestParam(required=false) Integer thongBaoId,@RequestParam String tieuDe,@RequestParam String noiDung){if(!ok(s))return "redirect:/403";if(thongBaoId==null)jdbc.update("INSERT INTO ThongBao(tieu_de,noi_dung) VALUES(?,?)",tieuDe.trim(),noiDung.trim());else jdbc.update("UPDATE ThongBao SET tieu_de=?,noi_dung=? WHERE thong_bao_id=?",tieuDe.trim(),noiDung.trim(),thongBaoId);return "redirect:/admin/thong-bao?success=saved";}
    @PostMapping("/thong-bao/delete/{id}") public String del(HttpSession s,@PathVariable Integer id){if(!ok(s))return "redirect:/403";jdbc.update("DELETE FROM ThongBao WHERE thong_bao_id=?",id);return "redirect:/admin/thong-bao?success=deleted";}
    public static class Form {Integer id;String title="",content="";public Integer getId(){return id;}public String getTitle(){return title;}public String getContent(){return content;}}
}
