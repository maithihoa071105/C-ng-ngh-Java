package com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name="ThongBao")
public class ThongBao {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="thong_bao_id")
    private Integer thongBaoId;

    @Column(name="tieu_de")
    private String tieuDe;

    @Column(name="noi_dung")
    private String noiDung;

    @Column(name="ngay_tao")
    private LocalDateTime ngayTao;

    public ThongBao(){}

    public Integer getThongBaoId(){return thongBaoId;}
    public void setThongBaoId(Integer v){this.thongBaoId=v;}

    public String getTieuDe(){return tieuDe;}
    public void setTieuDe(String v){this.tieuDe=v;}

    public String getNoiDung(){return noiDung;}
    public void setNoiDung(String v){this.noiDung=v;}

    public LocalDateTime getNgayTao(){return ngayTao;}
    public void setNgayTao(LocalDateTime v){this.ngayTao=v;}

}
