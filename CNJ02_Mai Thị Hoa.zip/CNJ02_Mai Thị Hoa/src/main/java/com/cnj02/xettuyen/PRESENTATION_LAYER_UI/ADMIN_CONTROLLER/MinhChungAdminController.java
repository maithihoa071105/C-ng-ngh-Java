package com.cnj02.xettuyen.PRESENTATION_LAYER_UI.ADMIN_CONTROLLER;

import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/admin")
public class MinhChungAdminController {
    private final JdbcTemplate jdbc;

    public MinhChungAdminController(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    private boolean ok(HttpSession session) {
        User user = (User) session.getAttribute("currentUser");
        return user != null && Integer.valueOf(2).equals(user.getRoleId());
    }

    @GetMapping("/minh-chung")
    public String list(HttpSession session, Model model) {
        if (!ok(session)) return "redirect:/403";

        // Gom minh chứng theo hồ sơ: một hồ sơ chỉ xuất hiện một dòng.
        List<Map<String, Object>> rows = jdbc.queryForList(
                "SELECT mc.minh_chung_id AS minhChungId, mc.ho_so_id AS hoSoId, " +
                "mc.ten_minh_chung AS tenMinhChung, mc.loai_minh_chung AS loaiMinhChung, " +
                "mc.mime_type AS mimeType, COALESCE(mc.kich_thuoc,0) AS kichThuoc, " +
                "CASE WHEN mc.du_lieu IS NULL THEN 0 ELSE OCTET_LENGTH(mc.du_lieu) END AS dbSize, " +
                "COALESCE(sv.ho_ten,'') AS hoTen " +
                "FROM MinhChung mc " +
                "LEFT JOIN HoSo hs ON hs.ho_so_id = mc.ho_so_id " +
                "LEFT JOIN SinhVien sv ON sv.sinh_vien_id = hs.sinh_vien_id " +
                "ORDER BY mc.ho_so_id, mc.minh_chung_id");

        Map<Integer, Map<String, Object>> grouped = new LinkedHashMap<>();
        for (Map<String, Object> row : rows) {
            Integer hoSoId = ((Number) row.get("hoSoId")).intValue();
            Map<String, Object> item = grouped.get(hoSoId);
            if (item == null) {
                item = new LinkedHashMap<>();
                item.put("hoSoId", hoSoId);
                item.put("hoTen", row.get("hoTen"));
                item.put("files", new ArrayList<Map<String, Object>>());
                grouped.put(hoSoId, item);
            }
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> files = (List<Map<String, Object>>) item.get("files");
            files.add(row);
        }

        model.addAttribute("items", new ArrayList<>(grouped.values()));
        model.addAttribute("isStaff", true);
        model.addAttribute("tabId", "minhchung");
        model.addAttribute("currentUser", session.getAttribute("currentUser"));
        return "VIEW/ADMIN/minh-chung";
    }

    @PostMapping("/minh-chung/delete/{id}")
    public String del(HttpSession session, @PathVariable Integer id) {
        if (!ok(session)) return "redirect:/403";
        jdbc.update("DELETE FROM MinhChung WHERE minh_chung_id=?", id);
        return "redirect:/admin/minh-chung?success=deleted";
    }
}
