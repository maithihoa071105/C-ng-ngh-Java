package com.cnj02.xettuyen.DESKTOP;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.concurrent.Worker;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.context.ConfigurableApplicationContext;

import javax.swing.SwingWorker;
import java.util.Map;

/**
 * CNJ02 Desktop: cửa sổ Desktop dùng JavaFX, giữ nguyên giao diện Web cũ qua WebView.
 * SwingWorker được dùng để khởi động Spring Boot ở luồng nền.
 * Không ép JavaFX dùng software rendering để tránh WebView bị lag khi cuộn.
 */
public final class CNJ02DesktopLauncher extends Application {

    private ConfigurableApplicationContext context;
    private Stage stage;

    public static void main(String[] args) {
        System.setProperty("java.awt.headless", "false");
        Application.launch(CNJ02DesktopLauncher.class, args);
    }

    @Override
    public void start(Stage primaryStage) {
        this.stage = primaryStage;

        Label loading = new Label("Đang khởi động CNJ02...");
        loading.setStyle("-fx-font-size: 20px; -fx-text-fill: #d81b60; -fx-font-weight: bold;");

        StackPane root = new StackPane(loading);
        root.setStyle("-fx-background-color: #fff5f9;");

        primaryStage.setTitle("CNJ02 - Hệ thống quản lý hồ sơ xét tuyển");
        primaryStage.setMinWidth(1180);
        primaryStage.setMinHeight(760);
        primaryStage.setWidth(1400);
        primaryStage.setHeight(900);
        primaryStage.setScene(new Scene(root));
        primaryStage.setOnCloseRequest(e -> shutdown());
        primaryStage.show();

        new StartupWorker(loading, root).execute();
    }

    private final class StartupWorker extends SwingWorker<StartupResult, Void> {
        private final Label loading;
        private final StackPane root;

        StartupWorker(Label loading, StackPane root) {
            this.loading = loading;
            this.root = root;
        }

        @Override
        protected StartupResult doInBackground() {
            ConfigurableApplicationContext ctx = startSpring();
            int port = ((org.springframework.boot.web.context.WebServerApplicationContext) ctx)
                    .getWebServer().getPort();
            return new StartupResult(ctx, "http://localhost:" + port + "/login");
        }

        @Override
        protected void done() {
            try {
                StartupResult r = get();
                context = r.context;
                Platform.runLater(() -> showWebView(r.url));
            } catch (Exception ex) {
                Platform.runLater(() -> {
                    loading.setText("Không thể khởi động CNJ02: " + rootCause(ex).getMessage());
                    loading.setStyle("-fx-font-size: 18px; -fx-text-fill: #b91c1c; -fx-wrap-text: true;");
                });
            }
        }
    }

    private static final class StartupResult {
        final ConfigurableApplicationContext context;
        final String url;
        StartupResult(ConfigurableApplicationContext context, String url) {
            this.context = context;
            this.url = url;
        }
    }

    private static ConfigurableApplicationContext startSpring() {
        SpringApplication app = new SpringApplication(com.cnj02.xettuyen.CNJ02Application.class);
        app.setWebApplicationType(WebApplicationType.SERVLET);
        app.setDefaultProperties(Map.of(
                "server.port", "0",
                "spring.application.name", "CNJ02 Desktop Offline",
                "server.address", "127.0.0.1"
        ));
        return app.run();
    }

    private void showWebView(String url) {
        WebView webView = new WebView();
        webView.setContextMenuEnabled(false);
        webView.setPrefSize(1400, 900);

        WebEngine engine = webView.getEngine();
        engine.setJavaScriptEnabled(true);
        engine.setOnStatusChanged(event -> stage.setTitle(
                event.getData() == null || event.getData().isBlank()
                        ? "CNJ02 - Hệ thống quản lý hồ sơ xét tuyển"
                        : "CNJ02 - " + event.getData()));
        engine.getLoadWorker().stateProperty().addListener((obs, oldState, newState) -> {
            if (newState == Worker.State.FAILED) {
                Throwable ex = engine.getLoadWorker().getException();
                showLoadError(url, ex);
            }
        });

        StackPane container = new StackPane(webView);
        container.setStyle("-fx-background-color: white;");
        stage.setScene(new Scene(container));
        stage.centerOnScreen();
        engine.load(url);
    }

    private void showLoadError(String url, Throwable ex) {
        String message = ex == null ? "Không xác định" : rootCause(ex).getMessage();
        Label error = new Label("Không tải được giao diện CNJ02.\nURL: " + url + "\nLỗi: " + message);
        error.setWrapText(true);
        error.setStyle("-fx-font-size: 16px; -fx-text-fill: #b91c1c; -fx-padding: 30px;");
        StackPane root = new StackPane(error);
        root.setStyle("-fx-background-color: #fff5f9;");
        stage.setScene(new Scene(root));
    }

    private static Throwable rootCause(Throwable e) {
        Throwable current = e;
        while (current.getCause() != null && current.getCause() != current) {
            current = current.getCause();
        }
        return current;
    }

    private void shutdown() {
        if (context != null) {
            try {
                context.close();
            } catch (Exception ignored) {
            }
            context = null;
        }
        Platform.exit();
    }

    @Override
    public void stop() {
        if (context != null) {
            try {
                context.close();
            } catch (Exception ignored) {
            }
            context = null;
        }
    }
}
