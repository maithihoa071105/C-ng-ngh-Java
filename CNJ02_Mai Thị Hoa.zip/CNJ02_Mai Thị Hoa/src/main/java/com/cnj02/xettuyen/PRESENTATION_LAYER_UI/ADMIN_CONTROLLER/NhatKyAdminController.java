package com.cnj02.xettuyen.PRESENTATION_LAYER_UI.ADMIN_CONTROLLER;

import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/admin/nhat-ky")
public class NhatKyAdminController {
    private final JdbcTemplate jdbc;
    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH:mm:ss");
    private static final DateTimeFormatter FULL_FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

    public NhatKyAdminController(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @GetMapping
    public String list(@RequestParam(value = "keyword", required = false) String keyword,
                       @RequestParam(value = "year", required = false) Integer year,
                       HttpSession session, Model model) {
        User u = (User) session.getAttribute("currentUser");
        if (u == null) return "redirect:/login";
        if (!Integer.valueOf(1).equals(u.getRoleId())) return "redirect:/403";

        // MySQL là nguồn thời gian chuẩn để giao diện và nhật ký dùng cùng một mốc thời gian.
        LocalDateTime serverNow = jdbc.queryForObject("SELECT NOW()", (rs, rowNum) -> {
            Timestamp ts = rs.getTimestamp(1);
            return ts == null ? LocalDateTime.now() : ts.toLocalDateTime();
        });
        int currentYear = serverNow.getYear();

        // Chỉ hiển thị lịch sử đã thực sự phát sinh trong MySQL; không mô phỏng các năm tương lai.
        boolean showFutureHistory = false;
        StringBuilder sql = new StringBuilder(
                "SELECT l.log_id,l.ho_so_id,l.user_id, " +
                "COALESCE(u.username,'Hệ thống') AS username, " +
                "COALESCE(r.role_name,'') AS role_name, " +
                "l.hanh_dong,l.thoi_gian,COALESCE(l.chi_tiet,'') AS chi_tiet " +
                "FROM HoSoLog l " +
                "LEFT JOIN `User` u ON u.user_id=l.user_id " +
                "LEFT JOIN Role r ON r.role_id=u.role_id WHERE 1=1 ");
        List<Object> args = new ArrayList<>();

        if (keyword != null && !keyword.isBlank()) {
            sql.append("AND (COALESCE(u.username,'') LIKE ? OR COALESCE(l.hanh_dong,'') LIKE ? " +
                    "OR COALESCE(l.chi_tiet,'') LIKE ? OR CAST(l.ho_so_id AS CHAR) LIKE ?) ");
            String k = "%" + keyword.trim() + "%";
            args.add(k); args.add(k); args.add(k); args.add(k);
        }
        if (year != null) {
            sql.append("AND YEAR(l.thoi_gian)=? ");
            args.add(year);
            sql.append("AND l.thoi_gian<=NOW() ");
        } else {
            sql.append("AND l.thoi_gian<=NOW() ");
        }

        // Ghi đúng hành động thật: Admin vừa mở trang nhật ký.
        try {
            jdbc.update("INSERT INTO HoSoLog(ho_so_id,user_id,hanh_dong,thoi_gian,chi_tiet) VALUES(NULL,?,?,NOW(),?)",
                    u.getUserId(), "XEM NHẬT KÝ", "Quản trị viên mở trang nhật ký hệ thống.");
        } catch (Exception ignored) { }

        sql.append("ORDER BY l.thoi_gian DESC,l.log_id DESC LIMIT 1500");
        List<Map<String, Object>> items = jdbc.queryForList(sql.toString(), args.toArray());

        for (Map<String, Object> item : items) {
            Object t = item.get("thoi_gian");
            LocalDateTime dt = null;
            if (t instanceof Timestamp ts) dt = ts.toLocalDateTime();
            else if (t instanceof LocalDateTime ldt) dt = ldt;
            if (dt != null) {
                item.put("ngay_hien_thi", dt.format(DATE_FMT));
                item.put("gio_hien_thi", dt.format(TIME_FMT));
            } else {
                item.put("ngay_hien_thi", t == null ? "" : String.valueOf(t));
                item.put("gio_hien_thi", "");
            }
        }

        // Các chỉ số mặc định luôn phản ánh lịch sử đã xảy ra đến thời điểm hiện tại.
        Long total = jdbc.queryForObject("SELECT COUNT(*) FROM HoSoLog WHERE thoi_gian<=NOW()", Long.class);
        Long today = jdbc.queryForObject("SELECT COUNT(*) FROM HoSoLog WHERE DATE(thoi_gian)=CURDATE()", Long.class);
        Long loginCount = jdbc.queryForObject("SELECT COUNT(*) FROM HoSoLog WHERE hanh_dong='ĐĂNG NHẬP' AND thoi_gian<=NOW()", Long.class);
        Long processingCount = jdbc.queryForObject(
                "SELECT COUNT(*) FROM HoSoLog WHERE thoi_gian<=NOW() AND " +
                "(hanh_dong LIKE '%HỒ SƠ%' OR hanh_dong LIKE '%TRẠNG THÁI%')", Long.class);

        model.addAttribute("items", items);
        model.addAttribute("keyword", keyword == null ? "" : keyword);
        model.addAttribute("year", year);
        model.addAttribute("currentYear", currentYear);
        model.addAttribute("showFutureHistory", showFutureHistory);
        model.addAttribute("serverNow", serverNow.format(FULL_FMT));
        model.addAttribute("currentUser", u);
        model.addAttribute("user", u);
        model.addAttribute("isStaff", false);
        model.addAttribute("tabId", "nhatky");
        model.addAttribute("totalLogs", total == null ? 0 : total);
        model.addAttribute("todayLogs", today == null ? 0 : today);
        model.addAttribute("loginLogs", loginCount == null ? 0 : loginCount);
        model.addAttribute("processingLogs", processingCount == null ? 0 : processingCount);

        return "VIEW/ADMIN/nhat-ky";
    }
}
