package com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.REPOSITORY;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class DashboardRepository {
    @PersistenceContext
    private EntityManager em;

    public long countUsers() {
        return ((Number) em.createNativeQuery("SELECT COUNT(*) FROM `User`").getSingleResult()).longValue();
    }

    public long countHoSo() {
        return ((Number) em.createNativeQuery("SELECT COUNT(*) FROM HoSo WHERE YEAR(ngay_nop)=2026").getSingleResult()).longValue();
    }

    public long countNganh() {
        return ((Number) em.createNativeQuery("SELECT COUNT(*) FROM Nganh WHERE trang_thai='DANG_TUYEN_SINH'").getSingleResult()).longValue();
    }

    public long totalChiTieu() {
        return ((Number) em.createNativeQuery(
                "SELECT COALESCE(SUM(ct.so_luong),0) FROM ChiTieu ct " +
                "JOIN Nganh n ON n.nganh_id=ct.nganh_id AND n.trang_thai='DANG_TUYEN_SINH' " +
                "JOIN PhuongThucXetTuyen p ON p.phuong_thuc_id=ct.phuong_thuc_id AND p.trang_thai='ACTIVE' " +
                "WHERE ct.nam_hoc=2026").getSingleResult()).longValue();
    }

    public List<Object[]> status() {
        return em.createNativeQuery(
                "SELECT trang_thai,COUNT(*) FROM HoSo WHERE YEAR(ngay_nop)=2026 " +
                "GROUP BY trang_thai ORDER BY COUNT(*) DESC").getResultList();
    }

    public List<Object[]> month(int year) {
        return em.createNativeQuery(
                "SELECT m.thang,COUNT(hs.ho_so_id) " +
                "FROM (SELECT 1 AS thang UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 " +
                "UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 " +
                "UNION ALL SELECT 9 UNION ALL SELECT 10) m " +
                "LEFT JOIN HoSo hs ON MONTH(hs.ngay_nop)=m.thang AND YEAR(hs.ngay_nop)=2026 " +
                "GROUP BY m.thang ORDER BY m.thang").getResultList();
    }

    public List<Object[]> method() {
        return em.createNativeQuery(
                "SELECT pt.ten_phuong_thuc,COUNT(hs.ho_so_id) " +
                "FROM PhuongThucXetTuyen pt " +
                "LEFT JOIN HoSo hs ON hs.phuong_thuc_id=pt.phuong_thuc_id AND YEAR(hs.ngay_nop)=2026 " +
                "WHERE pt.trang_thai='ACTIVE' " +
                "GROUP BY pt.phuong_thuc_id,pt.ten_phuong_thuc ORDER BY COUNT(hs.ho_so_id) DESC").getResultList();
    }

    public List<Object[]> major() {
        return em.createNativeQuery(
                "SELECT n.ten_nganh,COUNT(DISTINCT hs.ho_so_id) AS so_luong " +
                "FROM Nganh n " +
                "LEFT JOIN NguyenVong nv ON nv.nganh_id=n.nganh_id AND nv.thu_tu_nguyen_vong=1 " +
                "LEFT JOIN HoSo hs ON hs.ho_so_id=nv.ho_so_id AND YEAR(hs.ngay_nop)=2026 " +
                "WHERE n.trang_thai='DANG_TUYEN_SINH' " +
                "GROUP BY n.nganh_id,n.ten_nganh ORDER BY so_luong DESC,n.nganh_id LIMIT 10").getResultList();
    }

    public List<Object[]> table() {
        return em.createNativeQuery(
                "SELECT n.ten_nganh,n.khoa, " +
                "COALESCE((SELECT SUM(ct.so_luong) FROM ChiTieu ct " +
                "JOIN PhuongThucXetTuyen p ON p.phuong_thuc_id=ct.phuong_thuc_id AND p.trang_thai='ACTIVE' " +
                "WHERE ct.nganh_id=n.nganh_id AND ct.nam_hoc=2026),0) AS quota, " +
                "COUNT(DISTINCT hs.ho_so_id) AS apps, " +
                "COUNT(DISTINCT CASE WHEN kq.trang_thai_ket_qua='TRUNG_TUYEN' THEN kq.ho_so_id END) AS admitted " +
                "FROM Nganh n " +
                "LEFT JOIN NguyenVong nv ON nv.nganh_id=n.nganh_id AND nv.thu_tu_nguyen_vong=1 " +
                "LEFT JOIN HoSo hs ON hs.ho_so_id=nv.ho_so_id AND YEAR(hs.ngay_nop)=2026 " +
                "LEFT JOIN KetQua kq ON kq.ho_so_id=hs.ho_so_id AND kq.nganh_id=nv.nganh_id " +
                "WHERE n.trang_thai='DANG_TUYEN_SINH' " +
                "GROUP BY n.nganh_id,n.ten_nganh,n.khoa ORDER BY apps DESC,n.nganh_id").getResultList();
    }

    public Object[] admissionSummary() {
        return (Object[]) em.createNativeQuery(
                "SELECT SUM(CASE WHEN kq.trang_thai_ket_qua='TRUNG_TUYEN' THEN 1 ELSE 0 END), " +
                "SUM(CASE WHEN kq.trang_thai_ket_qua IN ('TRUNG_TUYEN','KHONG_TRUNG_TUYEN') THEN 1 ELSE 0 END) " +
                "FROM KetQua kq JOIN HoSo h ON h.ho_so_id=kq.ho_so_id WHERE YEAR(h.ngay_nop)=2026").getSingleResult();
    }

    public List<Object[]> faculty() {
        return em.createNativeQuery(
                "SELECT n.khoa,COUNT(DISTINCT hs.ho_so_id) AS apps, " +
                "COUNT(DISTINCT CASE WHEN kq.trang_thai_ket_qua='TRUNG_TUYEN' THEN kq.ho_so_id END) AS admitted " +
                "FROM Nganh n " +
                "LEFT JOIN NguyenVong nv ON nv.nganh_id=n.nganh_id AND nv.thu_tu_nguyen_vong=1 " +
                "LEFT JOIN HoSo hs ON hs.ho_so_id=nv.ho_so_id AND YEAR(hs.ngay_nop)=2026 " +
                "LEFT JOIN KetQua kq ON kq.ho_so_id=hs.ho_so_id AND kq.nganh_id=nv.nganh_id " +
                "WHERE n.trang_thai='DANG_TUYEN_SINH' GROUP BY n.khoa ORDER BY apps DESC,n.khoa").getResultList();
    }

    public List<Object[]> years() {
        return em.createNativeQuery(
                "SELECT y.nam_hoc, " +
                "CASE WHEN y.nam_hoc=2026 THEN 'ĐANG TUYỂN SINH' ELSE 'CHƯA ĐẾN KỲ TUYỂN SINH' END AS trang_thai, " +
                "COALESCE((SELECT SUM(ct.so_luong) FROM ChiTieu ct WHERE ct.nam_hoc=y.nam_hoc),0) AS quota, " +
                "CASE WHEN y.nam_hoc=2026 THEN (SELECT COUNT(*) FROM HoSo WHERE YEAR(ngay_nop)=2026) ELSE 0 END AS apps, " +
                "CASE WHEN y.nam_hoc=2026 THEN (SELECT COUNT(DISTINCT k.ho_so_id) FROM KetQua k JOIN HoSo h ON h.ho_so_id=k.ho_so_id WHERE YEAR(h.ngay_nop)=2026 AND k.trang_thai_ket_qua IN ('TRUNG_TUYEN','KHONG_TRUNG_TUYEN')) ELSE 0 END AS decided, " +
                "CASE WHEN y.nam_hoc=2026 THEN (SELECT COUNT(DISTINCT k.ho_so_id) FROM KetQua k JOIN HoSo h ON h.ho_so_id=k.ho_so_id WHERE YEAR(h.ngay_nop)=2026 AND k.trang_thai_ket_qua='TRUNG_TUYEN') ELSE 0 END AS admitted " +
                "FROM (SELECT 2026 AS nam_hoc UNION ALL SELECT 2027 UNION ALL SELECT 2028 UNION ALL SELECT 2029 UNION ALL SELECT 2030) y " +
                "ORDER BY y.nam_hoc").getResultList();
    }

    public List<Object[]> majorAnalytics() {
        return em.createNativeQuery(
                "SELECT n.khoa,n.ma_nganh,n.ten_nganh,COUNT(DISTINCT hs.ho_so_id) AS apps, " +
                "COUNT(DISTINCT CASE WHEN kq.trang_thai_ket_qua='TRUNG_TUYEN' THEN kq.ho_so_id END) AS admitted, " +
                "COALESCE((SELECT SUM(ct.so_luong) FROM ChiTieu ct " +
                "JOIN PhuongThucXetTuyen p ON p.phuong_thuc_id=ct.phuong_thuc_id AND p.trang_thai='ACTIVE' " +
                "WHERE ct.nganh_id=n.nganh_id AND ct.nam_hoc=2026),0) AS quota " +
                "FROM Nganh n " +
                "LEFT JOIN NguyenVong nv ON nv.nganh_id=n.nganh_id AND nv.thu_tu_nguyen_vong=1 " +
                "LEFT JOIN HoSo hs ON hs.ho_so_id=nv.ho_so_id AND YEAR(hs.ngay_nop)=2026 " +
                "LEFT JOIN KetQua kq ON kq.ho_so_id=hs.ho_so_id AND kq.nganh_id=nv.nganh_id " +
                "WHERE n.trang_thai='DANG_TUYEN_SINH' " +
                "GROUP BY n.nganh_id,n.khoa,n.ma_nganh,n.ten_nganh ORDER BY apps DESC,n.nganh_id").getResultList();
    }
}
