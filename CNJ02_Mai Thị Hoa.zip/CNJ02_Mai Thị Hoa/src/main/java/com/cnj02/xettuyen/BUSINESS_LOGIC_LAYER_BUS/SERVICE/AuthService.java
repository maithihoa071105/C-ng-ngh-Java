package com.cnj02.xettuyen.BUSINESS_LOGIC_LAYER_BUS.SERVICE;

import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.User;
import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.REPOSITORY.UserRepository;
import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.REPOSITORY.SinhVienRepository;
import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.SinhVien;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired private SinhVienRepository sinhVienRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JdbcTemplate jdbc;


    // =====================================================
    // ĐĂNG NHẬP
    // =====================================================

    public User login(String username, String rawPassword) {
        if (username == null || rawPassword == null || rawPassword.isBlank()) return null;
        String clean = username.trim();
        if (clean.isEmpty()) return null;

        List<Map<String,Object>> rows = jdbc.queryForList(
                "SELECT user_id,username,password,email,phone,role_id,status,created_at " +
                "FROM `User` WHERE LOWER(TRIM(username))=LOWER(TRIM(?)) LIMIT 1", clean);

        // Tạo lại đúng 3 tài khoản mẫu nếu DB của máy sinh viên bị thiếu tài khoản.
        if (rows.isEmpty() && "123456".equals(rawPassword)) {
            Integer role = knownRole(clean);
            if (role != null) {
                String email = clean.equalsIgnoreCase("admin") ? "admin@gmail.com" :
                        clean.equalsIgnoreCase("canbo") ? "canbo@gmail.com" : "maihoa@gmail.com";
                String phone = clean.equalsIgnoreCase("canbo") ? "0911223344" : "0912345678";
                jdbc.update("INSERT INTO `User`(username,password,email,phone,role_id,status) VALUES(?,?,?,?,?,'ACTIVE')",
                        clean, passwordEncoder.encode(rawPassword), email, phone, role);
                rows = jdbc.queryForList("SELECT user_id,username,password,email,phone,role_id,status,created_at FROM `User` WHERE LOWER(TRIM(username))=LOWER(TRIM(?)) LIMIT 1", clean);
            }
        }
        if (rows.isEmpty()) return null;

        Map<String,Object> r = rows.get(0);
        int userId = ((Number)r.get("user_id")).intValue();
        String dbUsername = String.valueOf(r.get("username"));
        String status = r.get("status") == null ? "ACTIVE" : String.valueOf(r.get("status")).trim();
        String hash = r.get("password") == null ? "" : String.valueOf(r.get("password"));

        // Với 3 tài khoản mẫu, luôn sửa lại mật khẩu/trạng thái nếu dữ liệu cũ bị sai.
        if ("123456".equals(rawPassword) && knownRole(clean) != null) {
            if (!passwordEncoder.matches(rawPassword, hash) || !"ACTIVE".equalsIgnoreCase(status)) {
                hash = passwordEncoder.encode(rawPassword);
                jdbc.update("UPDATE `User` SET password=?,role_id=?,status='ACTIVE' WHERE user_id=?",
                        hash, knownRole(clean), userId);
                status = "ACTIVE";
            }
        }
        if (!"ACTIVE".equalsIgnoreCase(status)) return null;
        if (hash.isBlank() || !passwordEncoder.matches(rawPassword, hash)) return null;

        User u = new User();
        u.setUserId(userId);
        u.setUsername(dbUsername);
        u.setPassword(hash);
        u.setEmail(r.get("email") == null ? "" : String.valueOf(r.get("email")));
        u.setPhone(r.get("phone") == null ? null : String.valueOf(r.get("phone")));
        u.setRoleId(((Number)r.get("role_id")).intValue());
        u.setStatus(status);
        if (r.get("created_at") instanceof java.sql.Timestamp ts) u.setCreatedAt(ts.toLocalDateTime());
        return u;
    }

    private Integer knownRole(String username) {
        if ("admin".equalsIgnoreCase(username)) return 1;
        if ("canbo".equalsIgnoreCase(username)) return 2;
        if ("Maihoa".equalsIgnoreCase(username)) return 3;
        return null;
    }


    // =====================================================
    // ĐĂNG KÝ SINH VIÊN
    // =====================================================

    @Transactional
    public User registerUserAndSinhVien(
            String username,
            String password,
            String email,
            String phone,
            String hoTen,
            String cccd,
            String gioiTinh,
            String ngaySinh) {

        // -------------------------
        // Kiểm tra dữ liệu
        // -------------------------

        if (username == null || username.trim().isEmpty()) {
            throw new RuntimeException("Tên đăng nhập không được để trống!");
        }

        if (password == null || password.length() < 6) {
            throw new RuntimeException(
                    "Mật khẩu phải có ít nhất 6 ký tự!"
            );
        }

        if (email == null || email.trim().isEmpty()) {
            throw new RuntimeException("Email không được để trống!");
        }

        username = username.trim();
        email = email.trim();

        // -------------------------
        // Kiểm tra username
        // -------------------------

        if (userRepository.findByUsername(username).isPresent()) {

            throw new RuntimeException(
                    "Tên đăng nhập đã tồn tại!"
            );
        }

        // -------------------------
        // Kiểm tra email
        // -------------------------

        if (userRepository.existsByEmail(email)) {

            throw new RuntimeException(
                    "Email đã được sử dụng!"
            );
        }

        if (cccd == null || cccd.trim().isEmpty()) {
            throw new RuntimeException("CCCD/CMND không được để trống!");
        }
        if (hoTen == null || hoTen.trim().isEmpty()) {
            throw new RuntimeException("Họ và tên không được để trống!");
        }
        Integer duplicateCccd = jdbc.queryForObject(
                "SELECT COUNT(*) FROM SinhVien WHERE cccd=?", Integer.class, cccd.trim());
        if (duplicateCccd != null && duplicateCccd > 0) {
            throw new RuntimeException("CCCD/CMND đã được đăng ký!");
        }

        // Tạo User bằng JDBC để không phụ thuộc vào phiên bản schema SinhVien cũ.
        // Đây cũng giúp tài khoản mới luôn ghi đúng vào CSDL MySQL hiện tại.
        String encodedPassword = passwordEncoder.encode(password);
        jdbc.update("INSERT INTO `User`(username,password,email,phone,role_id,status) VALUES(?,?,?,?,3,'ACTIVE')",
                username, encodedPassword, email, phone == null || phone.isBlank() ? null : phone.trim());
        Integer userId = jdbc.queryForObject("SELECT LAST_INSERT_ID()", Integer.class);
        LocalDate dob = (ngaySinh == null || ngaySinh.isBlank()) ? null : LocalDate.parse(ngaySinh);
        jdbc.update("INSERT INTO SinhVien(user_id,ho_ten,cccd,ngay_sinh,gioi_tinh) VALUES(?,?,?,?,?)",
                userId, hoTen.trim(), cccd.trim(), dob, gioiTinh);

        User savedUser = new User();
        savedUser.setUserId(userId);
        savedUser.setUsername(username);
        savedUser.setPassword(encodedPassword);
        savedUser.setEmail(email);
        savedUser.setPhone(phone == null || phone.isBlank() ? null : phone.trim());
        savedUser.setRoleId(3);
        savedUser.setStatus("ACTIVE");
        return savedUser;
    }
}