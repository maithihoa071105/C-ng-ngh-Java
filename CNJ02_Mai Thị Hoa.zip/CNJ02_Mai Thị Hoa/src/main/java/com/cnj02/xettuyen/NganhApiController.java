package com.cnj02.xettuyen;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.Nganh;
import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.REPOSITORY.NganhRepository;

import java.util.List;

@RestController
@RequestMapping("/api/nganh")
public class NganhApiController {

    @Autowired
    private NganhRepository nganhRepository;

    // 1. Lay danh sach (Hoac Tim kiem)
    @GetMapping
    public List<Nganh> getAllNganh(@RequestParam(required = false) String keyword) {
        if (keyword != null && !keyword.trim().isEmpty()) {
            return nganhRepository.findByMaNganhContainingIgnoreCaseOrTenNganhContainingIgnoreCase(keyword, keyword);
        }
        return nganhRepository.findAll();
    }

    // 2. Them moi
    @PostMapping
    public Nganh createNganh(@RequestBody Nganh nganh) {
        return nganhRepository.save(nganh);
    }

    // 3. Cap nhat (Sua)
    @PutMapping("/{id}")
    public Nganh updateNganh(@PathVariable Integer id, @RequestBody Nganh nganhDetails) {
        Nganh nganh = nganhRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Khong tim thay Nganh voi ID: " + id));
        
        nganh.setMaNganh(nganhDetails.getMaNganh());
        nganh.setTenNganh(nganhDetails.getTenNganh());
        nganh.setMoTa(nganhDetails.getMoTa());
        nganh.setKhoa(nganhDetails.getKhoa());
        nganh.setTrangThai(nganhDetails.getTrangThai());
        
        return nganhRepository.save(nganh);
    }

    // 4. Xoa
    @DeleteMapping("/{id}")
    public String deleteNganh(@PathVariable Integer id) {
        nganhRepository.deleteById(id);
        return "Da xoa thanh cong nganh ID: " + id;
    }
}