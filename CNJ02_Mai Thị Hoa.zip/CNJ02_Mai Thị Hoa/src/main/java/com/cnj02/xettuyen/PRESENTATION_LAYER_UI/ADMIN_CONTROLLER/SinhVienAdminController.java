package com.cnj02.xettuyen.PRESENTATION_LAYER_UI.ADMIN_CONTROLLER;

import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller @RequestMapping("/admin")
public class SinhVienAdminController {
    private final JdbcTemplate jdbc;
    public SinhVienAdminController(JdbcTemplate jdbc){this.jdbc=jdbc;}
    private boolean ok(HttpSession s){ User u=(User)s.getAttribute("currentUser"); return u!=null&&Integer.valueOf(1).equals(u.getRoleId()); }
    @GetMapping("/sinh-vien") public String list(HttpSession s, Model m){
        if(!ok(s)) return "redirect:/403";
        m.addAttribute("items", jdbc.queryForList("SELECT sv.sinh_vien_id AS sinhVienId,sv.user_id AS userId,sv.ho_ten AS hoTen,sv.cccd,sv.ngay_sinh AS ngaySinh,sv.gioi_tinh AS gioiTinh,sv.dia_chi AS diaChi,sv.truong_thpt AS truongThpt FROM SinhVien sv ORDER BY sv.sinh_vien_id"));
        m.addAttribute("form", new com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.SinhVien());
        return "VIEW/ADMIN/sinh-vien";
    }
    @GetMapping("/sinh-vien/edit/{id}") public String edit(HttpSession s,@PathVariable Integer id,Model m){
        if(!ok(s)) return "redirect:/403";
        var rows=jdbc.queryForList("SELECT sinh_vien_id AS sinhVienId,user_id AS userId,ho_ten AS hoTen,cccd,ngay_sinh AS ngaySinh,gioi_tinh AS gioiTinh,dia_chi AS diaChi,truong_thpt AS truongThpt FROM SinhVien WHERE sinh_vien_id=?",id);
        m.addAttribute("items",jdbc.queryForList("SELECT sinh_vien_id AS sinhVienId,user_id AS userId,ho_ten AS hoTen,cccd,ngay_sinh AS ngaySinh,gioi_tinh AS gioiTinh,dia_chi AS diaChi,truong_thpt AS truongThpt FROM SinhVien ORDER BY sinh_vien_id"));
        if(!rows.isEmpty()){
            var r=rows.get(0); var x=new com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.SinhVien();
            x.setSinhVienId(((Number)r.get("sinhVienId")).intValue()); x.setUserId(((Number)r.get("userId")).intValue()); x.setHoTen((String)r.get("hoTen")); x.setCccd((String)r.get("cccd"));
            if(r.get("ngaySinh") instanceof java.sql.Date d)x.setNgaySinh(d.toLocalDate()); x.setGioiTinh((String)r.get("gioiTinh")); x.setDiaChi((String)r.get("diaChi")); x.setTruongThpt((String)r.get("truongThpt")); m.addAttribute("form",x);
        } else m.addAttribute("form",new com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.SinhVien());
        return "VIEW/ADMIN/sinh-vien";
    }
    @PostMapping("/sinh-vien/save") public String save(HttpSession s,@ModelAttribute com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.SinhVien x){
        if(!ok(s)) return "redirect:/403";
        try{ if(x.getSinhVienId()==null) jdbc.update("INSERT INTO SinhVien(user_id,ho_ten,cccd,ngay_sinh,gioi_tinh,dia_chi,truong_thpt) VALUES(?,?,?,?,?,?,?)",x.getUserId(),x.getHoTen(),x.getCccd(),x.getNgaySinh(),x.getGioiTinh(),x.getDiaChi(),x.getTruongThpt());
        else jdbc.update("UPDATE SinhVien SET user_id=?,ho_ten=?,cccd=?,ngay_sinh=?,gioi_tinh=?,dia_chi=?,truong_thpt=? WHERE sinh_vien_id=?",x.getUserId(),x.getHoTen(),x.getCccd(),x.getNgaySinh(),x.getGioiTinh(),x.getDiaChi(),x.getTruongThpt(),x.getSinhVienId());
        return "redirect:/admin/sinh-vien?success=saved";}catch(Exception e){return "redirect:/admin/sinh-vien?error="+java.net.URLEncoder.encode(e.getMessage()==null?"Không thể lưu":e.getMessage(),java.nio.charset.StandardCharsets.UTF_8);}
    }
    @PostMapping("/sinh-vien/delete/{id}") public String del(HttpSession s,@PathVariable Integer id){if(!ok(s))return "redirect:/403";try{jdbc.update("DELETE FROM SinhVien WHERE sinh_vien_id=?",id);return "redirect:/admin/sinh-vien?success=deleted";}catch(Exception e){return "redirect:/admin/sinh-vien?error=delete";}}
}
