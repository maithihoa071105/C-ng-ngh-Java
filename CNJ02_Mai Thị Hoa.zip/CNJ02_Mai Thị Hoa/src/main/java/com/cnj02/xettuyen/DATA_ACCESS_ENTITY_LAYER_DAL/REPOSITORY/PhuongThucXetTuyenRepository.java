package com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.REPOSITORY;
import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.PhuongThucXetTuyen; import org.springframework.data.jpa.repository.JpaRepository;
public interface PhuongThucXetTuyenRepository extends JpaRepository<PhuongThucXetTuyen,Integer>{ boolean existsByMaPhuongThuc(String maPhuongThuc); }
