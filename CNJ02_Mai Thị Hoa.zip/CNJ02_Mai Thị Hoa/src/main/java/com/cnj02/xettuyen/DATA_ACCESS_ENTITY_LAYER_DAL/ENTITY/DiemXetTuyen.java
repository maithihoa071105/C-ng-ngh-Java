package com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name="DiemXetTuyen")
public class DiemXetTuyen {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="diem_id")
    private Integer diemId;

    @Column(name="ho_so_id")
    private Integer hoSoId;

    @Column(name="ten_mon")
    private String tenMon;

    @Column(name="diem_so")
    private Double diemSo;

    public DiemXetTuyen(){}

    public Integer getDiemId(){return diemId;}
    public void setDiemId(Integer v){this.diemId=v;}

    public Integer getHoSoId(){return hoSoId;}
    public void setHoSoId(Integer v){this.hoSoId=v;}

    public String getTenMon(){return tenMon;}
    public void setTenMon(String v){this.tenMon=v;}

    public Double getDiemSo(){return diemSo;}
    public void setDiemSo(Double v){this.diemSo=v;}

}
