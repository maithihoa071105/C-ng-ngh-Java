package com.cnj02.xettuyen.PRESENTATION_LAYER_UI.ADMIN_CONTROLLER;

import com.cnj02.xettuyen.BUSINESS_LOGIC_LAYER_BUS.SERVICE.AdminDataService;
import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.Nganh;
import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin")
public class NganhAdminController {
    private final AdminDataService s;
    public NganhAdminController(AdminDataService s){this.s=s;}
    private boolean ok(HttpSession ss){User u=(User)ss.getAttribute("currentUser");return u!=null&&Integer.valueOf(1).equals(u.getRoleId());}
    private void hot(Model m){
        Object code=s.hotMajorCode();
        m.addAttribute("hotMajorCode", code==null?"":String.valueOf(code));
    }
    @GetMapping("/nganh") public String list(HttpSession ss,Model m){if(!ok(ss))return "redirect:/403";m.addAttribute("items",s.nganh());m.addAttribute("form",new Nganh());hot(m);return "VIEW/ADMIN/nganh";}
    @GetMapping("/nganh/edit/{id}") public String edit(HttpSession ss,@PathVariable Integer id,Model m){if(!ok(ss))return "redirect:/403";m.addAttribute("items",s.nganh());m.addAttribute("form",s.getNganh(id));hot(m);return "VIEW/ADMIN/nganh";}
    @PostMapping("/nganh/save") public String save(HttpSession ss,@ModelAttribute("form") Nganh x){if(!ok(ss))return "redirect:/403";s.saveNganh(x);return "redirect:/admin/nganh?success=saved";}
    @PostMapping("/nganh/delete/{id}") public String del(HttpSession ss,@PathVariable Integer id){if(!ok(ss))return "redirect:/403";try{s.deleteNganh(id);return "redirect:/admin/nganh?success=deleted";}catch(DataIntegrityViolationException e){return "redirect:/admin/nganh?error=used";}}
}
