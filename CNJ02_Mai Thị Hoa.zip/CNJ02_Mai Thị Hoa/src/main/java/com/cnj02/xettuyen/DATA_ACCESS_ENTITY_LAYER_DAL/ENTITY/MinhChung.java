package com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name="MinhChung")
public class MinhChung {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="minh_chung_id")
    private Integer minhChungId;

    @Column(name="ho_so_id")
    private Integer hoSoId;

    @Column(name="ten_minh_chung")
    private String tenMinhChung;

    @Column(name="file_path")
    private String filePath;

    @Column(name="loai_minh_chung")
    private String loaiMinhChung;

    @Lob
    @Column(name="du_lieu")
    private byte[] duLieu;

    @Column(name="mime_type")
    private String mimeType;

    @Column(name="kich_thuoc")
    private Long kichThuoc;

    public MinhChung(){}

    public Integer getMinhChungId(){return minhChungId;}
    public void setMinhChungId(Integer v){this.minhChungId=v;}

    public Integer getHoSoId(){return hoSoId;}
    public void setHoSoId(Integer v){this.hoSoId=v;}

    public String getTenMinhChung(){return tenMinhChung;}
    public void setTenMinhChung(String v){this.tenMinhChung=v;}

    public String getFilePath(){return filePath;}
    public void setFilePath(String v){this.filePath=v;}

    public String getLoaiMinhChung(){return loaiMinhChung;}
    public void setLoaiMinhChung(String v){this.loaiMinhChung=v;}
    public byte[] getDuLieu(){return duLieu;} public void setDuLieu(byte[] v){this.duLieu=v;}
    public String getMimeType(){return mimeType;} public void setMimeType(String v){this.mimeType=v;}
    public Long getKichThuoc(){return kichThuoc;} public void setKichThuoc(Long v){this.kichThuoc=v;}

}
