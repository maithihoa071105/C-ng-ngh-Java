package com.cnj02.xettuyen.PRESENTATION_LAYER_UI.ADMIN_CONTROLLER;

import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/admin")
public class DiemXetTuyenAdminController {
    private final JdbcTemplate jdbc;

    public DiemXetTuyenAdminController(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    private boolean ok(HttpSession session) {
        User user = (User) session.getAttribute("currentUser");
        return user != null && Integer.valueOf(2).equals(user.getRoleId());
    }

    @GetMapping("/diem")
    public String list(HttpSession session, Model model) {
        if (!ok(session)) return "redirect:/403";

        // Gom các môn điểm theo hồ sơ để mỗi hồ sơ chỉ có một dòng.
        List<Map<String, Object>> rows = jdbc.queryForList(
                "SELECT d.ho_so_id AS hoSoId, d.ten_mon AS tenMon, d.diem_so AS diemSo, " +
                "COALESCE(hs.to_hop,'') AS toHop, COALESCE(sv.ho_ten,'') AS hoTen " +
                "FROM DiemXetTuyen d " +
                "JOIN HoSo hs ON hs.ho_so_id=d.ho_so_id " +
                "JOIN SinhVien sv ON sv.sinh_vien_id=hs.sinh_vien_id " +
                "ORDER BY d.ho_so_id, d.diem_id");

        Map<Integer, Map<String, Object>> grouped = new LinkedHashMap<>();
        for (Map<String, Object> row : rows) {
            Integer hoSoId = ((Number) row.get("hoSoId")).intValue();
            Map<String, Object> item = grouped.get(hoSoId);
            if (item == null) {
                item = new LinkedHashMap<>();
                item.put("hoSoId", hoSoId);
                item.put("hoTen", row.get("hoTen"));
                item.put("toHop", row.get("toHop"));
                item.put("scores", new ArrayList<Map<String, Object>>());
                item.put("total", BigDecimal.ZERO);
                grouped.put(hoSoId, item);
            }

            @SuppressWarnings("unchecked")
            List<Map<String, Object>> scores = (List<Map<String, Object>>) item.get("scores");
            Map<String, Object> score = new LinkedHashMap<>();
            score.put("tenMon", row.get("tenMon"));
            score.put("diemSo", row.get("diemSo"));
            scores.add(score);

            BigDecimal point = row.get("diemSo") == null
                    ? BigDecimal.ZERO
                    : new BigDecimal(String.valueOf(row.get("diemSo")));
            item.put("total", ((BigDecimal) item.get("total")).add(point));
        }

        model.addAttribute("items", new ArrayList<>(grouped.values()));
        model.addAttribute("isStaff", true);
        model.addAttribute("tabId", "diem");
        model.addAttribute("currentUser", session.getAttribute("currentUser"));
        return "VIEW/ADMIN/diem";
    }
}
