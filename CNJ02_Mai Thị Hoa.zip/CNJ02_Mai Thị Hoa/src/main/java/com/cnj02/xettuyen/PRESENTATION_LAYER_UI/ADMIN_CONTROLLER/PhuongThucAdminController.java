package com.cnj02.xettuyen.PRESENTATION_LAYER_UI.ADMIN_CONTROLLER;

import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin")
public class PhuongThucAdminController {
    private final JdbcTemplate jdbc;
    public PhuongThucAdminController(JdbcTemplate jdbc){this.jdbc=jdbc;}
    private boolean ok(HttpSession s){User u=(User)s.getAttribute("currentUser");return u!=null&&Integer.valueOf(1).equals(u.getRoleId());}

    @GetMapping("/phuong-thuc")
    public String list(HttpSession s, Model m){
        if(!ok(s)) return "redirect:/403";
        m.addAttribute("items", jdbc.queryForList("SELECT phuong_thuc_id phuongThucId,ma_phuong_thuc maPhuongThuc,ten_phuong_thuc tenPhuongThuc,COALESCE(mo_ta,'') moTa FROM PhuongThucXetTuyen ORDER BY phuong_thuc_id"));
        m.addAttribute("form", new Form());
        return "VIEW/ADMIN/phuong-thuc";
    }

    @GetMapping("/phuong-thuc/edit/{id}")
    public String edit(HttpSession s,@PathVariable Integer id,Model m){
        if(!ok(s)) return "redirect:/403";
        var rows=jdbc.queryForList("SELECT phuong_thuc_id,ma_phuong_thuc,ten_phuong_thuc,mo_ta FROM PhuongThucXetTuyen WHERE phuong_thuc_id=?",id);
        if(rows.isEmpty()) return "redirect:/admin/phuong-thuc?error=notfound";
        var r=rows.get(0); Form f=new Form(); f.id=((Number)r.get("phuong_thuc_id")).intValue(); f.code=String.valueOf(r.get("ma_phuong_thuc")); f.name=String.valueOf(r.get("ten_phuong_thuc")); f.description=r.get("mo_ta")==null?"":String.valueOf(r.get("mo_ta"));
        m.addAttribute("items",jdbc.queryForList("SELECT phuong_thuc_id phuongThucId,ma_phuong_thuc maPhuongThuc,ten_phuong_thuc tenPhuongThuc,COALESCE(mo_ta,'') moTa FROM PhuongThucXetTuyen ORDER BY phuong_thuc_id"));
        m.addAttribute("form",f); return "VIEW/ADMIN/phuong-thuc";
    }

    @PostMapping("/phuong-thuc/save")
    public String save(HttpSession s,@RequestParam(required=false) Integer phuongThucId,@RequestParam String maPhuongThuc,@RequestParam String tenPhuongThuc,@RequestParam(required=false) String moTa){
        if(!ok(s)) return "redirect:/403";
        if(phuongThucId==null) jdbc.update("INSERT INTO PhuongThucXetTuyen(ma_phuong_thuc,ten_phuong_thuc,mo_ta) VALUES(?,?,?)",maPhuongThuc.trim(),tenPhuongThuc.trim(),moTa);
        else jdbc.update("UPDATE PhuongThucXetTuyen SET ma_phuong_thuc=?,ten_phuong_thuc=?,mo_ta=? WHERE phuong_thuc_id=?",maPhuongThuc.trim(),tenPhuongThuc.trim(),moTa,phuongThucId);
        return "redirect:/admin/phuong-thuc?success=saved";
    }
    @PostMapping("/phuong-thuc/delete/{id}") public String del(HttpSession s,@PathVariable Integer id){if(!ok(s))return "redirect:/403";try{jdbc.update("DELETE FROM PhuongThucXetTuyen WHERE phuong_thuc_id=?",id);return "redirect:/admin/phuong-thuc?success=deleted";}catch(Exception e){return "redirect:/admin/phuong-thuc?error=used";}}

    public static class Form { public Integer id; public String code=""; public String name=""; public String description=""; public Integer getId(){return id;} public String getCode(){return code;} public String getName(){return name;} public String getDescription(){return description;} }
}
