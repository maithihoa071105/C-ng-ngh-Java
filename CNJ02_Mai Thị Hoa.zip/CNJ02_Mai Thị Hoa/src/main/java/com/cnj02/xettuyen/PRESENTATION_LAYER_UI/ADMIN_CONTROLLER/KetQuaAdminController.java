package com.cnj02.xettuyen.PRESENTATION_LAYER_UI.ADMIN_CONTROLLER;

import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/admin")
public class KetQuaAdminController {
    private final JdbcTemplate jdbc;

    public KetQuaAdminController(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    private boolean ok(HttpSession session) {
        User u = (User) session.getAttribute("currentUser");
        return u != null && Integer.valueOf(2).equals(u.getRoleId());
    }

    @GetMapping("/ket-qua")
    public String list(HttpSession session, Model model) {
        if (!ok(session)) return "redirect:/403";
        model.addAttribute("items", jdbc.queryForList(
                "SELECT k.ket_qua_id AS ketQuaId, k.ho_so_id AS hoSoId, " +
                "k.nganh_id AS nganhId, n.ma_nganh, n.ten_nganh, " +
                "k.diem_xet_tuyen AS diemXetTuyen, " +
                "k.trang_thai_ket_qua AS trangThaiKetQua, k.ngay_cap_nhat AS ngayCapNhat " +
                "FROM KetQua k LEFT JOIN Nganh n ON n.nganh_id=k.nganh_id " +
                "ORDER BY k.ket_qua_id DESC"));
        model.addAttribute("isStaff", true);
        model.addAttribute("tabId", "ketqua");
        model.addAttribute("currentUser", session.getAttribute("currentUser"));
        return "VIEW/ADMIN/ket-qua";
    }
}
