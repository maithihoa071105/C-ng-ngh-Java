package com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name="HoSo")
public class HoSo {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="ho_so_id")
    private Integer hoSoId;

    @Column(name="sinh_vien_id")
    private Integer sinhVienId;

    @Column(name="phuong_thuc_id")
    private Integer phuongThucId;

    @Column(name="to_hop")
    private String toHop;

    @Column(name="ngay_nop")
    private LocalDateTime ngayNop;

    @Column(name="trang_thai")
    private String trangThai;

    @Column(name="ghi_chu")
    private String ghiChu;

    public HoSo(){}

    public Integer getHoSoId(){return hoSoId;}
    public void setHoSoId(Integer v){this.hoSoId=v;}

    public Integer getSinhVienId(){return sinhVienId;}
    public void setSinhVienId(Integer v){this.sinhVienId=v;}

    public Integer getPhuongThucId(){return phuongThucId;}
    public void setPhuongThucId(Integer v){this.phuongThucId=v;}

    public String getToHop(){return toHop;}
    public void setToHop(String v){this.toHop=v;}

    public LocalDateTime getNgayNop(){return ngayNop;}
    public void setNgayNop(LocalDateTime v){this.ngayNop=v;}

    public String getTrangThai(){return trangThai;}
    public void setTrangThai(String v){this.trangThai=v;}

    public String getGhiChu(){return ghiChu;}
    public void setGhiChu(String v){this.ghiChu=v;}

}
