package com.cnj02.xettuyen.PRESENTATION_LAYER_UI.ADMIN_CONTROLLER;

import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller @RequestMapping("/admin")
public class ChiTieuAdminController {
    private final JdbcTemplate jdbc; public ChiTieuAdminController(JdbcTemplate jdbc){this.jdbc=jdbc;}
    private boolean ok(HttpSession s){User u=(User)s.getAttribute("currentUser");return u!=null&&Integer.valueOf(1).equals(u.getRoleId());}
    private void common(Model m){
        m.addAttribute("majors",jdbc.queryForList("SELECT nganh_id,ma_nganh,ten_nganh,khoa FROM Nganh WHERE trang_thai='DANG_TUYEN_SINH' ORDER BY ten_nganh"));
        m.addAttribute("methods",jdbc.queryForList("SELECT phuong_thuc_id,ma_phuong_thuc,ten_phuong_thuc FROM PhuongThucXetTuyen WHERE trang_thai='ACTIVE' ORDER BY ten_phuong_thuc"));
    }
    @GetMapping("/chitieu") public String list(HttpSession s,Model m){if(!ok(s))return "redirect:/403";var list=items();m.addAttribute("items",list);m.addAttribute("totalQuota", currentQuota());common(m);m.addAttribute("form",new Form());return "VIEW/ADMIN/chitieu";}
    @GetMapping("/chitieu/edit/{id}") public String edit(HttpSession s,@PathVariable Integer id,Model m){if(!ok(s))return "redirect:/403";var list=items();m.addAttribute("items",list);m.addAttribute("totalQuota", currentQuota());common(m);var r=jdbc.queryForList("SELECT chi_tieu_id,nganh_id,phuong_thuc_id,nam_hoc,so_luong,diem_san FROM ChiTieu WHERE chi_tieu_id=?",id);if(r.isEmpty())return "redirect:/admin/chitieu?error=notfound";var x=r.get(0);Form f=new Form();f.id=((Number)x.get("chi_tieu_id")).intValue();f.nganhId=((Number)x.get("nganh_id")).intValue();f.methodId=((Number)x.get("phuong_thuc_id")).intValue();f.year=((Number)x.get("nam_hoc")).intValue();f.quota=((Number)x.get("so_luong")).intValue();f.floor=x.get("diem_san")==null?0:((Number)x.get("diem_san")).doubleValue();m.addAttribute("form",f);return "VIEW/ADMIN/chitieu";}
    private long currentQuota(){Number n=jdbc.queryForObject("SELECT COALESCE(SUM(ct.so_luong),0) FROM ChiTieu ct JOIN PhuongThucXetTuyen p ON p.phuong_thuc_id=ct.phuong_thuc_id AND p.trang_thai='ACTIVE' WHERE ct.nam_hoc=2026",Number.class);return n==null?0:n.longValue();}
    private java.util.List<java.util.Map<String,Object>> items(){return jdbc.queryForList("SELECT ct.chi_tieu_id chiTieuId,n.ma_nganh,n.ten_nganh,p.ma_phuong_thuc,p.ten_phuong_thuc,ct.nam_hoc namHoc,ct.so_luong soLuong,ct.diem_san diemSan FROM ChiTieu ct JOIN Nganh n ON n.nganh_id=ct.nganh_id JOIN PhuongThucXetTuyen p ON p.phuong_thuc_id=ct.phuong_thuc_id ORDER BY ct.nam_hoc DESC,n.ten_nganh,p.ten_phuong_thuc");}
    @PostMapping("/chitieu/save") public String save(HttpSession s,@RequestParam(required=false) Integer chiTieuId,@RequestParam Integer nganhId,@RequestParam Integer phuongThucId,@RequestParam Integer namHoc,@RequestParam Integer soLuong,@RequestParam(required=false,defaultValue="0") Double diemSan){if(!ok(s))return "redirect:/403";if(chiTieuId==null)jdbc.update("INSERT INTO ChiTieu(nganh_id,phuong_thuc_id,nam_hoc,so_luong,diem_san) VALUES(?,?,?,?,?)",nganhId,phuongThucId,namHoc,soLuong,diemSan);else jdbc.update("UPDATE ChiTieu SET nganh_id=?,phuong_thuc_id=?,nam_hoc=?,so_luong=?,diem_san=? WHERE chi_tieu_id=?",nganhId,phuongThucId,namHoc,soLuong,diemSan,chiTieuId);return "redirect:/admin/chitieu?success=saved";}
    @PostMapping("/chitieu/delete/{id}") public String del(HttpSession s,@PathVariable Integer id){if(!ok(s))return "redirect:/403";try{jdbc.update("DELETE FROM ChiTieu WHERE chi_tieu_id=?",id);return "redirect:/admin/chitieu?success=deleted";}catch(Exception e){return "redirect:/admin/chitieu?error=used";}}
    public static class Form {Integer id,nganhId,methodId,year=2026,quota;Double floor=0.0;public Integer getId(){return id;}public Integer getNganhId(){return nganhId;}public Integer getMethodId(){return methodId;}public Integer getYear(){return year;}public Integer getQuota(){return quota;}public Double getFloor(){return floor;}}
}
