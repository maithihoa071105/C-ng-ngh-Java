package com.cnj02.xettuyen.PRESENTATION_LAYER_UI.ADMIN_CONTROLLER;
import com.cnj02.xettuyen.BUSINESS_LOGIC_LAYER_BUS.SERVICE.AdminDataService;
import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
@Controller @RequestMapping("/admin/thong-ke") public class ThongKeAdminController {
 private final AdminDataService s; public ThongKeAdminController(AdminDataService s){this.s=s;}
 @GetMapping public String list(HttpSession ss,Model m){User u=(User)ss.getAttribute("currentUser");if(u==null||(u.getRoleId()!=1&&u.getRoleId()!=2))return "redirect:/403";m.addAttribute("isStaff", Integer.valueOf(2).equals(u.getRoleId()));m.addAttribute("tabId", "thongke");m.addAttribute("currentUser", u);m.addAllAttributes(s.dashboard());return "VIEW/ADMIN/thong-ke";}
}
