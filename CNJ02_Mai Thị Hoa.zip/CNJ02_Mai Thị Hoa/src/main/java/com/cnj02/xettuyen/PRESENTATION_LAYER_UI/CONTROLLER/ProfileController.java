package com.cnj02.xettuyen.PRESENTATION_LAYER_UI.CONTROLLER;

import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.util.Map;

@Controller
public class ProfileController {
    private final JdbcTemplate jdbc;

    public ProfileController(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @GetMapping("/profile")
    public String profile(HttpSession session, Model model) {
        User user = currentUser(session);
        if (user == null) return "redirect:/login";
        if (!Integer.valueOf(3).equals(user.getRoleId())) return Integer.valueOf(1).equals(user.getRoleId()) ? "redirect:/admin/dashboard" : "redirect:/canbo/dashboard";

        model.addAttribute("user", user);
        model.addAttribute("currentUser", user);
        model.addAttribute("tabId", "profile");
        loadProfile(model, user.getUserId());
        return "VIEW/USER/profile";
    }

    @PostMapping("/profile/update")
    public String updateProfile(
            @RequestParam String hoTen,
            @RequestParam String cccd,
            @RequestParam(required = false) String ngaySinh,
            @RequestParam(required = false) String gioiTinh,
            @RequestParam(required = false) String diaChi,
            @RequestParam(required = false) String truongThpt,
            @RequestParam String email,
            @RequestParam(required = false) String phone,
            HttpSession session,
            RedirectAttributes ra) {

        User user = currentUser(session);
        if (user == null) return "redirect:/login";
        if (!Integer.valueOf(3).equals(user.getRoleId())) return "redirect:/403";
        int userId = user.getUserId();

        try {
            Integer duplicateEmail = jdbc.queryForObject(
                    "SELECT COUNT(*) FROM `User` WHERE email=? AND user_id<>?", Integer.class, email.trim(), userId);
            Integer duplicateCccd = jdbc.queryForObject(
                    "SELECT COUNT(*) FROM SinhVien WHERE cccd=? AND user_id<>?", Integer.class, cccd.trim(), userId);
            if (duplicateEmail != null && duplicateEmail > 0) {
                ra.addFlashAttribute("error", "Email đã được sử dụng bởi tài khoản khác.");
                return "redirect:/profile";
            }
            if (duplicateCccd != null && duplicateCccd > 0) {
                ra.addFlashAttribute("error", "CCCD đã tồn tại trong hệ thống.");
                return "redirect:/profile";
            }

            jdbc.update("UPDATE `User` SET email=?, phone=? WHERE user_id=?",
                    email.trim(), blankToNull(phone), userId);

            Integer exists = jdbc.queryForObject(
                    "SELECT COUNT(*) FROM SinhVien WHERE user_id=?", Integer.class, userId);
            if (exists != null && exists > 0) {
                jdbc.update("UPDATE SinhVien SET ho_ten=?, cccd=?, ngay_sinh=?, gioi_tinh=?, dia_chi=?, truong_thpt=? WHERE user_id=?",
                        hoTen.trim(), cccd.trim(), parseDate(ngaySinh), blankToNull(gioiTinh),
                        blankToNull(diaChi), blankToNull(truongThpt), userId);
            } else {
                jdbc.update("INSERT INTO SinhVien(user_id,ho_ten,cccd,ngay_sinh,gioi_tinh,dia_chi,truong_thpt) VALUES(?,?,?,?,?,?,?)",
                        userId, hoTen.trim(), cccd.trim(), parseDate(ngaySinh), blankToNull(gioiTinh),
                        blankToNull(diaChi), blankToNull(truongThpt));
            }

            // Cập nhật session để header đổi tên/email ngay sau khi lưu.
            User refreshed = new User();
            refreshed.setUserId(userId);
            refreshed.setUsername(user.getUsername());
            refreshed.setPassword(user.getPassword());
            refreshed.setEmail(email.trim());
            refreshed.setPhone(blankToNull(phone));
            refreshed.setRoleId(user.getRoleId());
            refreshed.setStatus(user.getStatus());
            refreshed.setCreatedAt(user.getCreatedAt());
            session.setAttribute("currentUser", refreshed);

            ra.addFlashAttribute("success", "Đã cập nhật thông tin vào MySQL thành công.");
        } catch (Exception e) {
            ra.addFlashAttribute("error", "Không thể cập nhật dữ liệu: " + e.getMessage());
        }
        return "redirect:/profile";
    }

    private void loadProfile(Model model, int userId) {
        Map<String, Object> p = jdbc.queryForMap(
                "SELECT u.user_id,u.username,u.email,u.phone,u.status," +
                "sv.sinh_vien_id,sv.ho_ten,sv.cccd,sv.ngay_sinh,sv.gioi_tinh,sv.dia_chi,sv.truong_thpt,sv.anh_dai_dien,sv.anh_dai_dien_mime " +
                "FROM `User` u LEFT JOIN SinhVien sv ON sv.user_id=u.user_id WHERE u.user_id=?", userId);
        model.addAttribute("profile", p);
    }

    private User currentUser(HttpSession session) {
        return (User) session.getAttribute("currentUser");
    }

    private String blankToNull(String value) {
        return value == null || value.trim().isEmpty() ? null : value.trim();
    }

    private LocalDate parseDate(String value) {
        return value == null || value.trim().isEmpty() ? null : LocalDate.parse(value);
    }
}
