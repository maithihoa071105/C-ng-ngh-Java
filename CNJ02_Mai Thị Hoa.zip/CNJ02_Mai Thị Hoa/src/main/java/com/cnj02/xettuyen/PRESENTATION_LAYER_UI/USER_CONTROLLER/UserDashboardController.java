package com.cnj02.xettuyen.PRESENTATION_LAYER_UI.USER_CONTROLLER;

import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/sinh-vien")
public class UserDashboardController {
    private final JdbcTemplate jdbc;
    public UserDashboardController(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    @GetMapping({"/dashboard", ""})
    public String dash(HttpSession session, Model model) {
        User u = (User) session.getAttribute("currentUser");
        if (u == null) return "redirect:/login";
        if (!Integer.valueOf(3).equals(u.getRoleId())) return "redirect:/admin/dashboard";
        Integer hsCount = jdbc.queryForObject("SELECT COUNT(*) FROM HoSo hs JOIN SinhVien sv ON sv.sinh_vien_id=hs.sinh_vien_id WHERE sv.user_id=?", Integer.class, u.getUserId());
        Integer pending = jdbc.queryForObject("SELECT COUNT(*) FROM HoSo hs JOIN SinhVien sv ON sv.sinh_vien_id=hs.sinh_vien_id WHERE sv.user_id=? AND hs.trang_thai IN ('CHO_DUYET','TIEP_NHAN','DANG_XU_LY')", Integer.class, u.getUserId());
        // "Đã xét tuyển" phải lấy từ trạng thái hồ sơ đã được cán bộ xử lý hoàn tất,
        // không đếm bảng KetQua vì KetQua có thể tồn tại với trạng thái CHUA_XET.
        Integer results = jdbc.queryForObject(
                "SELECT COUNT(*) FROM HoSo hs JOIN SinhVien sv ON sv.sinh_vien_id=hs.sinh_vien_id " +
                "WHERE sv.user_id=? AND hs.trang_thai IN ('DA_DUYET','KHONG_DUYET')",
                Integer.class, u.getUserId());
        List<Map<String,Object>> latest = jdbc.queryForList("SELECT hs.ho_so_id,hs.ngay_nop,COALESCE(hs.trang_thai,'CHO_DUYET') trang_thai,COALESCE(pt.ten_phuong_thuc,'Phương thức xét tuyển') ten_phuong_thuc FROM HoSo hs JOIN SinhVien sv ON sv.sinh_vien_id=hs.sinh_vien_id LEFT JOIN PhuongThucXetTuyen pt ON pt.phuong_thuc_id=hs.phuong_thuc_id WHERE sv.user_id=? ORDER BY hs.ho_so_id DESC LIMIT 5", u.getUserId());
        model.addAttribute("user",u); model.addAttribute("currentUser",u); model.addAttribute("tabId","home");
        model.addAttribute("hosoCount",hsCount==null?0:hsCount); model.addAttribute("pendingCount",pending==null?0:pending); model.addAttribute("resultCount",results==null?0:results); model.addAttribute("latest",latest);
        return "VIEW/USER/dashboard";
    }
}
