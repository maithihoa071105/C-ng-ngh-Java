package com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name="HoSoLog")
public class HoSoLog {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="log_id")
    private Integer logId;

    @Column(name="ho_so_id")
    private Integer hoSoId;

    @Column(name="user_id")
    private Integer userId;

    @Column(name="hanh_dong")
    private String hanhDong;

    @Column(name="thoi_gian")
    private LocalDateTime thoiGian;

    @Column(name="chi_tiet")
    private String chiTiet;

    public HoSoLog(){}

    public Integer getLogId(){return logId;}
    public void setLogId(Integer v){this.logId=v;}

    public Integer getHoSoId(){return hoSoId;}
    public void setHoSoId(Integer v){this.hoSoId=v;}

    public Integer getUserId(){return userId;}
    public void setUserId(Integer v){this.userId=v;}

    public String getHanhDong(){return hanhDong;}
    public void setHanhDong(String v){this.hanhDong=v;}

    public LocalDateTime getThoiGian(){return thoiGian;}
    public void setThoiGian(LocalDateTime v){this.thoiGian=v;}

    public String getChiTiet(){return chiTiet;}
    public void setChiTiet(String v){this.chiTiet=v;}

}
