package com.cnj02.xettuyen.PRESENTATION_LAYER_UI.CONTROLLER;

import com.cnj02.xettuyen.BUSINESS_LOGIC_LAYER_BUS.SERVICE.AuthService;
import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.User;

import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AuthController {

    @Autowired
    private AuthService authService;

    @Autowired
    private JdbcTemplate jdbc;


    // =====================================================
    // HIỂN THỊ TRANG ĐĂNG NHẬP
    // =====================================================

    @GetMapping("/login")
    public String showLoginForm() {

        return "VIEW/AUTH/login";
    }


    // =====================================================
    // XỬ LÝ ĐĂNG NHẬP
    // =====================================================

    @PostMapping("/login")
    public String handleLogin(
            @RequestParam("username") String username,
            @RequestParam("password") String password,
            @RequestParam(value = "role", required = false)
            Integer selectedRole,

            HttpSession session,
            Model model) {

        System.out.println("\n================================");
        System.out.println("        REQUEST LOGIN");
        System.out.println("================================");

        System.out.println(
                "Username = " + username
        );

        System.out.println(
                "Selected Role = " + selectedRole
        );


        // =================================================
        // GỌI BUSINESS LOGIC
        // =================================================

        User user = authService.login(
                username,
                password
        );


        // =================================================
        // ĐĂNG NHẬP THẤT BẠI
        // =================================================

        if (user == null) {

            model.addAttribute(
                    "errorLogin",
                    "Tên đăng nhập hoặc mật khẩu không chính xác!"
            );

            return "VIEW/AUTH/login";
        }


        // =================================================
        // KIỂM TRA ROLE
        // =================================================

        // Vai trò được quyết định bởi role_id trong MySQL; dropdown chỉ là lựa chọn giao diện.
        // Sau khi xác thực, hệ thống luôn chuyển tới đúng khu vực theo role thực tế.

        // =================================================
        // TẠO SESSION
        // =================================================

        session.setAttribute(
                "currentUser",
                user
        );

        session.setAttribute(
                "username",
                user.getUsername()
        );

        session.setAttribute(
                "roleId",
                user.getRoleId()
        );


        System.out.println(
                "LOGIN SUCCESS: "
                + user.getUsername()
        );

        // Ghi nhật ký hoạt động đăng nhập vào HoSoLog; ho_so_id để NULL vì đây là hoạt động hệ thống.
        try {
            jdbc.update("INSERT INTO HoSoLog(ho_so_id,user_id,hanh_dong,thoi_gian,chi_tiet) VALUES(NULL,?,?,?,?)",
                    user.getUserId(), "ĐĂNG NHẬP", java.sql.Timestamp.valueOf(java.time.LocalDateTime.now()),
                    "Đăng nhập thành công vào hệ thống CNJ02.");
        } catch (Exception ignored) { }



        // =================================================
        // PHÂN LUỒNG THEO ROLE
        // =================================================

        Integer roleId = user.getRoleId();

        if (roleId == null) {

            return "redirect:/trang-chu";
        }


        switch (roleId) {

            // ================================
            // ADMIN
            // ================================

            case 1:

                System.out.println(
                        "Redirect ADMIN"
                );

                return "redirect:/admin/dashboard";


            // ================================
            // CÁN BỘ
            // ================================

            case 2:

                System.out.println(
                        "Redirect STAFF"
                );

                return "redirect:/admin/dashboard";


            // ================================
            // SINH VIÊN
            // ================================

            case 3:

                System.out.println(
                        "Redirect SINH VIEN"
                );

                return "redirect:/trang-chu";


            // ================================
            // ROLE KHÔNG XÁC ĐỊNH
            // ================================

            default:

                return "redirect:/trang-chu";
        }
    }


    // =====================================================
    // ĐĂNG XUẤT
    // =====================================================

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        User user = (User) session.getAttribute("currentUser");
        if (user != null) {
            try {
                jdbc.update("INSERT INTO HoSoLog(ho_so_id,user_id,hanh_dong,thoi_gian,chi_tiet) VALUES(NULL,?,?,?,?)",
                        user.getUserId(), "ĐĂNG XUẤT", java.sql.Timestamp.valueOf(java.time.LocalDateTime.now()), "Tài khoản đăng xuất khỏi hệ thống CNJ02.");
            } catch (Exception ignored) { }
        }
        session.invalidate();
        return "redirect:/login";
    }
}