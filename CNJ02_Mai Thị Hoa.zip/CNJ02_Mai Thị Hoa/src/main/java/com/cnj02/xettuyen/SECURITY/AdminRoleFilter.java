package com.cnj02.xettuyen.SECURITY;

import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.User;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

/**
 * Phân quyền nghiệp vụ đúng vai trò:
 * ADMIN (1) bảo trì/cấu hình hệ thống; STAFF (2) xử lý hồ sơ tuyển sinh.
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE + 20)
public class AdminRoleFilter extends OncePerRequestFilter {
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        String uri = request.getRequestURI();
        if (!uri.startsWith(request.getContextPath() + "/admin")) {
            chain.doFilter(request, response);
            return;
        }

        HttpSession session = request.getSession(false);
        User user = session == null ? null : (User) session.getAttribute("currentUser");
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        int role = user.getRoleId() == null ? 0 : user.getRoleId();
        String path = uri.substring((request.getContextPath() + "/admin").length());

        boolean adminMaintenance = path.startsWith("/dashboard") || path.startsWith("/users") ||
                path.startsWith("/nganh") || path.startsWith("/chitieu") ||
                path.startsWith("/phuong-thuc") || path.startsWith("/sinh-vien") ||
                path.startsWith("/thong-bao") || path.startsWith("/nhat-ky");
        boolean staffOperations = path.startsWith("/hoso") || path.startsWith("/duyet-ho-so") ||
                path.startsWith("/nguyen-vong") || path.startsWith("/diem") ||
                path.startsWith("/minh-chung") || path.startsWith("/ket-qua");

        if (path.startsWith("/dashboard") || path.startsWith("/thong-ke")) {
            if (role != 1 && role != 2) { response.sendRedirect(request.getContextPath() + "/403"); return; }
        } else if (adminMaintenance && role != 1) {
            response.sendRedirect(request.getContextPath() + "/403");
            return;
        }
        if (staffOperations && role != 2) {
            response.sendRedirect(request.getContextPath() + "/403");
            return;
        }
        boolean sharedReadOnly = path.startsWith("/thong-ke");
        if (!adminMaintenance && !staffOperations && !sharedReadOnly) {
            response.sendRedirect(request.getContextPath() + "/403");
            return;
        }
        chain.doFilter(request, response);
    }
}
