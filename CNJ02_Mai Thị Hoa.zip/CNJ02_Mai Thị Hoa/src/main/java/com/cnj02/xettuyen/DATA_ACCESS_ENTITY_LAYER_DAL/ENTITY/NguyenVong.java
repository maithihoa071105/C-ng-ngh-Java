package com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name="NguyenVong")
public class NguyenVong {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="nguyen_vong_id")
    private Integer nguyenVongId;

    @Column(name="ho_so_id")
    private Integer hoSoId;

    @Column(name="nganh_id")
    private Integer nganhId;

    @Column(name="thu_tu_nguyen_vong")
    private Integer thuTuNguyenVong;

    @Column(name="trang_thai")
    private String trangThai;

    public NguyenVong(){}

    public Integer getNguyenVongId(){return nguyenVongId;}
    public void setNguyenVongId(Integer v){this.nguyenVongId=v;}

    public Integer getHoSoId(){return hoSoId;}
    public void setHoSoId(Integer v){this.hoSoId=v;}

    public Integer getNganhId(){return nganhId;}
    public void setNganhId(Integer v){this.nganhId=v;}

    public Integer getThuTuNguyenVong(){return thuTuNguyenVong;}
    public void setThuTuNguyenVong(Integer v){this.thuTuNguyenVong=v;}

    public String getTrangThai(){return trangThai;}
    public void setTrangThai(String v){this.trangThai=v;}

}
