package com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY;

import jakarta.persistence.*;

@Entity
@Table(name="Nganh")
public class Nganh {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="nganh_id")
    private Integer nganhId;

    @Column(name="ma_nganh")
    private String maNganh;

    @Column(name="ten_nganh")
    private String tenNganh;

    @Column(name="mo_ta")
    private String moTa;

    @Column(name="khoa")
    private String khoa;

    @Column(name="trang_thai")
    private String trangThai = "DANG_TUYEN_SINH";

    public Nganh(){}

    public Integer getNganhId(){return nganhId;}
    public void setNganhId(Integer v){this.nganhId=v;}
    public String getMaNganh(){return maNganh;}
    public void setMaNganh(String v){this.maNganh=v;}
    public String getTenNganh(){return tenNganh;}
    public void setTenNganh(String v){this.tenNganh=v;}
    public String getMoTa(){return moTa;}
    public void setMoTa(String v){this.moTa=v;}
    public String getKhoa(){return khoa;}
    public void setKhoa(String v){this.khoa=v;}
    public String getTrangThai(){return trangThai;}
    public void setTrangThai(String v){this.trangThai=v;}

    @PrePersist
    public void prePersist(){
        if(khoa==null||khoa.isBlank()) khoa="Chưa phân khoa";
        if(trangThai==null||trangThai.isBlank()) trangThai="DANG_TUYEN_SINH";
    }
}
