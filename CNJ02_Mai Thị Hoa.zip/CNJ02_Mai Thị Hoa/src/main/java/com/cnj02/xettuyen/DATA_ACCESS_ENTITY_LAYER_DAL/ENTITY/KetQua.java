package com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name="KetQua")
public class KetQua {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="ket_qua_id")
    private Integer ketQuaId;

    @Column(name="ho_so_id")
    private Integer hoSoId;

    @Column(name="nganh_id")
    private Integer nganhId;

    @Column(name="diem_xet_tuyen")
    private Double diemXetTuyen;

    @Column(name="trang_thai_ket_qua")
    private String trangThaiKetQua;

    @Column(name="ngay_cap_nhat")
    private LocalDateTime ngayCapNhat;

    public KetQua(){}

    public Integer getKetQuaId(){return ketQuaId;}
    public void setKetQuaId(Integer v){this.ketQuaId=v;}

    public Integer getHoSoId(){return hoSoId;}
    public void setHoSoId(Integer v){this.hoSoId=v;}

    public Integer getNganhId(){return nganhId;}
    public void setNganhId(Integer v){this.nganhId=v;}

    public Double getDiemXetTuyen(){return diemXetTuyen;}
    public void setDiemXetTuyen(Double v){this.diemXetTuyen=v;}

    public String getTrangThaiKetQua(){return trangThaiKetQua;}
    public void setTrangThaiKetQua(String v){this.trangThaiKetQua=v;}

    public LocalDateTime getNgayCapNhat(){return ngayCapNhat;}
    public void setNgayCapNhat(LocalDateTime v){this.ngayCapNhat=v;}

}
