package com.cnj02.xettuyen.PRESENTATION_LAYER_UI.CONTROLLER;

import com.cnj02.xettuyen.BUSINESS_LOGIC_LAYER_BUS.SERVICE.AuthService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class RegisterController {


    @Autowired
    private AuthService authService;


    // =====================================================
    // HIỂN THỊ TRANG ĐĂNG KÝ
    // =====================================================

    @GetMapping("/register")
    public String showRegisterForm() {

        return "VIEW/AUTH/register";
    }


    // =====================================================
    // XỬ LÝ ĐĂNG KÝ
    // =====================================================

    @PostMapping("/register")
    public String handleRegister(

            @RequestParam("username")
            String username,

            @RequestParam("password")
            String password,

            @RequestParam("confirmPassword")
            String confirmPassword,

            @RequestParam("email")
            String email,

            @RequestParam("phone")
            String phone,

            @RequestParam("hoTen")
            String hoTen,

            @RequestParam("cccd")
            String cccd,

            @RequestParam("gioiTinh")
            String gioiTinh,

            @RequestParam(value = "ngaySinh",
                    required = false)
            String ngaySinh,

            Model model) {


        try {

            // =================================================
            // KIỂM TRA MẬT KHẨU
            // =================================================

            if (!password.equals(confirmPassword)) {

                model.addAttribute(
                        "errorRegister",
                        "Mật khẩu nhập lại không khớp!"
                );

                return "VIEW/AUTH/register";
            }


            // =================================================
            // GỌI SERVICE
            // =================================================

            authService.registerUserAndSinhVien(

                    username,
                    password,
                    email,
                    phone,
                    hoTen,
                    cccd,
                    gioiTinh,
                    ngaySinh
            );


            // =================================================
            // ĐĂNG KÝ THÀNH CÔNG
            // =================================================

            return "redirect:/login?registered=true";


        } catch (DuplicateKeyException e) {
            model.addAttribute("errorRegister", "Tên đăng nhập, email hoặc CCCD đã tồn tại trong MySQL.");
            return "VIEW/AUTH/register";
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("errorRegister", e.getMessage() == null ? "Đăng ký không thành công." : e.getMessage());
            return "VIEW/AUTH/register";
        }
    }
}