package com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.REPOSITORY;
import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.MinhChung; import org.springframework.data.jpa.repository.JpaRepository;
public interface MinhChungRepository extends JpaRepository<MinhChung,Integer>{  }
