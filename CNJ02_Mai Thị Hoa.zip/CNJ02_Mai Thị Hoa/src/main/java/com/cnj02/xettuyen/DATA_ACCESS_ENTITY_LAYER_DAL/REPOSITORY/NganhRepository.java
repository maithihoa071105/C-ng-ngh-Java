package com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.REPOSITORY;
import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.Nganh; import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface NganhRepository extends JpaRepository<Nganh,Integer>{
    boolean existsByMaNganh(String maNganh);
    List<Nganh> findByMaNganhContainingIgnoreCaseOrTenNganhContainingIgnoreCase(String maNganh, String tenNganh);
}
