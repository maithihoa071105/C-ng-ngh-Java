package com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name="NguoiNhanThongBao")
public class NguoiNhanThongBao {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="id")
    private Integer id;

    @Column(name="thong_bao_id")
    private Integer thongBaoId;

    @Column(name="user_id")
    private Integer userId;

    @Column(name="da_doc")
    private Boolean daDoc;

    @Column(name="ngay_doc")
    private LocalDateTime ngayDoc;

    public NguoiNhanThongBao(){}

    public Integer getId(){return id;}
    public void setId(Integer v){this.id=v;}

    public Integer getThongBaoId(){return thongBaoId;}
    public void setThongBaoId(Integer v){this.thongBaoId=v;}

    public Integer getUserId(){return userId;}
    public void setUserId(Integer v){this.userId=v;}

    public Boolean getDaDoc(){return daDoc;}
    public void setDaDoc(Boolean v){this.daDoc=v;}

    public LocalDateTime getNgayDoc(){return ngayDoc;}
    public void setNgayDoc(LocalDateTime v){this.ngayDoc=v;}

}
