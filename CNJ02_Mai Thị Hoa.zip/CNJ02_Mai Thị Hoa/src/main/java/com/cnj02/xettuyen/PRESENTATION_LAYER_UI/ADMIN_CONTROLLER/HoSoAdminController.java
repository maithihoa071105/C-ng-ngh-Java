package com.cnj02.xettuyen.PRESENTATION_LAYER_UI.ADMIN_CONTROLLER;

import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Route tương thích cho mục Hồ sơ. Nghiệp vụ hồ sơ được xử lý tập trung tại DuyetHoSoController.
 */
@Controller
@RequestMapping("/admin")
public class HoSoAdminController {
    private boolean ok(HttpSession session) {
        User u = (User) session.getAttribute("currentUser");
        return u != null && Integer.valueOf(2).equals(u.getRoleId());
    }

    @GetMapping("/hoso")
    public String list(HttpSession session) {
        if (!ok(session)) return "redirect:/403";
        return "redirect:/admin/duyet-ho-so";
    }
}
