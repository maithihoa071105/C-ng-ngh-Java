package com.cnj02.xettuyen.PRESENTATION_LAYER_UI.CONTROLLER;

import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.net.URLEncoder;
import java.util.List;
import java.util.Map;

@Controller
public class FileViewController {
    private final JdbcTemplate jdbc;
    public FileViewController(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    @GetMapping("/minh-chung/file/{id}")
    public ResponseEntity<byte[]> viewEvidence(@PathVariable int id, HttpSession session) {
        User u = (User) session.getAttribute("currentUser");
        if (u == null) return ResponseEntity.status(302).header(HttpHeaders.LOCATION, "/login").build();
        List<Map<String,Object>> rows;
        if (Integer.valueOf(1).equals(u.getRoleId()) || Integer.valueOf(2).equals(u.getRoleId())) {
            rows = jdbc.queryForList("SELECT mc.ten_minh_chung,mc.file_path,mc.mime_type,mc.du_lieu FROM MinhChung mc WHERE mc.minh_chung_id=?", id);
        } else {
            rows = jdbc.queryForList("SELECT mc.ten_minh_chung,mc.file_path,mc.mime_type,mc.du_lieu FROM MinhChung mc JOIN HoSo hs ON hs.ho_so_id=mc.ho_so_id JOIN SinhVien sv ON sv.sinh_vien_id=hs.sinh_vien_id WHERE mc.minh_chung_id=? AND sv.user_id=?", id, u.getUserId());
        }
        if (rows.isEmpty()) return ResponseEntity.notFound().build();
        Map<String,Object> row = rows.get(0);
        byte[] data = row.get("du_lieu") instanceof byte[] b ? b : null;
        String mime = row.get("mime_type") == null ? null : String.valueOf(row.get("mime_type"));
        String name = row.get("ten_minh_chung") == null ? "file" : String.valueOf(row.get("ten_minh_chung"));
        try {
            if (data == null || data.length == 0) {
                String pv = row.get("file_path") == null ? "" : String.valueOf(row.get("file_path"));
                if (!pv.startsWith("/uploads/")) return ResponseEntity.notFound().build();
                Path root = Paths.get("uploads").toAbsolutePath().normalize();
                Path path = root.resolve(pv.substring("/uploads/".length())).normalize();
                if (!path.startsWith(root) || !Files.exists(path)) return ResponseEntity.notFound().build();
                data = Files.readAllBytes(path);
            }
            if (mime == null || mime.isBlank()) mime = URLConnection.guessContentTypeFromName(name);
            MediaType media;
            try { media = mime == null ? MediaType.APPLICATION_OCTET_STREAM : MediaType.parseMediaType(mime); }
            catch (Exception e) { media = MediaType.APPLICATION_OCTET_STREAM; }
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename*=UTF-8''" + URLEncoder.encode(name, StandardCharsets.UTF_8).replace("+", "%20"))
                    .contentType(media).body(data);
        } catch (Exception e) { return ResponseEntity.internalServerError().build(); }
    }

    @GetMapping("/sinh-vien/avatar")
    public ResponseEntity<byte[]> currentAvatar(HttpSession session) {
        User u = (User) session.getAttribute("currentUser");
        if (u == null) return ResponseEntity.status(302).header(HttpHeaders.LOCATION, "/login").build();
        return avatarByStudentId(findStudentId(u.getUserId()));
    }

    @GetMapping("/sinh-vien/avatar/{sinhVienId}")
    public ResponseEntity<byte[]> avatar(@PathVariable int sinhVienId, HttpSession session) {
        User u = (User) session.getAttribute("currentUser");
        if (u == null) return ResponseEntity.status(302).header(HttpHeaders.LOCATION, "/login").build();
        if (Integer.valueOf(3).equals(u.getRoleId())) {
            Integer owner = jdbc.queryForObject("SELECT user_id FROM SinhVien WHERE sinh_vien_id=?", Integer.class, sinhVienId);
            if (owner == null || !owner.equals(u.getUserId())) return ResponseEntity.status(403).build();
        }
        return avatarByStudentId(sinhVienId);
    }

    private Integer findStudentId(int userId) {
        List<Map<String,Object>> r = jdbc.queryForList("SELECT sinh_vien_id FROM SinhVien WHERE user_id=?", userId);
        return r.isEmpty() ? null : ((Number)r.get(0).get("sinh_vien_id")).intValue();
    }
    private ResponseEntity<byte[]> avatarByStudentId(Integer id) {
        if (id == null) return ResponseEntity.notFound().build();
        List<Map<String,Object>> rows = jdbc.queryForList("SELECT anh_dai_dien,anh_dai_dien_data,anh_dai_dien_mime FROM SinhVien WHERE sinh_vien_id=?", id);
        if (rows.isEmpty()) return ResponseEntity.notFound().build();
        Map<String,Object> row = rows.get(0);
        byte[] data = row.get("anh_dai_dien_data") instanceof byte[] b ? b : null;
        String mime = row.get("anh_dai_dien_mime") == null ? "image/jpeg" : String.valueOf(row.get("anh_dai_dien_mime"));
        try {
            if (data == null || data.length == 0) {
                String p = row.get("anh_dai_dien") == null ? "" : String.valueOf(row.get("anh_dai_dien"));
                if (!p.startsWith("/uploads/")) return ResponseEntity.notFound().build();
                Path root = Paths.get("uploads").toAbsolutePath().normalize();
                Path path = root.resolve(p.substring("/uploads/".length())).normalize();
                if (!path.startsWith(root) || !Files.exists(path)) return ResponseEntity.notFound().build();
                data = Files.readAllBytes(path);
            }
            return ResponseEntity.ok().contentType(MediaType.parseMediaType(mime)).body(data);
        } catch (Exception e) { return ResponseEntity.internalServerError().build(); }
    }
}
