package com.cnj02.xettuyen.PRESENTATION_LAYER_UI.CONTROLLER;

import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {
    private final JdbcTemplate jdbc;

    public HomeController(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @GetMapping({"/", "/trang-chu", "/index"})
    public String index(HttpSession session, Model model) {
        User user = (User) session.getAttribute("currentUser");
        if (user == null) return "redirect:/login";
        if (!Integer.valueOf(3).equals(user.getRoleId())) return "redirect:/admin/dashboard";

        model.addAttribute("user", user);
        model.addAttribute("tabId", "home");

        Integer userId = user.getUserId();
        long total = scalar("SELECT COUNT(*) FROM HoSo hs JOIN SinhVien sv ON hs.sinh_vien_id=sv.sinh_vien_id WHERE sv.user_id=?", userId);
        long processing = scalar("SELECT COUNT(*) FROM HoSo hs JOIN SinhVien sv ON hs.sinh_vien_id=sv.sinh_vien_id WHERE sv.user_id=? AND hs.trang_thai NOT IN ('DA_DUYET','KHONG_DUYET')", userId);
        long approved = scalar("SELECT COUNT(*) FROM HoSo hs JOIN SinhVien sv ON hs.sinh_vien_id=sv.sinh_vien_id WHERE sv.user_id=? AND hs.trang_thai='DA_DUYET'", userId);
        long failed = scalar("SELECT COUNT(*) FROM HoSo hs JOIN SinhVien sv ON hs.sinh_vien_id=sv.sinh_vien_id WHERE sv.user_id=? AND hs.trang_thai IN ('KHONG_DUYET','KHONG_DAT')", userId);
        long target = scalar("SELECT COALESCE(SUM(ct.so_luong),0) FROM ChiTieu ct JOIN PhuongThucXetTuyen pt ON pt.phuong_thuc_id=ct.phuong_thuc_id AND pt.trang_thai='ACTIVE' WHERE ct.nam_hoc=2026", null);
        long recruited = scalar("SELECT COUNT(*) FROM HoSo WHERE trang_thai='DA_DUYET'", null);

        model.addAttribute("hoSoTotal", total);
        model.addAttribute("hoSoProcessing", processing);
        model.addAttribute("hoSoApproved", approved);
        model.addAttribute("hoSoFailed", failed);
        model.addAttribute("totalChiTieu", target);
        model.addAttribute("daTuyen", recruited);
        model.addAttribute("conLai", Math.max(0, target - recruited));
        long unread = scalar("SELECT COUNT(*) FROM ThongBao tb LEFT JOIN NguoiNhanThongBao nr ON nr.thong_bao_id=tb.thong_bao_id AND nr.user_id=? WHERE COALESCE(nr.da_doc,0)=0", userId);
        model.addAttribute("unreadNotifications", unread);

        return "VIEW/HOME/index";
    }

    private long scalar(String sql, Object arg) {
        Number n = arg == null ? jdbc.queryForObject(sql, Number.class) : jdbc.queryForObject(sql, Number.class, arg);
        return n == null ? 0 : n.longValue();
    }
}
