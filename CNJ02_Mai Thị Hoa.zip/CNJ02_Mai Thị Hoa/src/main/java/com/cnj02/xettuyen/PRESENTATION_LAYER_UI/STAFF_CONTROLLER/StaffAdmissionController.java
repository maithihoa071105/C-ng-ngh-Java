package com.cnj02.xettuyen.PRESENTATION_LAYER_UI.STAFF_CONTROLLER;

import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Set;

/**
 * Các chức năng nhập học dành riêng cho cán bộ tuyển sinh.
 *
 * Luồng xử lý:
 * 1. Sinh viên điền đủ thông tin và gửi xác nhận nhập học.
 * 2. Hồ sơ chuyển sang trạng thái CHO_CAN_BO_XU_LY.
 * 3. Cán bộ kiểm tra, bổ sung địa điểm và ngày nhập học.
 * 4. Chỉ cán bộ mới được chuyển hồ sơ sang DA_NHAP_HOC.
 * 5. Danh sách sinh viên đã nhập học được lấy lại trực tiếp từ MySQL.
 */
@Controller
@RequestMapping("/canbo")
public class StaffAdmissionController {

    private static final int ROLE_CAN_BO = 2;
    private static final int NAM_TUYEN_SINH = 2026;

    private static final Set<String> TRANG_THAI_HOP_LE = Set.of(
            "CHUA_NHAP_HOC",
            "CHO_CAN_BO_XU_LY",
            "DA_NHAP_HOC",
            "TU_CHOI"
    );

    private final JdbcTemplate jdbc;

    public StaffAdmissionController(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    private boolean laCanBo(HttpSession session) {
        User user = (User) session.getAttribute("currentUser");
        return user != null && Integer.valueOf(ROLE_CAN_BO).equals(user.getRoleId());
    }

    private String tuChoi(HttpSession session) {
        User user = (User) session.getAttribute("currentUser");
        if (user == null) {
            return "redirect:/login";
        }
        return "redirect:/403";
    }

    @GetMapping({"", "/", "/dashboard"})
    public String dashboard(HttpSession session) {
        if (!laCanBo(session)) {
            return tuChoi(session);
        }
        return "redirect:/admin/dashboard";
    }

    @GetMapping("/hoso")
    public String hoSo(HttpSession session) {
        if (!laCanBo(session)) {
            return tuChoi(session);
        }
        return "redirect:/admin/duyet-ho-so";
    }

    @GetMapping("/hoso/{id}")
    public String chiTietHoSo(@PathVariable int id, HttpSession session) {
        if (!laCanBo(session)) {
            return tuChoi(session);
        }
        return "redirect:/admin/duyet-ho-so/" + id;
    }

    @GetMapping("/nguyen-vong")
    public String nguyenVong(HttpSession session) {
        if (!laCanBo(session)) {
            return tuChoi(session);
        }
        return "redirect:/admin/nguyen-vong";
    }

    @GetMapping("/ket-qua")
    public String ketQua(HttpSession session) {
        if (!laCanBo(session)) {
            return tuChoi(session);
        }
        return "redirect:/admin/ket-qua";
    }

    @GetMapping("/thong-ke")
    public String thongKe(HttpSession session) {
        if (!laCanBo(session)) {
            return tuChoi(session);
        }
        return "redirect:/admin/thong-ke";
    }

    /** Trang xử lý các hồ sơ đang chờ cán bộ xác nhận. */
    @GetMapping("/nhap-hoc")
    public String nhapHoc(HttpSession session, Model model) {
        if (!laCanBo(session)) {
            return tuChoi(session);
        }

        napDuLieuNhapHoc(model, session);
        return "VIEW/STAFF/nhap-hoc";
    }

    /**
     * Trang riêng để cán bộ mở danh sách sinh viên đã nhập học.
     * Tách thành trang riêng để danh sách dễ xem, không phải cuộn xuống cuối trang xử lý.
     */
    @GetMapping("/nhap-hoc/da-nhap-hoc")
    public String danhSachDaNhapHoc(HttpSession session, Model model) {
        if (!laCanBo(session)) {
            return tuChoi(session);
        }

        napDanhSachDaNhapHoc(model);
        model.addAttribute("tabId", "nhaphoc");
        model.addAttribute("currentUser", session.getAttribute("currentUser"));
        return "VIEW/STAFF/danh-sach-da-nhap-hoc";
    }

    /** Cán bộ cập nhật kết quả xử lý một hồ sơ nhập học. */
    @PostMapping("/nhap-hoc/{id}")
    public String capNhatNhapHoc(
            @PathVariable int id,
            @RequestParam(required = false) String coSo,
            @RequestParam(required = false) String diaDiem,
            @RequestParam(required = false) String diaChi,
            @RequestParam(required = false) String ngayNhapHoc,
            @RequestParam(required = false) String khungGio,
            @RequestParam(required = false) String trangThai,
            @RequestParam(required = false) String ghiChu,
            @RequestParam(required = false) String lyDoTuChoi,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        if (!laCanBo(session)) {
            return tuChoi(session);
        }

        User canBo = (User) session.getAttribute("currentUser");
        String status = trangThai == null || trangThai.isBlank()
                ? "CHUA_NHAP_HOC"
                : trangThai.trim();

        if (!TRANG_THAI_HOP_LE.contains(status)) {
            status = "CHUA_NHAP_HOC";
        }

        // Không cho ghi nhận ĐÃ NHẬP HỌC nếu sinh viên chưa gửi xác nhận.
        if ("DA_NHAP_HOC".equals(status)) {
            Integer daXacNhan = jdbc.queryForObject(
                    "SELECT COUNT(*) FROM NhapHoc " +
                    "WHERE nhap_hoc_id = ? AND ngay_xac_nhan IS NOT NULL",
                    Integer.class,
                    id
            );

            if (daXacNhan == null || daXacNhan == 0) {
                redirectAttributes.addFlashAttribute(
                        "error",
                        "Sinh viên chưa gửi xác nhận nhập học đầy đủ nên cán bộ chưa thể ghi nhận đã nhập học."
                );
                return "redirect:/canbo/nhap-hoc";
            }
        }

        String sql = "UPDATE NhapHoc SET " +
                "co_so = ?, " +
                "dia_diem = ?, " +
                "dia_chi = ?, " +
                "ngay_nhap_hoc = ?, " +
                "khung_gio = ?, " +
                "trang_thai = ?, " +
                "ghi_chu = ?, " +
                "ly_do_tu_choi = ?, " +
                "ngay_xu_ly = NOW(), " +
                "nguoi_xu_ly = ? " +
                "WHERE nhap_hoc_id = ?";

        jdbc.update(
                sql,
                giaTriRong(coSo),
                giaTriRong(diaDiem),
                giaTriRong(diaChi),
                giaTriRong(ngayNhapHoc),
                giaTriRong(khungGio),
                status,
                giaTriRong(ghiChu),
                giaTriRong(lyDoTuChoi),
                canBo.getUserId(),
                id
        );

        // Lưu nhật ký để sau này cán bộ/admin có thể kiểm tra lịch sử xử lý.
        try {
            Integer hoSoId = jdbc.queryForObject(
                    "SELECT ho_so_id FROM NhapHoc WHERE nhap_hoc_id = ?",
                    Integer.class,
                    id
            );

            jdbc.update(
                    "INSERT INTO HoSoLog(ho_so_id, user_id, hanh_dong, chi_tiet) " +
                    "VALUES (?, ?, ?, ?)",
                    hoSoId,
                    canBo.getUserId(),
                    "XỬ LÝ NHẬP HỌC",
                    "Cán bộ cập nhật trạng thái nhập học: " + status
            );
        } catch (Exception ignored) {
            // Nhật ký không được làm hỏng nghiệp vụ cập nhật nhập học.
        }

        redirectAttributes.addFlashAttribute(
                "success",
                "Đã xử lý hồ sơ nhập học và cập nhật số liệu tổng hợp."
        );

        if ("DA_NHAP_HOC".equals(status)) {
            return "redirect:/canbo/nhap-hoc/da-nhap-hoc";
        }

        return "redirect:/canbo/nhap-hoc";
    }

    private void napDuLieuNhapHoc(Model model, HttpSession session) {
        String sql = "SELECT " +
                "nh.nhap_hoc_id, nh.ket_qua_id, nh.ho_so_id, " +
                "sv.ho_ten, sv.cccd, sv.ngay_sinh, sv.gioi_tinh, " +
                "sv.dia_chi AS dia_chi_sv, sv.truong_thpt, " +
                "u.email, u.phone, n.ma_nganh, n.ten_nganh, n.khoa, " +
                "kq.trang_thai_ket_qua, nh.co_so, nh.dia_diem, nh.dia_chi, " +
                "nh.ngay_nhap_hoc, nh.khung_gio, nh.trang_thai, nh.ghi_chu, " +
                "nh.ngay_xac_nhan, nh.ngay_xu_ly, nh.ly_do_tu_choi " +
                "FROM NhapHoc nh " +
                "JOIN KetQua kq ON kq.ket_qua_id = nh.ket_qua_id " +
                "JOIN HoSo hs ON hs.ho_so_id = nh.ho_so_id " +
                "JOIN SinhVien sv ON sv.sinh_vien_id = hs.sinh_vien_id " +
                "JOIN `User` u ON u.user_id = sv.user_id " +
                "LEFT JOIN Nganh n ON n.nganh_id = kq.nganh_id " +
                "ORDER BY CASE nh.trang_thai " +
                "WHEN 'CHO_CAN_BO_XU_LY' THEN 0 " +
                "WHEN 'CHUA_NHAP_HOC' THEN 1 " +
                "WHEN 'DA_NHAP_HOC' THEN 2 " +
                "ELSE 3 END, nh.ho_so_id ASC";

        model.addAttribute("items", jdbc.queryForList(sql));
        napThongKeNhapHoc(model);
        model.addAttribute("tabId", "nhaphoc");
        model.addAttribute("currentUser", session.getAttribute("currentUser"));

        // Để trang xử lý cũng có thể hiển thị số lượng đã nhập học nhanh ở đầu trang.
        napDanhSachDaNhapHoc(model);
    }

    private void napDanhSachDaNhapHoc(Model model) {
        String sql = "SELECT " +
                "nh.nhap_hoc_id, nh.ho_so_id, " +
                "sv.ho_ten, sv.cccd, sv.ngay_sinh, sv.gioi_tinh, " +
                "u.email, u.phone, n.ma_nganh, n.ten_nganh, n.khoa, " +
                "nh.co_so, nh.dia_diem, nh.dia_chi, nh.ngay_nhap_hoc, " +
                "nh.khung_gio, nh.ngay_xac_nhan, nh.ngay_xu_ly, nh.nguoi_xu_ly " +
                "FROM NhapHoc nh " +
                "JOIN HoSo hs ON hs.ho_so_id = nh.ho_so_id " +
                "JOIN SinhVien sv ON sv.sinh_vien_id = hs.sinh_vien_id " +
                "JOIN `User` u ON u.user_id = sv.user_id " +
                "LEFT JOIN KetQua kq ON kq.ket_qua_id = nh.ket_qua_id " +
                "LEFT JOIN Nganh n ON n.nganh_id = kq.nganh_id " +
                "WHERE nh.trang_thai = 'DA_NHAP_HOC' " +
                "ORDER BY nh.ho_so_id ASC";

        model.addAttribute("enrolledItems", jdbc.queryForList(sql));
    }

    private void napThongKeNhapHoc(Model model) {
        Number choXuLy = jdbc.queryForObject(
                "SELECT COUNT(*) FROM NhapHoc nh " +
                "JOIN HoSo h ON h.ho_so_id = nh.ho_so_id " +
                "WHERE YEAR(h.ngay_nop) = ? AND nh.trang_thai = 'CHO_CAN_BO_XU_LY'",
                Number.class,
                NAM_TUYEN_SINH
        );

        Number daNhapHoc = jdbc.queryForObject(
                "SELECT COUNT(*) FROM NhapHoc nh " +
                "JOIN HoSo h ON h.ho_so_id = nh.ho_so_id " +
                "WHERE YEAR(h.ngay_nop) = ? AND nh.trang_thai = 'DA_NHAP_HOC'",
                Number.class,
                NAM_TUYEN_SINH
        );

        Number tuChoi = jdbc.queryForObject(
                "SELECT COUNT(*) FROM NhapHoc nh " +
                "JOIN HoSo h ON h.ho_so_id = nh.ho_so_id " +
                "WHERE YEAR(h.ngay_nop) = ? AND nh.trang_thai = 'TU_CHOI'",
                Number.class,
                NAM_TUYEN_SINH
        );

        Number tongTrungTuyen = jdbc.queryForObject(
                "SELECT COUNT(DISTINCT nh.ho_so_id) FROM NhapHoc nh " +
                "JOIN HoSo h ON h.ho_so_id = nh.ho_so_id " +
                "JOIN KetQua kq ON kq.ket_qua_id = nh.ket_qua_id " +
                "WHERE YEAR(h.ngay_nop) = ? " +
                "AND UPPER(TRIM(kq.trang_thai_ket_qua)) IN ('TRUNG_TUYEN', 'DA_TRUNG_TUYEN')",
                Number.class,
                NAM_TUYEN_SINH
        );

        long tong = tongTrungTuyen == null ? 0 : tongTrungTuyen.longValue();
        long daNhap = daNhapHoc == null ? 0 : daNhapHoc.longValue();
        double tyLe = tong == 0 ? 0 : Math.round(daNhap * 10000.0 / tong) / 100.0;

        model.addAttribute("tongTrungTuyen", tong);
        model.addAttribute("choXuLy", choXuLy == null ? 0 : choXuLy.longValue());
        model.addAttribute("daNhapHoc", daNhap);
        model.addAttribute("tuChoi", tuChoi == null ? 0 : tuChoi.longValue());
        model.addAttribute("tyLeNhapHoc", tyLe);
    }

    private String giaTriRong(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }
}
