package com.cnj02.xettuyen.UTILS;

import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Locale;
import java.util.UUID;

public final class FileUtil {
    private FileUtil() {}

    public static String save(MultipartFile file, String folder) throws IOException {
        if (file == null || file.isEmpty()) throw new IllegalArgumentException("File rỗng.");
        String original = file.getOriginalFilename() == null ? "file" : file.getOriginalFilename();
        original = Paths.get(original).getFileName().toString();
        String ext = "";
        int dot = original.lastIndexOf('.');
        if (dot >= 0) ext = original.substring(dot).toLowerCase(Locale.ROOT);
        String name = UUID.randomUUID() + ext;
        Path dir = Paths.get("uploads", folder).toAbsolutePath().normalize();
        Files.createDirectories(dir);
        Path target = dir.resolve(name).normalize();
        if (!target.startsWith(dir)) throw new IOException("Tên file không hợp lệ.");
        file.transferTo(target);
        return "/uploads/" + folder + "/" + name;
    }

    public static boolean allowedImage(MultipartFile file) {
        if (file == null || file.isEmpty()) return false;
        String type = file.getContentType() == null ? "" : file.getContentType().toLowerCase(Locale.ROOT);
        return type.equals("image/jpeg") || type.equals("image/png") || type.equals("image/webp");
    }

    public static boolean allowedEvidence(MultipartFile file) {
        if (file == null || file.isEmpty()) return false;
        String type = file.getContentType() == null ? "" : file.getContentType().toLowerCase(Locale.ROOT);
        return type.equals("application/pdf") || type.equals("image/jpeg") || type.equals("image/png") || type.equals("image/webp");
    }
}
