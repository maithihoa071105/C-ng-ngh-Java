package com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name="ChiTieu")
public class ChiTieu {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="chi_tieu_id")
    private Integer chiTieuId;

    @Column(name="nganh_id")
    private Integer nganhId;

    @Column(name="phuong_thuc_id")
    private Integer phuongThucId;

    @Column(name="nam_hoc")
    private Integer namHoc;

    @Column(name="so_luong")
    private Integer soLuong;

    @Column(name="diem_san")
    private Double diemSan;

    public ChiTieu(){}

    public Integer getChiTieuId(){return chiTieuId;}
    public void setChiTieuId(Integer v){this.chiTieuId=v;}

    public Integer getNganhId(){return nganhId;}
    public void setNganhId(Integer v){this.nganhId=v;}

    public Integer getPhuongThucId(){return phuongThucId;}
    public void setPhuongThucId(Integer v){this.phuongThucId=v;}

    public Integer getNamHoc(){return namHoc;}
    public void setNamHoc(Integer v){this.namHoc=v;}

    public Integer getSoLuong(){return soLuong;}
    public void setSoLuong(Integer v){this.soLuong=v;}

    public Double getDiemSan(){return diemSan;}
    public void setDiemSan(Double v){this.diemSan=v;}

}
