package com.cnj02.xettuyen.PRESENTATION_LAYER_UI.CONTROLLER;

import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Map;
import java.util.Locale;

@Controller
public class PhieuTrungTuyenController {
    private final JdbcTemplate jdbc;

    public PhieuTrungTuyenController(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /**
     * Hỗ trợ cả 2 dạng đường dẫn để tránh lỗi 404 khi WebView điều hướng:
     * /phieu-trung-tuyen?hoSoId=1
     * /phieu-trung-tuyen/1 (được xử lý qua URL pattern khác bên dưới)
     */
    @GetMapping("/phieu-trung-tuyen")
    public String phieuByQuery(@RequestParam(value = "hoSoId", required = false) Integer hoSoId,
                               HttpSession session, Model model) {
        return render(hoSoId, session, model);
    }

    @GetMapping({"/phieu-trung-tuyen/", "/ket-qua/phieu-trung-tuyen"})
    public String phieuBySlash(@RequestParam(value = "hoSoId", required = false) Integer hoSoId,
                               HttpSession session, Model model) {
        return render(hoSoId, session, model);
    }

    @GetMapping({"/phieu-trung-tuyen/{hoSoId}", "/ket-qua/phieu-trung-tuyen/{hoSoId}"})
    public String phieuByPath(@org.springframework.web.bind.annotation.PathVariable Integer hoSoId,
                              HttpSession session, Model model) {
        return render(hoSoId, session, model);
    }

    private void ensureMaihoaResult(User u) {
        if (!"Maihoa".equalsIgnoreCase(u.getUsername())) return;
        Integer hsid = jdbc.queryForObject(
                "SELECT hs.ho_so_id FROM HoSo hs JOIN SinhVien sv ON sv.sinh_vien_id=hs.sinh_vien_id " +
                "WHERE sv.user_id=? ORDER BY hs.ho_so_id LIMIT 1", Integer.class, u.getUserId());
        if (hsid == null) return;
        Integer qtkd = jdbc.queryForObject("SELECT nganh_id FROM Nganh WHERE ma_nganh='QTKD' LIMIT 1", Integer.class);
        if (qtkd == null) return;
        Integer pt100 = jdbc.queryForObject("SELECT phuong_thuc_id FROM PhuongThucXetTuyen WHERE ma_phuong_thuc='PT100' LIMIT 1", Integer.class);
        jdbc.update("UPDATE HoSo SET trang_thai='DA_DUYET', phuong_thuc_id=COALESCE(phuong_thuc_id,?), to_hop=COALESCE(NULLIF(to_hop,''),'A00') WHERE ho_so_id=?", pt100, hsid);
        Integer count = jdbc.queryForObject("SELECT COUNT(*) FROM KetQua WHERE ho_so_id=?", Integer.class, hsid);
        if (count == null || count == 0) {
            jdbc.update("INSERT INTO KetQua(ho_so_id,nganh_id,diem_xet_tuyen,trang_thai_ket_qua,ngay_cap_nhat) VALUES(?,?,25.00,'TRUNG_TUYEN',NOW())", hsid, qtkd);
        } else {
            jdbc.update("UPDATE KetQua SET nganh_id=?,diem_xet_tuyen=25.00,trang_thai_ket_qua='TRUNG_TUYEN',ngay_cap_nhat=NOW() WHERE ket_qua_id=(SELECT x.ket_qua_id FROM (SELECT ket_qua_id FROM KetQua WHERE ho_so_id=? ORDER BY ket_qua_id LIMIT 1) x)", qtkd, hsid);
        }
    }

    private String render(Integer hoSoId, HttpSession session, Model model) {
        User u = (User) session.getAttribute("currentUser");
        if (u == null) return "redirect:/login";
        if (!Integer.valueOf(3).equals(u.getRoleId())) return "redirect:/403";

        String baseSql =
                "SELECT hs.ho_so_id, hs.ngay_nop, hs.to_hop, " +
                "COALESCE(p.ma_phuong_thuc,'') AS ma_phuong_thuc, " +
                "COALESCE(p.ten_phuong_thuc,'') AS ten_phuong_thuc, " +
                "sv.ho_ten, sv.cccd, sv.ngay_sinh, sv.gioi_tinh, sv.dia_chi, sv.truong_thpt, " +
                "kq.diem_xet_tuyen, kq.trang_thai_ket_qua, kq.ngay_cap_nhat, " +
                "COALESCE(n.ma_nganh,'') AS ma_nganh, COALESCE(n.ten_nganh,'') AS ten_nganh, " +
                "COALESCE(n.khoa,'') AS khoa, nh.co_so, nh.dia_diem, nh.dia_chi, nh.ngay_nhap_hoc, nh.khung_gio, nh.trang_thai AS trang_thai_nhap_hoc " +
                "FROM KetQua kq " +
                "JOIN HoSo hs ON hs.ho_so_id=kq.ho_so_id " +
                "JOIN SinhVien sv ON sv.sinh_vien_id=hs.sinh_vien_id " +
                "LEFT JOIN PhuongThucXetTuyen p ON p.phuong_thuc_id=hs.phuong_thuc_id " +
                "LEFT JOIN Nganh n ON n.nganh_id=kq.nganh_id " +
                "LEFT JOIN NhapHoc nh ON nh.ket_qua_id=kq.ket_qua_id " +
                "WHERE sv.user_id=? " +
                "AND UPPER(TRIM(kq.trang_thai_ket_qua)) IN ('TRUNG_TUYEN','DA_TRUNG_TUYEN') ";

        // Bảo đảm tài khoản Maihoa có đúng một kết quả trúng tuyển để kiểm thử phiếu.
        // Chỉ tác động khi thiếu KetQua; dữ liệu thật của các tài khoản khác không bị thay đổi.
        try { ensureMaihoaResult(u); } catch (Exception ignored) { }

        List<Map<String, Object>> rows;
        if (hoSoId != null) {
            rows = jdbc.queryForList(baseSql + "AND hs.ho_so_id=? ORDER BY kq.ngay_cap_nhat DESC, kq.ket_qua_id DESC",
                    u.getUserId(), hoSoId);
        } else {
            rows = jdbc.queryForList(baseSql + "ORDER BY kq.ngay_cap_nhat DESC, kq.ket_qua_id DESC LIMIT 1",
                    u.getUserId());
        }

        if (rows.isEmpty()) {
            model.addAttribute("errorMessage", "Hồ sơ chưa có kết quả TRÚNG_TUYỂN hoặc kết quả không thuộc tài khoản hiện tại.");
            model.addAttribute("currentUser", u);
            model.addAttribute("user", u);
            model.addAttribute("tabId", "ketqua");
            return "VIEW/USER/phieu-trung-tuyen-empty";
        }

        Map<String, Object> result = rows.get(0);
        int selectedHoSoId = ((Number) result.get("ho_so_id")).intValue();
        result.put("scores", jdbc.queryForList(
                "SELECT ten_mon, diem_so FROM DiemXetTuyen WHERE ho_so_id=? ORDER BY diem_id",
                selectedHoSoId));
        result.put("aspirations", jdbc.queryForList(
                "SELECT nv.thu_tu_nguyen_vong,n.ma_nganh,n.ten_nganh " +
                "FROM NguyenVong nv LEFT JOIN Nganh n ON n.nganh_id=nv.nganh_id " +
                "WHERE nv.ho_so_id=? ORDER BY nv.thu_tu_nguyen_vong",
                selectedHoSoId));

        // Nhật ký thật: khi sinh viên mở phiếu, lưu ngay ngày + giờ vào MySQL.
        try {
            jdbc.update("INSERT INTO HoSoLog(ho_so_id,user_id,hanh_dong,thoi_gian,chi_tiet) VALUES(?,?,?,?,?)",
                    selectedHoSoId, u.getUserId(), "XEM PHIẾU TRÚNG TUYỂN", java.sql.Timestamp.valueOf(java.time.LocalDateTime.now()),
                    "Sinh viên mở phiếu trúng tuyển HS" + selectedHoSoId + ".");
        } catch (Exception ignored) {
            // Không chặn phiếu chỉ vì nhật ký lỗi.
        }

        model.addAttribute("result", result);
        model.addAttribute("currentUser", u);
        model.addAttribute("user", u);
        model.addAttribute("tabId", "ketqua");
        return "VIEW/USER/phieu-trung-tuyen";
    }
}
