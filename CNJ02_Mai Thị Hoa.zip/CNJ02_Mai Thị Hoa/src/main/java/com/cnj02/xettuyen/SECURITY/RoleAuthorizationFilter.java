package com.cnj02.xettuyen.SECURITY;

import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.User;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

public class RoleAuthorizationFilter extends OncePerRequestFilter {
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        String uri = request.getRequestURI();
        if (!uri.startsWith(request.getContextPath()+"/admin") && !uri.startsWith(request.getContextPath()+"/canbo")) {
            chain.doFilter(request,response); return;
        }
        HttpSession session = request.getSession(false);
        User u = session == null ? null : (User) session.getAttribute("currentUser");
        if (u == null) { response.sendRedirect(request.getContextPath()+"/login"); return; }
        Integer role = u.getRoleId();
        String path = uri.substring(request.getContextPath().length());
        boolean allowed = false;
        if (path.startsWith("/canbo")) allowed = Integer.valueOf(2).equals(role);
        else if (path.equals("/admin") || path.equals("/admin/") || path.startsWith("/admin/dashboard"))
            allowed = Integer.valueOf(1).equals(role) || Integer.valueOf(2).equals(role);
        else if (path.startsWith("/admin/users") || path.startsWith("/admin/sinh-vien") || path.startsWith("/admin/nganh") ||
                path.startsWith("/admin/chitieu") || path.startsWith("/admin/phuong-thuc") || path.startsWith("/admin/thong-bao"))
            allowed = Integer.valueOf(1).equals(role);
        else if (path.startsWith("/admin/hoso") || path.startsWith("/admin/duyet-ho-so") || path.startsWith("/admin/nguyen-vong") ||
                path.startsWith("/admin/minh-chung") || path.startsWith("/admin/diem") || path.startsWith("/admin/ket-qua"))
            allowed = Integer.valueOf(2).equals(role);
        else if (path.startsWith("/admin/thong-ke"))
            allowed = Integer.valueOf(1).equals(role) || Integer.valueOf(2).equals(role);
        else if (path.startsWith("/admin/nhap-hoc"))
            allowed = false;
        if (!allowed) { response.sendError(HttpServletResponse.SC_FORBIDDEN); return; }
        chain.doFilter(request,response);
    }
}
