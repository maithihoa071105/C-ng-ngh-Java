package com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name="Role")
public class Role {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="role_id")
    private Integer roleId;

    @Column(name="role_name")
    private String roleName;

    public Role(){}

    public Integer getRoleId(){return roleId;}
    public void setRoleId(Integer v){this.roleId=v;}

    public String getRoleName(){return roleName;}
    public void setRoleName(String v){this.roleName=v;}

}
