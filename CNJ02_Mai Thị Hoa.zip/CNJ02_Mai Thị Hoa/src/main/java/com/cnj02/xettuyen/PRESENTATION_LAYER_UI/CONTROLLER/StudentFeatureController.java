package com.cnj02.xettuyen.PRESENTATION_LAYER_UI.CONTROLLER;

import com.cnj02.xettuyen.DATA_ACCESS_ENTITY_LAYER_DAL.ENTITY.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.*;

@Controller
public class StudentFeatureController {
    private final JdbcTemplate jdbc;
    private final PasswordEncoder encoder;

    public StudentFeatureController(JdbcTemplate jdbc, PasswordEncoder encoder) {
        this.jdbc = jdbc;
        this.encoder = encoder;
    }

    private User student(HttpSession session) {
        User u = (User) session.getAttribute("currentUser");
        return u != null && Integer.valueOf(3).equals(u.getRoleId()) ? u : null;
    }

    private String guard(HttpSession session, Model model, String tab) {
        User u = (User) session.getAttribute("currentUser");
        if (u == null) return "redirect:/login";
        if (!Integer.valueOf(3).equals(u.getRoleId())) {
            return Integer.valueOf(1).equals(u.getRoleId()) || Integer.valueOf(2).equals(u.getRoleId())
                    ? "redirect:/admin/dashboard" : "redirect:/403";
        }
        model.addAttribute("user", u);
        model.addAttribute("currentUser", u);
        model.addAttribute("tabId", tab);
        return null;
    }

    @GetMapping("/ket-qua")
    public String results(HttpSession session, Model model) {
        String g = guard(session, model, "ketqua");
        if (g != null) return g;
        int uid = student(session).getUserId();
        List<Map<String,Object>> results = jdbc.queryForList(
                "SELECT kq.ket_qua_id,kq.ho_so_id,kq.diem_xet_tuyen,kq.trang_thai_ket_qua,kq.ngay_cap_nhat, " +
                "COALESCE(n.ma_nganh,CONCAT('NGANH#',kq.nganh_id)) ma_nganh, " +
                "COALESCE(n.ten_nganh,'Ngành tuyển sinh') ten_nganh " +
                "FROM KetQua kq JOIN HoSo hs ON hs.ho_so_id=kq.ho_so_id " +
                "JOIN SinhVien sv ON sv.sinh_vien_id=hs.sinh_vien_id " +
                "LEFT JOIN Nganh n ON n.nganh_id=kq.nganh_id " +
                "WHERE sv.user_id=? ORDER BY kq.ngay_cap_nhat DESC,kq.ket_qua_id DESC", uid);
        for (Map<String,Object> r : results) {
            int hs = ((Number) r.get("ho_so_id")).intValue();
            r.put("scores", jdbc.queryForList("SELECT ten_mon,diem_so FROM DiemXetTuyen WHERE ho_so_id=? ORDER BY diem_id", hs));
            r.put("to_hop", jdbc.queryForObject("SELECT COALESCE(to_hop,'Không áp dụng') FROM HoSo WHERE ho_so_id=?", String.class, hs));
        }
        model.addAttribute("results", results);
        try {
            jdbc.update("INSERT INTO HoSoLog(ho_so_id,user_id,hanh_dong,thoi_gian,chi_tiet) VALUES(NULL,?,?,?,?)",
                    uid, "XEM KẾT QUẢ", java.sql.Timestamp.valueOf(java.time.LocalDateTime.now()),
                    "Sinh viên mở trang kết quả xét tuyển.");
        } catch (Exception ignored) { }
        return "VIEW/USER/ket-qua";
    }

    @GetMapping("/nhap-hoc")
    public String enrollment(HttpSession session, Model model) {
        String g = guard(session, model, "nhaphoc");
        if (g != null) return g;
        int uid = student(session).getUserId();
        List<Map<String,Object>> rows = jdbc.queryForList(
                "SELECT kq.ket_qua_id,kq.ho_so_id,kq.diem_xet_tuyen,kq.trang_thai_ket_qua, " +
                "n.ma_nganh,n.ten_nganh,n.khoa, " +
                "sv.ho_ten,sv.cccd,sv.ngay_sinh,sv.gioi_tinh,sv.dia_chi,sv.truong_thpt, " +
                "u.email,u.phone,nh.nhap_hoc_id,nh.co_so,nh.dia_diem,nh.dia_chi dia_chi_nhap_hoc, " +
                "nh.ngay_nhap_hoc,nh.khung_gio,COALESCE(nh.trang_thai,'CHUA_NHAP_HOC') trang_thai_nhap_hoc, " +
                "nh.ghi_chu,nh.ngay_xac_nhan,nh.ngay_xu_ly,nh.ly_do_tu_choi " +
                "FROM KetQua kq JOIN HoSo hs ON hs.ho_so_id=kq.ho_so_id " +
                "JOIN SinhVien sv ON sv.sinh_vien_id=hs.sinh_vien_id " +
                "JOIN `User` u ON u.user_id=sv.user_id " +
                "LEFT JOIN Nganh n ON n.nganh_id=kq.nganh_id " +
                "LEFT JOIN NhapHoc nh ON nh.ket_qua_id=kq.ket_qua_id " +
                "WHERE sv.user_id=? AND UPPER(TRIM(kq.trang_thai_ket_qua)) IN ('TRUNG_TUYEN','DA_TRUNG_TUYEN') " +
                "ORDER BY kq.ngay_cap_nhat DESC,kq.ket_qua_id DESC", uid);
        model.addAttribute("items", rows);
        return "VIEW/USER/nhap-hoc";
    }

    @PostMapping("/nhap-hoc/xac-nhan/{ketQuaId}")
    public String confirmEnrollment(@PathVariable int ketQuaId,
                                     @RequestParam String hoTen,
                                     @RequestParam String cccd,
                                     @RequestParam String ngaySinh,
                                     @RequestParam String gioiTinh,
                                     @RequestParam String diaChi,
                                     @RequestParam String truongThpt,
                                     @RequestParam String email,
                                     @RequestParam String phone,
                                     HttpSession session, RedirectAttributes ra) {
        User u = student(session);
        if (u == null) return "redirect:/login";
        String[] values = {hoTen, cccd, ngaySinh, gioiTinh, diaChi, truongThpt, email, phone};
        for (String v : values) {
            if (v == null || v.isBlank()) {
                ra.addFlashAttribute("error", "Vui lòng điền đầy đủ thông tin nhập học trước khi xác nhận.");
                return "redirect:/nhap-hoc";
            }
        }
        Integer count = jdbc.queryForObject(
                "SELECT COUNT(*) FROM KetQua k JOIN HoSo hs ON hs.ho_so_id=k.ho_so_id JOIN SinhVien sv ON sv.sinh_vien_id=hs.sinh_vien_id " +
                "WHERE k.ket_qua_id=? AND sv.user_id=? AND UPPER(TRIM(k.trang_thai_ket_qua)) IN ('TRUNG_TUYEN','DA_TRUNG_TUYEN')", Integer.class, ketQuaId, u.getUserId());
        if (count == null || count == 0) {
            ra.addFlashAttribute("error", "Kết quả trúng tuyển không thuộc tài khoản của bạn.");
            return "redirect:/nhap-hoc";
        }
        Integer hsId = jdbc.queryForObject("SELECT ho_so_id FROM KetQua WHERE ket_qua_id=?", Integer.class, ketQuaId);
        Integer svId = jdbc.queryForObject("SELECT sinh_vien_id FROM HoSo WHERE ho_so_id=?", Integer.class, hsId);
        try {
            java.sql.Date birth = java.sql.Date.valueOf(ngaySinh);
            jdbc.update("UPDATE SinhVien SET ho_ten=?,cccd=?,ngay_sinh=?,gioi_tinh=?,dia_chi=?,truong_thpt=? WHERE sinh_vien_id=?",
                    hoTen.trim(), cccd.trim(), birth, gioiTinh.trim(), diaChi.trim(), truongThpt.trim(), svId);
            jdbc.update("UPDATE `User` SET email=?,phone=? WHERE user_id=?", email.trim(), phone.trim(), u.getUserId());
            jdbc.update("INSERT INTO NhapHoc(ket_qua_id,ho_so_id,trang_thai,ngay_xac_nhan) VALUES(?,?, 'CHO_CAN_BO_XU_LY', NOW()) " +
                    "ON DUPLICATE KEY UPDATE trang_thai='CHO_CAN_BO_XU_LY',ngay_xac_nhan=NOW(),ngay_xu_ly=NULL,nguoi_xu_ly=NULL,ly_do_tu_choi=NULL",
                    ketQuaId, hsId);
            try {
                jdbc.update("INSERT INTO HoSoLog(ho_so_id,user_id,hanh_dong,chi_tiet) VALUES(?,?,?,?)", hsId, u.getUserId(), "XÁC NHẬN NHẬP HỌC", "Sinh viên đã điền đủ thông tin và gửi xác nhận nhập học cho KQ" + ketQuaId + ".");
            } catch (Exception ignored) { }
        } catch (IllegalArgumentException ex) {
            ra.addFlashAttribute("error", "Ngày sinh không hợp lệ.");
            return "redirect:/nhap-hoc";
        }
        ra.addFlashAttribute("success", "Đã gửi xác nhận nhập học. Hồ sơ đang chờ cán bộ xử lý.");
        return "redirect:/nhap-hoc";
    }

    @GetMapping("/thong-bao")
    public String notifications(HttpSession session, Model model) {
        String g = guard(session, model, "thongbao");
        if (g != null) return g;
        int uid = student(session).getUserId();
        List<Map<String,Object>> rows = jdbc.queryForList(
                "SELECT tb.thong_bao_id,tb.tieu_de,tb.noi_dung,tb.ngay_tao, " +
                "COALESCE(nn.da_doc,FALSE) da_doc,nn.ngay_doc " +
                "FROM ThongBao tb LEFT JOIN NguoiNhanThongBao nn ON nn.thong_bao_id=tb.thong_bao_id AND nn.user_id=? " +
                "ORDER BY tb.ngay_tao DESC,tb.thong_bao_id DESC", uid);
        long unread = rows.stream().filter(r -> !Boolean.TRUE.equals(r.get("da_doc")) && !"1".equals(String.valueOf(r.get("da_doc")))).count();
        model.addAttribute("notifications", rows);
        model.addAttribute("unread", unread);
        return "VIEW/USER/thong-bao";
    }

    @PostMapping("/thong-bao/read/{id}")
    public String readNotification(@PathVariable int id, HttpSession session, RedirectAttributes ra) {
        User u = student(session);
        if (u == null) return "redirect:/login";
        Integer exists = jdbc.queryForObject("SELECT COUNT(*) FROM ThongBao WHERE thong_bao_id=?", Integer.class, id);
        if (exists == null || exists == 0) {
            ra.addFlashAttribute("error", "Thông báo không tồn tại.");
            return "redirect:/thong-bao";
        }
        Integer receiver = jdbc.queryForObject("SELECT COUNT(*) FROM NguoiNhanThongBao WHERE thong_bao_id=? AND user_id=?", Integer.class, id, u.getUserId());
        if (receiver == null || receiver == 0) {
            jdbc.update("INSERT INTO NguoiNhanThongBao(thong_bao_id,user_id,da_doc,ngay_doc) VALUES(?,?,TRUE,NOW())", id, u.getUserId());
        } else {
            jdbc.update("UPDATE NguoiNhanThongBao SET da_doc=TRUE,ngay_doc=NOW() WHERE thong_bao_id=? AND user_id=?", id, u.getUserId());
        }
        return "redirect:/thong-bao";
    }

    @GetMapping("/change-password")
    public String changePassword(HttpSession session, Model model) {
        String g = guard(session, model, "password");
        if (g != null) return g;
        return "VIEW/USER/change-password";
    }

    @PostMapping("/change-password")
    public String changePassword(@RequestParam String oldPassword,
                                 @RequestParam String newPassword,
                                 @RequestParam String confirmPassword,
                                 HttpSession session,
                                 RedirectAttributes ra) {
        User u = student(session);
        if (u == null) return "redirect:/login";
        if (newPassword.length() < 6) {
            ra.addFlashAttribute("error", "Mật khẩu mới phải có ít nhất 6 ký tự.");
            return "redirect:/change-password";
        }
        if (!newPassword.equals(confirmPassword)) {
            ra.addFlashAttribute("error", "Mật khẩu nhập lại không khớp.");
            return "redirect:/change-password";
        }
        String hash = jdbc.queryForObject("SELECT password FROM `User` WHERE user_id=?", String.class, u.getUserId());
        if (hash == null || !encoder.matches(oldPassword, hash)) {
            ra.addFlashAttribute("error", "Mật khẩu hiện tại không đúng.");
            return "redirect:/change-password";
        }
        jdbc.update("UPDATE `User` SET password=? WHERE user_id=?", encoder.encode(newPassword), u.getUserId());
        try { jdbc.update("INSERT INTO HoSoLog(ho_so_id,user_id,hanh_dong,chi_tiet) VALUES(NULL,?,?,?)", u.getUserId(), "ĐỔI MẬT KHẨU", "Sinh viên đổi mật khẩu tài khoản."); } catch (Exception ignored) { }
        ra.addFlashAttribute("success", "Đổi mật khẩu thành công.");
        return "redirect:/change-password";
    }
}
